#!/usr/bin/env python2

from __future__ import print_function
import os
import click
import json
import csv
import collections
import sys
import time
import bisect
import subprocess

import simpleRaytracer.bench as simpleRaytracer
import zxing.bench as zxing
import imagefill.bench as imagefill
import fft.bench as fft
import lu.bench as lu
import mc.bench as mc
import smm.bench as smm
import sor.bench as sor

BENCHMARKS = [simpleRaytracer, zxing, imagefill, fft, lu, mc, smm, sor]
CHECKS = [1, 2, 3, 4, 5, 6, 7, 8]
LEVELS = [
    "0.99,1.0",
    "0.99,0.999,1.0",
    "0.99,0.999,0.9999,1.0",
    "0.99,0.999,0.9999,0.99999,1.0",
    "0.99,0.999,0.9999,0.99999,0.999999,1.0",
    "0.99,0.999,0.9999,0.99999,0.999999,0.9999999,1.0",
    "0.99,0.999,0.9999,0.99999,0.999999,0.9999999,0.99999999,1.0",
    "0.99,0.999,0.9999,0.99999,0.999999,0.9999999,0.99999999,0.999999999,1.0",
]
ENERJC = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      '..', 'enerj', 'bin', 'enerjc')


def cd(fn):
    def inner(*args, **kwargs):
        os.chdir(args[0].NAME)
        res = None
        try:
            res = fn(*args, **kwargs)
        finally:
            os.chdir("..")
        return res
    return inner


def dump_json(obj, f):
    """Dump an object to a file as human-readable JSON.
    """
    json.dump(obj, f, indent=2, sort_keys=True)


# From the docs.
def find_ge(a, x):
    """Find leftmost item greater than or equal to x.
    """
    i = bisect.bisect_left(a, x)
    if i != len(a):
        return a[i]
    raise ValueError()


# Replaces bench.build().
def _build_helper(bench, checks, instrument, levels=None, timeout=False):
    old_dir = os.getcwd()
    if hasattr(bench, 'BINDIR'):
        os.chdir(bench.BINDIR)
    try:
        command = [ENERJC, "-Achecks={}".format(checks)]
        if instrument:
            command.append("-Alint=simulation")
        if levels:
            command.append("-Alevels=" + levels)
        if timeout:
            command.append("-Atimeout")
        if hasattr(bench, 'BUILD_ARGS'):
            command += bench.BUILD_ARGS
        command.append(bench.JCAT_OUT)
        subprocess.check_call(command)
    finally:
        os.chdir(old_dir)


@cd
def build(benchmark, checks, levels=None, instrument=True, timeout=False):
    """Compiles benchmark, with checks maximum checks and limit discrete
    limits.
    """
    start_time = time.time()
    if hasattr(benchmark, 'setup'):
        benchmark.setup()
    _build_helper(benchmark, checks, instrument, levels, timeout)
    end_time = time.time()
    return end_time - start_time


@cd
def run(benchmark, noisy, levels=None):
    benchmark.run(noisy, levels)


def _get_bench(name):
    """Get a benchmark by its directory name.
    """
    for bench in BENCHMARKS:
        if name == bench.NAME:
            return bench
    raise click.UsageError('no such benchmark: {}'.format(name))


@click.group()
def cli():
    pass


@cli.command('build')
@click.argument('benchname')
@click.option('--checks', type=int, default=0)
@click.option('--levels', default=None)
def build_cmd(benchname, checks, levels):
    bench = _get_bench(benchname)
    build(bench, checks, levels)


@cli.command('run')
@click.argument('benchname')
@click.option('--noisy', is_flag=True)
@click.option('--levels', default=None)
def run_cmd(benchname, noisy, levels):
    bench = _get_bench(benchname)
    run(bench, noisy, levels)


@cli.command()
@click.argument('benchname')
@click.option('--out', '-o', type=click.File(mode='w'), default=sys.stdout)
def continuous(benchname, out):
    bench = _get_bench(benchname)
    outdata = {}

    # Continuous benchmarks
    outdata['build_time'] = build(bench, 0)

    # Noisy
    run(bench, True)
    outdata['continuous'] = load_bench(bench)

    # Run-time Levels
    discretedata = outdata['discrete'] = {}
    for levels in LEVELS:
        run(bench, True, levels)
        discretedata[levels] = load_bench(bench, levels)

    dump_json(outdata, out)


@cli.command()
@click.argument('benchname')
@click.option('--out', '-o', type=click.File(mode='w'), default=sys.stdout)
def limited(benchname, out):
    bench = _get_bench(benchname)
    outdata = {}

    for checks in CHECKS:
        print('evaluating with k={} limited checks'.format(checks))

        benchdata = outdata[checks] = {}
        outdata['build_time'] = build(bench, checks)
        run(bench, True)
        benchdata.update(load_bench(bench))

    dump_json(outdata, out)


@cli.command()
@click.argument('benchname')
@click.option('--out', '-o', type=click.File(mode='w'), default=sys.stdout)
def discrete(benchname, out):
    bench = _get_bench(benchname)
    outdata = {}

    for levels in LEVELS:
        print('evaluating with compile-time levels: {}'.format(levels))

        benchdata = outdata[levels] = {}

        try:
            benchdata['build_time'] = build(bench, 0, levels, timeout=True)
        except subprocess.CalledProcessError:
            print('TIMEOUT', file=sys.stderr)
            benchdata['failure'] = 'timeout'
            continue

        run(bench, True)
        benchdata.update(load_bench(bench))

    dump_json(outdata, out)


def load_statistics(stats_file, config_file, levels=None):
    """Given an `enerjstats.json` file and an `operators.csv` file,
    return the number of precise operations and a histogram of
    approximate operations. If `levels` is provided, the precision
    levels are discretized to the levels found in the list.
    """
    # Load the dynamic statistics from the JSON dump.
    counts = json.load(stats_file)

    # Load the tuned (static) parameters from the CSV.
    config_csv = csv.reader(config_file)
    probabilities = {}
    for row in config_csv:
        for s in row:
            if ':' in s:
                name, prob = s.split(':')
                if name.startswith('op-'):
                    # Munge name following PrecisionRuntimeNoisy:107.
                    parts = name.split('-')
                    new_name = '-'.join(parts[0:2] + parts[3:6] + parts[7:9])
                    probabilities[new_name] = float(prob)

    # Aggregate the statistics.
    precise_ops = 0
    dyn_ops = 0
    approx_ops = collections.Counter()
    for name, count in counts.items():
        if name in probabilities:
            # An approximate operation.
            approx_ops[probabilities[name]] += count

        elif name == 'dyn':
            # Marker for dynamically tracked ops. These are also counted
            # elsewhere.
            dyn_ops += count

        else:
            # A precise operation.
            precise_ops += count
    approx_ops = dict(approx_ops)

    # Optionally discretize.
    if levels:
        levels = [float(n) for n in levels.split(',')]
        discrete_approx_ops = collections.Counter()
        for prob, count in approx_ops.items():
            # Find the lowest level >= the continuous level. Following
            # PrecisionRuntimeNoisy.
            discrete_prob = find_ge(levels, prob)
            discrete_approx_ops[discrete_prob] += count
        approx_ops = dict(discrete_approx_ops)

    return precise_ops, approx_ops, dyn_ops


@cd
def load_bench(bench, levels=None):
    """Load statistics from a benchmark and return a dict suitable for
    dumping as JSON.
    """
    stats_fn = 'enerjstats.json'
    operators_fn = 'operators.csv'

    if hasattr(bench, 'BINDIR'):
        stats_fn = os.path.join(bench.BINDIR, stats_fn)
        operators_fn = os.path.join(bench.BINDIR, operators_fn)

    with open(stats_fn) as stats_file:
        with open(operators_fn) as config_file:
            precise, approx, dyn = \
                load_statistics(stats_file, config_file, levels)
            return {
                'precise': precise,
                'approx': approx,
                'dyn': dyn,
            }


@cli.command('load')
@click.argument('stats_file', default='enerjstats.json', type=click.File())
@click.argument('config_file', default='operators.csv', type=click.File())
def load_cmd(stats_file, config_file):
    print(load_statistics(stats_file, config_file))


@cli.command()
@click.argument('benchname')
@click.option('--out', '-o', type=click.File(mode='w'), default=sys.stdout)
def timebuild(benchname, out):
    bench = _get_bench(benchname)
    outdata = {}

    outdata['continuous'] = build(bench, 0, instrument=False)

    leveldata = outdata['levels'] = {}
    for levels in LEVELS:
        try:
            t = build(bench, 0, levels, instrument=False)
        except subprocess.CalledProcessError:
            print('TIMEOUT', file=sys.stderr)
            t = 'timeout'
        leveldata[levels] = t

    # limitdata = outdata['limited'] = {}
    # for checks in CHECKS:
    #     limitdata[checks] = build(bench, checks, instrument=False)

    dump_json(outdata, out)


if __name__ == "__main__":
    cli()
