package jnt.scimark2;

public class RunFFT {
    public static void main(String[] argv) {
        final int N = Constants.TINY_FFT_SIZE;
        Random R = new Random(Constants.RANDOM_SEED);
        @Approx(0.9) double arr[] = kernel.RandomVector(2 * N, R);
        @Dyn double x[] = (@Dyn double[]) arr;

        for (int i = 0; i < 100; i++) {
            FFT.transform(x);
            FFT.inverse(x);
        }
        @Approx(0.9) double res[] = Endorsements.checked_endorse(x, 0.9);

        for (int i = 0; i < N; ++i) {
            System.out.print(Endorsements.endorse(res[i], 1.0) + " ");
        }
        System.out.println();
    }
}
