#!/bin/sh
enerjdir=../../enerj

enerjcargs="-Alint=simulation -AprintErrorStack"
if [ "$1" = "-nosim" ]
then
enerjcargs="-AprintErrorStack"
elif [ "$1" = "-lchecks" ]
then
enerjcargs="-Alint=simulation -AprintErrorStack -Achecks=1"
fi

rm -f jnt/*/*.class *.csv
mkdir -p bin
$enerjdir/tools/jcat.rkt -s jnt/*/*.java > bin/commandline.java
$enerjdir/bin/enerjc $enerjcargs bin/commandline.java
