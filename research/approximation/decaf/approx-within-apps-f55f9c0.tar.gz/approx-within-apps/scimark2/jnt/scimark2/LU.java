package jnt.scimark2;

import enerj.lang.*;

/**
    LU matrix factorization. (Based on TNT implementation.)
    Decomposes a matrix A  into a triangular lower triangular
    factor (L) and an upper triangular factor (U) such that
    A = L*U.  By convnetion, the main diagonal of L consists
    of 1's so that L and U can be stored compactly in
    a NxN matrix.


*/
public class LU 
{
    /**
        Returns a <em>copy</em> of the compact LU factorization.
        (useful mainly for debugging.)

        @return the compact LU factorization.  The U factor
        is stored in the upper triangular portion, and the L
        factor is stored in the lower triangular portion.
        The main diagonal of L consists (by convention) of
        ones, and is not explicitly stored.
    */

    /*
    FIXME: overloading stopped working
    protected static @Approx double[] new_copy(@Approx double x[])
    {
        int N = x.length;
        @Approx double T[] = new @Approx double[N];
        for (int i=0; i<N; i++)
            T[i] = x[i];
        return T;
    }
    */


    protected static @Approx double[][] new_copy(@Approx double A[][])
    {
        int M = A.length;
        int N = A[0].length;

        @Approx double T[][] = new @Approx double[M][N];

        for (int i=0; i<M; i++)
        {
            @Approx double Ti[] = T[i];
            @Approx double Ai[] = A[i];
            for (int j=0; j<N; j++)
                Ti[j] = Ai[j];
        }

        return T;
    }



    /*
    FIXME: overloading stopped working
    public static int[] new_copy(int x[])
    {
        int N = x.length;
        int T[] = new int[N];
        for (int i=0; i<N; i++)
            T[i] = x[i];
        return T;
    }
    */

    protected static final void insert_copy(@Approx double B[][], @Approx double A[][])
    {
        int M = A.length;
        int N = A[0].length;

		int remainder = N & 3;		 // N mod 4;

        for (int i=0; i<M; i++)
        {
            @Approx double Bi[] = B[i];
            @Approx double Ai[] = A[i];
			for (int j=0; j<remainder; j++)
                Bi[j] = Ai[j];
            for (int j=remainder; j<N; j+=4)
			{
				Bi[j] = Ai[j];
				Bi[j+1] = Ai[j+1];
				Bi[j+2] = Ai[j+2];
				Bi[j+3] = Ai[j+3];
			}
		}

    }

/**
    LU factorization (in place).

    @param A (in/out) On input, the matrix to be factored.
        On output, the compact LU factorization.

    @param pivit (out) The pivot vector records the
        reordering of the rows of A during factorization.

    @return 0, if OK, nozero value, othewise.
*/
public static @Approx double[][] factor(@Approx double[][] A, int pivot[])
{

    // Copy A so our modifications don't effect the caller
    A = new_copy(A);


    int N = A.length;
    int M = A[0].length;
    @Approx double[][] ret = new_copy(A);

    int minMN = Math.min(M,N);

    for (int j=0; j<minMN; j++)
    {
        // find pivot in column j and  test for singularity.

        int jp=j;

        double t = Math.abs(Endorsements.endorse(A[j][j]));
        for (int i=j+1; i<M; i++)
        {
            double ab = Math.abs(Endorsements.endorse(A[i][j]));
            if (ab > t)
            {
                jp = i;
            }
        }

        pivot[j] = jp;

        // jp now has the index of maximum element
        // of column j, below the diagonal

        if (Endorsements.endorse( A[jp][j] ) == 0)
            return null;       // factorization failed because of zero pivot


        if (jp != j)
        {
            // swap rows j and jp
            @Approx double tA[] = A[j];
            A[j] = A[jp];
            A[jp] = tA;
        }

        // New copy so quality may degrade
        @Approx double[][] recpA = new_copy(A);
        if (j<M-1)                // compute elements j+1:M of jth column
        {
            // note A(j,j), was A(jp,p) previously which was
            // guarranteed not to be zero (Label #1)
            //
            @Approx double recp =  1.0 / A[j][j];

            for (int k=j+1; k<M; k++)
                recpA[k][j] = A[k][j] * recp;
        }


        if (j < minMN-1)
        {
            // rank-1 update to trailing submatrix:   E = E - x*y;
            //
            // E is the region A(j+1:M, j+1:N)
            // x is the column vector A(j+1:M,j)
            // y is row vector A(j,j+1:N)


            for (int ii=j+1; ii<M; ii++)
            {
                @Approx double retii[] = ret[ii];
                @Approx double Aii[] = recpA[ii];
                @Approx double Aj[] = recpA[j];
                @Approx double AiiJ = Aii[j];
                for (int jj=j+1; jj<N; jj++)
                  retii[jj] = Aii[jj] - AiiJ * Aj[jj];

            }
        }
    }

    return ret;
}


    /**
        Solve a linear system, using a prefactored matrix
            in LU form.


        @param LU (in) the factored matrix in LU form. 
        @param pivot (in) the pivot vector which lists
            the reordering used during the factorization
            stage.
        @param b    (in/out) On input, the right-hand side.
                    On output, the solution vector.
    */
    // DECAF: LU flows into b about 200 times, hence the high probability
    public static int solve(@Approx double[][] LU, int pvt[], @Dyn double b[])
    {
        int M = LU.length;
        int N = LU[0].length;
        int ii=0;

        for (int i=0; i<M; i++)
        {
            int ip = pvt[i];
            @Dyn double firstSum = b[ip];

            b[ip] = b[i];
            if (ii==0)
                for (int j=ii; j<i; j++)
                    firstSum -= LU[i][j] * b[j];
            else
                if ((@Precise double) firstSum == 0.0)
                    ii = i;
            b[i] = firstSum;
        }

        for (int i=N-1; i>=0; i--)
        {
            @Dyn double sum = b[i];
            for (int j=i+1; j<N; j++)
                sum -= LU[i][j] * b[j];
            b[i] = sum / LU[i][i];
        }

        return 0;
    }
}
