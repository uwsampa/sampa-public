package jnt.scimark2;

import enerj.lang.*;

public class kernel
{
	// each measurement returns approx Mflops


	public static double measureFFT(int N, double mintime, Random R)
	{
		// initialize FFT data as complex (N real/img pairs)

        int size = 2 * N;
		@Dyn double x[] = RandomVector(size, R);
		//@Approx double oldx[] = NewVectorCopy(x);
		long cycles = 100;
        //@Approx(1.0) double last[] = NewVectorCopy(x);
		for (int i=0; i<cycles; i++)
		{
            // Unfortunately, this is fully precise or imprecise, and I don't
            // think there's a way to get around it.  Value degrades with each
            // iteration .  Value degrades with each iteration .  Value
            // degrades with each iteration :/
            // ENDORSEMENT_HACK
            /*
			@Approx double[] forward = FFT.transform(last);	// forward transform
			@Approx(0.999) double[] inverse = FFT.inverse(forward);		// backward transform
            last = Endorsements.endorse(forward, 1.0);
            */
            FFT.transform(x);
            FFT.inverse(x);
		}
        // LAST has precision 0.999^100 = ~0.9
        @Approx(0.9) double res[] = Endorsements.checked_endorse(x, 0.9);
        //last = null; // Prevent ourselves from treating reference precisely

		// approx Mflops
		//final double EPS = 1.0e-10;
		//if ( FFT.test(x) / N > EPS )
		//	return 0.0;
		System.out.print("FFT vector: ");
		for (int i = 0; i < N; ++i) {
		    System.out.print(Endorsements.endorse(res[i], 1.0) + " ");
		}
		System.out.println();
		
		return 0.0;
	}


	public static double measureSOR(int N, double min_time, Random R)
	{
		@Approx double G[][] = RandomMatrix(N, N, R);

		int cycles=100;
        double omega = 1.25;
		@Approx(0.9) double res[][] = SOR.execute(omega, G, cycles);
		// approx Mflops
		
		System.out.print("SOR values: ");
		for (int i = 0; i < N; ++i) {
		    for (int j = 0; j < N; ++j) {
		        System.out.print(Endorsements.endorse(res[i][j], 1.0) + " ");
		    }
		}
		System.out.println("");
		
		return 0.0;
	}

	public static double measureMonteCarlo(double min_time, Random R)
	{
		int cycles=1492;
		@Approx(0.8) double out = 0.0;
		out = MonteCarlo.integrate(cycles);
		
		System.out.println("MonteCarlo out: " + Endorsements.endorse(out, 1.0));
		
		// approx Mflops
		return 0.0;
	}


	public static double measureSparseMatmult(int N, int nz, 
			double min_time, Random R)
	{
		// initialize vector multipliers and storage for result
		// y = A*y;

		@Approx double x[] = RandomVector(N, R);
		@Approx(0.9) double y[] = new double[N];

		// initialize square sparse matrix
		//
		// for this test, we create a sparse matrix wit M/nz nonzeros
		// per row, with spaced-out evenly between the begining of the
		// row to the main diagonal.  Thus, the resulting pattern looks
		// like
		//             +-----------------+
		//             +*                +
		//             +***              +
		//             +* * *            +
		//             +** *  *          +
		//             +**  *   *        +
		//             +* *   *   *      +
		//             +*  *   *    *    +
		//             +*   *    *    *  + 
		//             +-----------------+
		//
		// (as best reproducible with integer artihmetic)
		// Note that the first nr rows will have elements past
		// the diagonal.

		int nr = nz/N; 		// average number of nonzeros per row
		int anz = nr *N;   // _actual_ number of nonzeros


		@Approx double val[] = RandomVector(anz, R);
		int col[] = new int[anz];
		int row[] = new int[N+1];

		row[0] = 0;
		for (int r=0; r<N; r++)
		{
			// initialize elements for row r

			int rowr = row[r];
			row[r+1] = rowr + nr;
			int step = r/ nr;
			if (step < 1) step = 1;   // take at least unit steps


			for (int i=0; i<nr; i++)
				col[rowr+i] = i*step;

		}

		int cycles=100;
    	SparseCompRow.matmult(y, val, row, col, x, cycles);

		System.out.print("SparseMatMult vector: ");
		for (int i = 0; i < N; ++i) {
		    System.out.print(Endorsements.endorse(y[i], 1.0) + " ");
		}
		System.out.println("");

		// approx Mflops
		return 0.0;
	}


	public static double measureLU(int N, double min_time, Random R)
	{
		// compute approx Mlfops, or O if LU yields large errors

		@Approx double A[][] = RandomMatrix(N, N,  R);
		@Approx double lu[][] = new @Approx double[N][N];
		int pivot[] = new int[N];

		int cycles=100;
        // DECAF: LU flows into b about 200 times, hence the high probability
        @Approx(0.999998) double factorRes[][] = new @Approx double[N][N];
		for (int i=0; i<cycles; i++)
		{
			CopyMatrix(lu, A);
			factorRes = LU.factor(lu, pivot);
		}


		// verify that LU is correct
        // DECAF TODO: Figure out how to fix x at 0.9, solve has issues
		@Dyn double x[] = RandomVector(N, R);
		LU.solve(factorRes, pivot, x);
        @Approx(0.9995) double x2[] = Endorsements.checked_endorse(x, 0.9995);

		// final double EPS = 1.0e-12;

        // DECAF: Endorse A and x for matvec, else it will set their precision
        // to 1 even though they are not modified

        @Dyn double[] matvecRes = matvec(A, x2);
		@Approx(0.9) double[] y = Endorsements.checked_endorse(matvecRes, 0.9);
		System.out.print("LU vector: ");
		for (int i = 0; i < N; ++i) {
		    System.out.print(Endorsements.endorse(y[i]) + " ");
		}
		System.out.println("");
        // DECAF: I removed the b array, look in enerj apps if we need this
        // back
		//if ( normabs(b, matvec(A,x)) / N > EPS )
		//	return 0.0;


		// else return approx Mflops
		//
        //
		return 0.0;
	}


  private static @Approx double[] NewVectorCopy(@Approx double x[])
  {
		int N = x.length;

		@Approx double y[] = new @Approx double[N];
		for (int i=0; i<N; i++)
			y[i] = x[i];

		return y;
  }
	
  private static void CopyVector(@Approx double B[], @Approx double A[])
  {
		int N = A.length;

		for (int i=0; i<N; i++)
			B[i] = A[i];
  }


  private static @Approx double normabs(@Approx double x[], @Approx double y[])
  {
		int N = x.length;
		@Approx double sum = 0.0;

		for (int i=0; i<N; i++) {
			sum += Math.abs(x[i]-y[i]);
		}

		return sum;
  }

  private static void CopyMatrix(@Approx double B[][], @Approx double A[][])
  {
        int M = A.length;
        int N = A[0].length;

		int remainder = N & 3;		 // N mod 4;

        for (int i=0; i<M; i++)
        {
            @Approx double Bi[] = B[i];
            @Approx double Ai[] = A[i];
			for (int j=0; j<remainder; j++)
                Bi[j] = Ai[j];
            for (int j=remainder; j<N; j+=4)
			{
				Bi[j] = Ai[j];
				Bi[j+1] = Ai[j+1];
				Bi[j+2] = Ai[j+2];
				Bi[j+3] = Ai[j+3];
			}
		}
  }

  private static @Approx double[][] RandomMatrix(int M, int N, Random R)
  {
  		@Approx double A[][] = new @Approx double[M][N];

        for (int i=0; i<N; i++)
			for (int j=0; j<N; j++)
            	A[i][j] = R.nextDouble();
		return A;
	}

	private static @Approx double[] RandomVector(int N, Random R)
	{
		@Approx double A[] = new @Approx double[N];

		for (int i=0; i<N; i++)
			A[i] = R.nextDouble();
		return A;
	}

	private static @Dyn double[] matvec(@Approx double A[][], @Approx double x[])
	{
		@Dyn double y[] = new double[x.length];

		int M = A.length;
		int N = A[0].length;

		for (int i=0; i<M; i++)
		{
			@Dyn double sum = 0.0;
			@Approx double Ai[] = A[i];
			for (int j=0; j<N; j++) {
                @Approx(0.999) double prod = Ai[j] * x[j];
				sum += prod;
			}

			y[i] = sum;
		}

		return y;
	}

    /*
    // FIXME: This will never work if y is not correct with p=1.0 or p=0.0
    // because y is a reference.  Must always RETURN an array (for safety :))
    @Deprecated
	private static void matvec(@Approx double A[][], @Approx double x[], @Approx double y[])
	{
		int M = A.length;
		int N = A[0].length;

		for (int i=0; i<M; i++)
		{
			@Approx double sum = 0.0;
			@Approx double Ai[] = A[i];
			for (int j=0; j<N; j++) {
				sum += Ai[j] * x[j];
			}

			y[i] = sum;
		}
	}
    */

}
