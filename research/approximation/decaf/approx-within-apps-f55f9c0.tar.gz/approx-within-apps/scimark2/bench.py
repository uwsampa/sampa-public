#!/usr/bin/env python2

import argparse
import glob
import os
import shutil
import subprocess
import sys

NAME = "scimark2"

DEFAULT_CHECKS = [2**x for x in range(4)]

ENERJ_DIR = "../../enerj"
BASE_BUILD = ENERJ_DIR +"/bin/enerjc -Achecks="
BASE_RUN = ENERJ_DIR + "/bin/enerj -Xmx2048m "
SCIMARK_ARGS = "-tiny"

JCAT_OUT = "commandline.java"

"""
Decorator that switches to the bin directory before calling fn, then back after
returning from fn
"""
def cd(fn):
    def inner(*args, **kwargs):
        os.chdir("bin")
        res = fn(*args, **kwargs)
        os.chdir("..")
        return res
    return inner


""" Compile the program using checks as the value for -Achecks """
@cd
def build(checks, instrument, levels=None):
    command = "../" + BASE_BUILD + str(checks) + " "
    if instrument:
        command += "-Alint=simulation "
    if levels:
        command += "-Alevels=" + levels + " "
    command += JCAT_OUT
    os.system(command)

"""
Clean up any generated files.  If class_only is truthy, only .class files will
be removed
"""
def clean(class_only):
    if class_only:
        files = glob.glob("bin/*.class")
        for file in files:
            os.remove(file)
        try:
            os.remove("bin/operators.csv")
        except OSError:
            pass
    else:
        shutil.rmtree("bin", True)

def default():
    clean(False)
    setup()
    ret = {}
    for i in DEFAULT_CHECKS:
        build(i)
        ret[i] = (run(True), run(False))
        clean(True)
    return ret

""" Create required bin directory and jcat test files """
def setup():
    # Create the bin directory
    try:
        os.mkdir("bin")
    except OSError:
        pass

    # jcat the files
    os.system(ENERJ_DIR +
              "/tools/jcat.rkt -s jnt/*/*.java > bin/" +
              JCAT_OUT)

""" Run the compiled benchmark and return the output """
@cd
def run(noisy, levels=None):
    command = "../" + BASE_RUN
    if noisy:
        command += "-noisy "
    if levels:
        command += "-Dlevels=" + levels + " "
    command += JCAT_OUT.split(".")[0] + " " + SCIMARK_ARGS
    return subprocess.check_output(command, shell=True)

# Main "method"
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Bench scimark2")
    parser.add_argument("--build",
                        action="store_true",
                        help="Only build the project, do not run")
    parser.add_argument("-i",
                        "--instrument",
                        action="store_true",
                        help="Instrument after compilation")
    parser.add_argument('-c',
                        '--checks',
                        default=0,
                        help="Max number of times to check a given method. \
                              (defalut: no limit)")
    parser.add_argument("--clean",
                        action="store_true",
                        help="Clean the bin directory and stop")
    parser.add_argument("--run",
                        action="store_true",
                        help="Run the compiled benchmark")
    parser.add_argument("-n",
                        "--noisy",
                        action="store_true",
                        help="Use noisy runtime")
    exclusive = ['build', 'clean', 'run']
    args = parser.parse_args()
    # Check how many arguments are True (not truthy, but actually True)
    trues = len([v for (k, v) in vars(args).iteritems() if v == True and k in exclusive])
    if trues > 1:
        print >> sys.stderr, "Can't set multiple actions"
        exit(1)
    if args.build:
        setup()
        build(int(args.checks), args.instrument)
    elif args.clean:
        clean(False)
    elif args.run:
        print run(args.noisy)
    else:
        default()
