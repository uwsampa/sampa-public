package jnt.scimark2;

public class RunLU {
    public static void main(String[] argv) {
        // DECAF TODO: Out of memory error if using LU_SIZE
        final int N = Constants.TINY_LU_SIZE;
        Random R = new Random(Constants.RANDOM_SEED);
        @Approx double A[][] = kernel.RandomMatrix(N, N,  R);
        @Approx double lu[][] = new @Approx double[N][N];
        int pivot[] = new int[N];

        @Approx(0.999998) double factorRes[][] = new @Approx double[N][N];
        for (int i = 0; i < 100; i++) {
            kernel.CopyMatrix(lu, A);
            factorRes = LU.factor(lu, pivot);
        }

        @Approx(0.95) double approxX[] = kernel.RandomVector(N, R);
        @Dyn double x[] = (@Dyn double[]) approxX;
        LU.solve(factorRes, pivot, x);
        @Approx(0.9995) double x2[] = Endorsements.checked_endorse(x, 0.9995);

        @Dyn double[] matvecRes = kernel.matvec(A, x2);
        @Approx(0.9) double[] y = Endorsements.checked_endorse(matvecRes, 0.9);
        for (int i = 0; i < N; ++i) {
            System.out.print(Endorsements.endorse(y[i]) + " ");
        }
        System.out.println("");
    }
}
