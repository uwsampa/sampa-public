import enerj.lang.*;

/** This class, which does flood filling, is used by the floodFill() macro function and
    by the particle analyzer
    The Wikipedia at "http://en.wikipedia.org/wiki/Flood_fill" has a good 
    description of the algorithm used here as well as examples in C and Java. 
*/
public class FloodFiller {
    int maxStackSize = 500; // will be increased as needed
    @Approx(0.99) int[] xstack; //= new @Approx int[maxStackSize];
    @Approx(0.99) int[] ystack; //= new @Approx int[maxStackSize];
    int stackSize;
    @Approx(0.99) int[][] pixels;
	@Approx(0.99) int targetColor;
  
    public FloodFiller(@Approx int[][] pixels, @Approx int targetColor) {
		this.pixels = pixels;
		this.targetColor = targetColor;
        xstack = new @Approx int[maxStackSize];
        ystack = new @Approx int[maxStackSize];
    }

	public @Approx int getPix(@Approx int ax, @Approx(0.9) int ay) {
		int x = Endorsements.endorse(ax, 1.0);
		int y = Endorsements.endorse(ay, 1.0);
		if (x < 0 || x >= pixels.length || y < 0 || y >= pixels[0].length)
			return -1;
		else
			return pixels[x][y];
	}
	public void setPix(@Approx int ax, @Approx int ay, @Approx int c) {
		int x = Endorsements.endorse(ax, 1.0);
		int y = Endorsements.endorse(ay, 1.0);
		if (x < 0 || x >= pixels.length || y < 0 || y >= pixels[0].length)
			return;
		else
			pixels[x][y] = c;
	}

    /** Does a 4-connected flood fill using the current fill/draw
        value, which is defined by ImageProcessor.setValue(). */
    public boolean fill(@Approx int x, @Approx int y) {
        @Approx int width = pixels.length;
        int height = pixels[0].length;
        @Approx int color = getPix(x, y);
        fillLine(x, x, y);
        @Approx int newColor = getPix(x, y);
		setPix(x, y, color);
        @Approx(0.9) boolean cond = color == newColor;
        @Approx(0.9) boolean cond2;
        if (Endorsements.endorse(cond, 1.0)) return false;
        stackSize = 0;
        push(x, y);
        while(true) {   
            x = popx(); 
            if (Endorsements.endorse(x) ==-1) return true;
            y = popy();
            cond = getPix(x, y) != color;
            if (Endorsements.endorse(cond)) continue;
            @Approx int x1 = x; @Approx int x2 = x;
            cond = getPix(x1, y) == color && x1 >= 0;
            while (Endorsements.endorse(cond)) { 
                x1--; // find start of scan-line
                cond = getPix(x1, y) == color && x1 >= 0;
            }
            x1++;
            cond = getPix(x2, y) == color && x2 < width;
            while (Endorsements.endorse(cond)) {
                x2++;  // find end of scan-line                 
                cond = getPix(x2, y) == color && x2 < width;
            }
            x2--;
            fillLine(x1,x2,y); // fill scan-line
            boolean inScanLine = false;
            int i = Endorsements.endorse(x1);
            @Approx(0.9) boolean loopCond = i <= x2;
            while (Endorsements.endorse(loopCond)) {
                @Approx int pixy = y-1;
                cond = y > 0 && getPix(i, pixy) == color;
                cond2 = y > 0 && getPix(i, pixy) != color;
                if (!inScanLine && Endorsements.endorse(cond)) {
                    @Approx int pushy = y-1;
                    push(i, pushy);
                    inScanLine = true;
                } else if (inScanLine && Endorsements.endorse(cond2))
                    inScanLine = false;
                ++i;
                loopCond = i <= x2;
            }
            inScanLine = false;
            i = Endorsements.endorse(x1);
            loopCond = i <= x2;
            while (Endorsements.endorse(loopCond)) { // find scan-lines below this one
                @Approx int pixy = y+1;
                int condHeight = height - 1;
                cond = y < condHeight && getPix(i, pixy) == color;
                cond2 = y < condHeight && getPix(i, pixy) != color;
                if (!inScanLine && Endorsements.endorse(cond)) {
                    @Approx int pushy = y + 1;
                    push(i, pushy);
                    inScanLine = true;
                } else if (inScanLine && Endorsements.endorse(cond2))
                    inScanLine = false;
                ++i;
                loopCond = i <= x2;
            }
        }
    }
    
    final void push(@Approx int x, @Approx int y) {
        stackSize++;
        if (stackSize==maxStackSize) {
            int size = maxStackSize * 2;
            @Approx int[] newXStack = new @Approx int[size];
            @Approx int[] newYStack = new @Approx int[size];
            System.arraycopy(xstack, 0, newXStack, 0, maxStackSize);
            System.arraycopy(ystack, 0, newYStack, 0, maxStackSize);
            xstack = newXStack;
            ystack = newYStack;
            maxStackSize *= 2;
        }
        int index = stackSize - 1;
        xstack[index] = x;
        ystack[index] = y;
    }
    
    final @Approx int popx() {
        if (stackSize==0) {
            int fail = -1;
            return fail;
        } else {
            int index = stackSize - 1;
            @Approx int ret = xstack[index];
            return ret;
        }
    }

    final @Approx int popy() {
        stackSize--;
        @Approx int value = ystack[stackSize];
        return value;
    }

    final void fillLine(@Approx int x1, @Approx int x2, @Approx int y) {
        @Approx(0.9) boolean cond = x1 > x2;
        if (Endorsements.endorse(cond)) {@Approx int t = x1; x1=x2; x2=t;}
        for (@Approx int x=x1; Endorsements.endorse(x<=x2, 1.0); x++)
			setPix(x, y, targetColor);
    }

}
