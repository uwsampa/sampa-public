#!/bin/sh
enerjdir=../../enerj

args=-Alint=simulation
if [ "$1" = "-nosim" ]
then
args=-Alint=
fi

rm -f bin/*
mkdir -p bin
$enerjdir/tools/jcat.rkt -s src/*.java > bin/FFTest.java
$enerjdir/bin/enerjc $args bin/FFTest.java
