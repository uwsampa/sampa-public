package jnt.scimark2;

public class RunSOR {
    public static void main(String[] argv) {
        final int N = Constants.TINY_SOR_SIZE;
        Random R = new Random(Constants.RANDOM_SEED);

        @Approx double G[][] = kernel.RandomMatrix(N, N, R);
        int cycles=100;
        double omega = 1.25;
        @Approx(0.9) double res[][] = SOR.execute(omega, G, cycles);

        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                System.out.print(Endorsements.endorse(res[i][j], 1.0) + " ");
            }
            System.out.println();
        }
    }
}
