import java.util.Random;
import enerj.lang.*;

public class JMEIntTest {
	public static Random rand;
	public static Vector3f randvec() {
		return new Vector3f(
			rand.nextFloat(), rand.nextFloat(), rand.nextFloat()
		);
	}
    public static void main(String[] argv) {

		// Use a constant seed so we operate deterministically.
		rand = new Random(1234); 

		for (int i = 0; i <= 100; ++i) {
			@Approx(0.9) boolean isec = Intersection.intersection(
				randvec(), randvec(), randvec(),
				randvec(), randvec(), randvec()
			);
			if (Endorsements.endorse(isec)) {
				System.out.print("1 ");
			} else {
				System.out.print("0 ");
			}
		}

		System.out.println("");

    }
}
