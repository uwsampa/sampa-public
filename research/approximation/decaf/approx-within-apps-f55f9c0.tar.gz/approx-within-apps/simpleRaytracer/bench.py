#!/usr/bin/env python2

import argparse
import glob
import os
import shutil
import subprocess
import sys

NAME = "simpleRaytracer"

ENERJ_DIR = "../../enerj"
BASE_BUILD = ENERJ_DIR +"/bin/enerjc -AprintErrorStack -Achecks="
BASE_RUN = ENERJ_DIR + "/bin/enerj "

PARAMS = "2 1 30 10"
PLANE_FILE = "Plane.java"
JCAT_OUT = PLANE_FILE

""" Compile the program using checks as the value for -Achecks """
def build(checks, instrument, levels=None):
    command = BASE_BUILD + str(checks) + " "
    if instrument:
        command += "-Alint=simulation "
    if levels:
        command += "-Alevels=" + levels + " "
    command += PLANE_FILE
    os.system(command)

"""
Clean up any generated files.  If class_only is truthy, only .class files will
be removed
"""
def clean():
    try:
        os.remove("Plane.class")
        os.remove("operators.csv")
    except OSError:
        pass

""" Run the compiled benchmark and return the output """
def run(noisy, levels=None):
    command = BASE_RUN
    if noisy:
        command += "-noisy "
    if levels:
        command += "-Dlevels=" + levels + " "
    command += PLANE_FILE.split(".")[0] + " " + PARAMS
    return subprocess.check_output(command, shell=True)

# Main "method"
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Bench scimark2")
    parser.add_argument("--build",
                        action="store_true",
                        help="Only build the project, do not run")
    parser.add_argument('-c',
                        '--checks',
                        default=0,
                        help="Max number of times to check a given method. \
                              (defalut: no limit)")
    parser.add_argument("-i",
                        '--instrument',
                        action="store_true",
                        help="Enables instrumentation")
    parser.add_argument("--clean",
                        action="store_true",
                        help="Clean the bin directory and stop")
    parser.add_argument("--run",
                        action="store_true",
                        help="Run the compiled benchmark")
    parser.add_argument("-n",
                        "--noisy",
                        action="store_true",
                        help="Use noisy runtime")
    exclusive = ['build', 'clean', 'run']
    args = parser.parse_args()
    # Check how many arguments are True (not truthy, but actually True)
    trues = len([v for (k, v) in vars(args).iteritems() if v == True and k in exclusive])
    if trues > 1:
        print >> sys.stderr, "Can't set multiple actions"
        exit(1)
    if args.build:
        build(int(args.checks), args.instrument)
    elif args.clean:
        clean()
    elif args.run:
        print run(args.noisy)
    else:
        default()
