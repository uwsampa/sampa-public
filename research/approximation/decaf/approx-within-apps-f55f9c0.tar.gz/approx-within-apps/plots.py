#!/usr/bin/env python2

from __future__ import print_function
import click
import json
import os
import subprocess
import contextlib
import tempfile
import sys


COLORS = [
    '#000000',
    '#333333',
    '#666666',
    '#999999',
    '#aaaaaa',
    '#cccccc',
    '#dddddd',
    '#ffffff',
]

BENCHNAMES = {
    'simpleRaytracer': 'raytracer',
}


@click.group()
@click.option('--kind', '-k', default='pdf')
@click.option('--dest', '-d', default='plots')
@click.pass_context
def cli(ctx, kind, dest):
    ctx.obj['kind'] = kind
    ctx.obj['dest'] = dest


def _gnuplot_table(rows):
    out = []
    for row in rows:
        for value in row:
            out.append(str(value))
            out.append('\t')
        out.append('\n')
    return ''.join(out)


def ps2pdf(psfile, pdffile=None):
    args = ['ps2pdf', '-dEPSCrop', psfile]
    if pdffile:
        args.append(pdffile)
    subprocess.check_call(args)
    os.remove(psfile)


def gnuplot(script, data, outfile, kind='pdf', width=3.5, height=2.7):
    if kind == 'pdf':
        script = 'set terminal postscript;\n' + script
        filename = outfile + '.eps'
    elif kind == 'tex':
        script = """
set terminal epslatex size {}in,{}in header "\\\\sffamily \\\\footnotesize";
        """.format(width, height) + script
        filename = outfile + '.tex'
    script = "set output '{}';\n".format(filename) + script

    datafd, datafn = tempfile.mkstemp('.gp')
    datafh = os.fdopen(datafd, 'w')
    with contextlib.closing(datafh):
        datafh.write(data)
    script = "data_file = '{}';\n".format(datafn) + script

    # print(script)

    try:
        proc = subprocess.Popen(['gnuplot', '-e', script],
                                stdin=subprocess.PIPE)
        # proc.communicate(data.encode('utf8'))
        proc.communicate()
    except subprocess.CalledProcessError:
        print('gnuplot error', file=sys.stderr)
        return

    os.remove(datafn)

    if kind == 'pdf':
        ps2pdf(outfile + '.eps', outfile + '.pdf')
    elif kind == 'tex':
        # Strip CreationDate from EPS file to avoid spurious revision
        # control noise.
        epsfile = outfile + '.eps'
        lines = []
        with open(epsfile) as f:
            for line in f:
                if '%%CreationDate:' not in line and \
                   '/CreationDate (' not in line:
                    lines.append(line)
        with open(epsfile, 'w') as f:
            for line in lines:
                f.write(line)


def plot(ctx, script, rows, name, **kwargs):
    gnuplot(script, _gnuplot_table(rows),
            os.path.join(ctx.obj['dest'], name),
            kind=ctx.obj['kind'],
            **kwargs)

    # Hacky hacky hack: fix up TeX document path.
    if ctx.obj['kind'] == 'tex':
        texfile = os.path.join(ctx.obj['dest'], name) + '.tex'
        with open(texfile) as f:
            tex = f.read()
        tex = tex.replace(ctx.obj['dest'], os.path.basename(ctx.obj['dest']))
        with open(texfile, 'w') as f:
            f.write(tex)


@cli.command()
@click.argument('jsonfile', type=click.File())
@click.pass_context
def levels(ctx, jsonfile, max_configs=8):
    jsondata = json.load(jsonfile)

    rows = []
    plots = []
    index = -1
    for bench, values in sorted(jsondata.items()):
        index += 1

        rows.append(BENCHNAMES.get(bench, bench))
        pairs = sorted(values.items())
        pairs = pairs[:max_configs - 1] + [pairs[-1]]
        for key, value in pairs:
            if key == 'asterisks':
                continue
            config = key.replace('-rounded', '')
            name = config
            if config == 'continuous':
                # FIXME currently just using the last position
                config = 9
                name = '$\\\\infty$'
            rows.append((config, value, name))
        rows.append(())
        rows.append(())

        plots.append("""
            unset key;
            unset xtics;
            set xrange [{xmin}:{xmax}];
            set ytics offset char 0.5 nomirror scale 1.5;
            set mytics 2;
            set label 11 center at graph 0.5, char 0.3 "{title}";
            set lmargin 4;
            set rmargin 0;
            set tmargin 0.5;
            set bmargin 1;
            set format y "\\\\tiny {yformat}";
            set border 3;
            plot data_file index {index} title columnheader(1)
                    with points pt 7,
                data_file index {index} using 1:2:3 with labels
                    offset 0,0.5;
        """.format(
            index=index,
            xmin=0.5,
            xmax=len(pairs) + 2.2,
            title=BENCHNAMES.get(bench, bench),
            yformat='%g',
        ))

    script = """
        set multiplot layout 1,{nplots};
        {plots}
    """.format(
        plots=''.join(plots),
        nplots=len(plots),
    )
    plot(ctx, script, rows, 'levels', width=7)


@cli.command()
@click.argument('appname')
@click.argument('jsonfile', type=click.File())
@click.pass_context
def cdf(ctx, appname, jsonfile):
    jsondata = json.load(jsonfile)

    rows = []
    plots = []
    xmin = 1.0
    xmax = 0.0
    index = -1
    for config, cdf_points in sorted(jsondata.items()):
        if 'rounded' in config:
            continue
        index += 1

        local_xmin = None
        local_xmax = None
        rows.append('"{}"'.format(config))
        for p, f in cdf_points:
            invp = 1 - float(p)
            rows.append((invp, f))
            if f < 0.99:
                local_xmin = invp
            if not local_xmax and f > 0.02:
                local_xmax = invp
        rows.append([])
        rows.append([])

        plots.append(
            'data_file i {index} u 1:2 w linespoints '
            'title columnheader(1) lw {lw}'.format(
                index=index,
                lw=3 if config == 'unlimited' else 1,
            )
        )
        xmin = min(local_xmin, xmin)
        xmax = max(local_xmax, xmax)
        print(local_xmax)

    script = """
        set xrange [{xmin}:{xmax}] reverse;
        set logscale x;
        set yrange [0:1];
        set format x "$1 - 10^{{%T}}$";
        set key top left;
        plot {plots};
    """.format(
        xmin=xmin,
        xmax=xmax,
        plots=', '.join(plots),
    )
    plot(ctx, script, rows, 'limitcdf-{}'.format(appname))


@cli.command()
@click.argument('appname')
@click.argument('jsonfile', type=click.File())
@click.pass_context
def spark(ctx, appname, jsonfile, max_levels=3):
    jsondata = json.load(jsonfile)

    rounded_plots = []
    solved_plots = []
    rows = []
    index = -1
    left = True
    for _, configdata in sorted(jsondata.items()):
        for mode, plots in (("rounded", rounded_plots),
                            ("solved", solved_plots)):
            if len(plots) >= max_levels:
                continue
            index += 1

            for level in configdata['config'].split(','):
                if level in configdata[mode]:
                    freq = configdata[mode][level]
                else:
                    freq = 0
                rows.append((level, freq * 100))
            rows.append(())
            rows.append(())

            top = mode == 'rounded'
            plots.append("""
                set style data histogram;
                set style histogram rowstacked;
                set style fill solid border -1;
                unset key;
                set yrange [0:100];
                set xtic scale 0 rotate by -45;
                set ytic 50 scale 1.5;
                set mytic 5;
                {tic}
                {yl}
                {yf}
                set lmargin {lmargin};
                set rmargin 0;
                set tmargin {tmargin};
                set bmargin {bmargin};
                plot data_file i {index} u 2:xtic(1)
                    lc rgb "#999999" lw 1;
            """.format(
                index=index,
                tic='unset xtics;' if top else '',
                yl='set ylabel "{}" offset 2.1;'.format(mode) if left
                   else 'unset ylabel;',
                yf='set format y "";',
                bmargin=0,
                lmargin=0,
                tmargin=0.1 if top else 0,
            ))

        left = False

    plots = rounded_plots + solved_plots

    # We do a multiplot with 3 rows to leave room for the bottom labels.
    script = """
        set multiplot layout 3,{ncols};
        {rounded_plots}
        {solved_plots}
    """.format(
        ncols=min(max_levels, len(jsondata)),
        rounded_plots=''.join(rounded_plots),
        solved_plots=''.join(solved_plots),
    )

    plot(ctx, script, rows, 'spark-{}'.format(appname),
         width=3.0, height=1.8)


@cli.command()
@click.argument('jsonfile', type=click.File())
@click.pass_context
def forced1(ctx, jsonfile, max_configs=8):
    jsondata = json.load(jsonfile)

    rows = []
    for bench, values in sorted(jsondata.items()):
        values = [v for k, v in sorted(values.items()) if k != 'asterisks']
        if len(values) > max_configs:
            values = values[:max_configs - 1] + [values[-1]]
        rows.append([BENCHNAMES.get(bench, bench)] + values)

    # Title row.
    configs = sorted(jsondata.values()[0].keys())
    configs = ['"{}"'.format(c.replace('-rounded', '')
                             .replace('continuous', '$\\\\infty$'))
               for c in configs]
    if len(configs) > max_configs:
        configs = configs[:max_configs - 1] + [configs[-1]]
    rows.insert(0, ['benchmark'] + configs)

    plots = []
    for i in range(len(rows[0]) - 1):
        plots.append(
            'data_file using {}:xtic(1) title col '
            'lt 1 lc rgb "{}"'
            .format(i + 2, COLORS[i])
        )
    script = """
        set style data histogram;
        set style histogram cluster gap 1;

        set style fill solid border rgb "black";
        set auto x;
        set ylabel "fraction of ops forced precise" offset 2;
        set key spacing 0.7 samplen 1.5 top left;

        plot {};
    """.format(', '.join(plots))
    plot(ctx, script, rows, 'forced1')


@cli.command()
@click.argument('jsonfile', type=click.File())
@click.pass_context
def level_breakdown(ctx, jsonfile, levelcounts=range(2, 9)):
    jsondata = json.load(jsonfile)

    # Generate probability levels via their numbers of nines.
    problevels = ["0." + "9" * nines for nines in levelcounts]

    rows = []
    plots = []
    index = -1
    for bench, values in sorted(jsondata.items()):
        index += 1

        # Header row.
        if index == 0:
            rows.append(['levels'] + problevels + ['1.0'])

        for levels in levelcounts:
            row = []
            if levels in values['asterisks']:
                row.append(
                    r'"\\raisebox{{1.5ex}}{{\\shortstack{{$\\star$\\\\{}}}}}"'
                    .format(levels)
                )
            else:
                row.append(levels)
            fracs = values[str(levels)]
            for prob in problevels:
                row.append(fracs.get(prob, 0) * 100)
            row.append(fracs.get("1.0", 0) * 100)
            rows.append(row)

        # Section separator.
        rows.append(())
        rows.append(())

        name = BENCHNAMES.get(bench, bench)
        plots.append(r'newhistogram "\\raisebox{{-2ex}}{{{}}}"'.format(name))
        for levels in levelcounts + [levelcounts[-1] + 1]:
            i = levels - levelcounts[0]
            plots.append("""
                data_file index {index} using {col}:xtic(1)
                lc rgb "{color}" lt 1 lw 1 {etc}
            """.format(
                index=index,
                col=i + 2,
                color=COLORS[i],
                etc='t col' if index == 0 else 'notitle',
            ))

    script = """
        set style histogram rows;
        set style data histograms;
        set style fill solid border -1;
        unset xtics;
        set xtics nomirror;
        set yrange [0:100];
        set ytics nomirror;
        set mytics 2;
        set key outside right nobox reverse Left;
        set border 2;
        set format y "%g\\\\%%";
        set xrange [{xmin}:*];
        plot {plots};
    """.format(
        plots=','.join(plots),
        xmin=-2.5,
    )
    plot(ctx, script, rows, 'levelbreakdown', width=9)


@cli.command()
@click.argument('jsonfile', type=click.File())
@click.pass_context
def idealhist(ctx, jsonfile, max_levels=3):
    jsondata = json.load(jsonfile)

    _colors = [
        '#000000',
        '#cccccc',
        '#ffffff',
        '#000000',
    ]

    # Header row.
    headrow = ['bench']
    lastbucket = None
    for bucket, _ in jsondata.values()[0]:
        if bucket == 2.0:  # Indicating ==1.0 values.
            headrow.append(r'"$p=1.0$"')
        elif lastbucket is None:
            headrow.append(r'"$p<{}$"'.format(bucket))
        else:
            headrow.append(r'"${} \\le p < {}$"'.format(lastbucket, bucket))
        lastbucket = bucket

    rows = [headrow]
    plots = []
    for bench, hist in sorted(jsondata.items()):
        rows.append([BENCHNAMES.get(bench, bench)] +
                    [f * 100 for _, f in hist])

    for col in range(2, len(headrow) + 1):
        i = col - 2
        top = col == len(headrow)
        plots.append("""
            data_file u {col}:xtic(1) ti col lc rgb "{color}" lw 1 lt 1
            fs pattern {pattern}
        """.format(
            col=col,
            color=_colors[i],
            pattern=2 if top else 3,
        ))

    # We do a multiplot with 3 rows to leave room for the bottom labels.
    script = """
        set style data histogram;
        set style histogram rowstacked;
        set style fill solid border -1;
        set key above left reverse Left invert samplen 1 vertical;
        set yrange [0:100];
        set format y {yformat};
        set mytics 2;
        set xtics nomirror scale 0;
        set boxwidth 0.9;
        set lmargin 6;
        set tmargin 5;
        set rmargin 1;
        set xrange [{xmin}:{xmax}];
        plot {plots};
    """.format(
        plots=','.join(plots),
        yformat='"%g\\\\%%"',
        xmin=-0.7,
        xmax=len(jsondata) - 0.3,
    )

    plot(ctx, script, rows, 'idealhist')

if __name__ == '__main__':
    cli(obj={})
