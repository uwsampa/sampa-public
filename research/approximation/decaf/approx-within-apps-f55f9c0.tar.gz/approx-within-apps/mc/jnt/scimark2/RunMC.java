package jnt.scimark2;

public class RunMC {
    public static void main(String[] argv) {
        int cycles=1492;
        @Approx(0.9) double out = 0.0;
        out = MonteCarlo.integrate(1492);
        System.out.println(Endorsements.endorse(out, 1.0));
    }
}
