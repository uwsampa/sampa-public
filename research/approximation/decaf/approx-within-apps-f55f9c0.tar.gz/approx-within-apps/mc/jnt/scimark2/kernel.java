package jnt.scimark2;

import enerj.lang.*;

public class kernel
{
	// each measurement returns approx Mflops


  public static @Approx double[] NewVectorCopy(@Approx double x[])
  {
		int N = x.length;

		@Approx double y[] = new @Approx double[N];
		for (int i=0; i<N; i++)
			y[i] = x[i];

		return y;
  }
	
  public static void CopyVector(@Approx double B[], @Approx double A[])
  {
		int N = A.length;

		for (int i=0; i<N; i++)
			B[i] = A[i];
  }


  public static @Approx double normabs(@Approx double x[], @Approx double y[])
  {
		int N = x.length;
		@Approx double sum = 0.0;

		for (int i=0; i<N; i++) {
			sum += Math.abs(x[i]-y[i]);
		}

		return sum;
  }

  public static void CopyMatrix(@Approx double B[][], @Approx double A[][])
  {
        int M = A.length;
        int N = A[0].length;

		int remainder = N & 3;		 // N mod 4;

        for (int i=0; i<M; i++)
        {
            @Approx double Bi[] = B[i];
            @Approx double Ai[] = A[i];
			for (int j=0; j<remainder; j++)
                Bi[j] = Ai[j];
            for (int j=remainder; j<N; j+=4)
			{
                int j1 = j+1;
                int j2 = j+2;
                int j3 = j+3;
				Bi[j] = Ai[j];
				Bi[j1] = Ai[j1];
				Bi[j2] = Ai[j2];
				Bi[j3] = Ai[j3];
			}
		}
  }

  public static @Approx double[][] RandomMatrix(int M, int N, Random R)
  {
  		@Approx double A[][] = new @Approx double[M][N];

        for (int i=0; i<N; i++)
			for (int j=0; j<N; j++)
            	A[i][j] = R.nextDouble();
		return A;
	}

	public static @Approx double[] RandomVector(int N, Random R)
	{
		@Approx double A[] = new @Approx double[N];

		for (int i=0; i<N; i++)
			A[i] = R.nextDouble();
		return A;
	}

	public static @Dyn double[] matvec(@Approx double A[][], @Approx double x[])
	{
		@Dyn double y[] = new double[x.length];

		int M = A.length;
		int N = A[0].length;

		for (int i=0; i<M; i++)
		{
			@Dyn double sum = 0.0;
			@Approx double Ai[] = A[i];
			for (int j=0; j<N; j++) {
                @Approx(0.999) double prod = Ai[j] * x[j];
				sum += prod;
			}

			y[i] = sum;
		}

		return y;
	}

    /*
    // FIXME: This will never work if y is not correct with p=1.0 or p=0.0
    // because y is a reference.  Must always RETURN an array (for safety :))
    @Deprecated
	private static void matvec(@Approx double A[][], @Approx double x[], @Approx double y[])
	{
		int M = A.length;
		int N = A[0].length;

		for (int i=0; i<M; i++)
		{
			@Approx double sum = 0.0;
			@Approx double Ai[] = A[i];
			for (int j=0; j<N; j++) {
				sum += Ai[j] * x[j];
			}

			y[i] = sum;
		}
	}
    */

}
