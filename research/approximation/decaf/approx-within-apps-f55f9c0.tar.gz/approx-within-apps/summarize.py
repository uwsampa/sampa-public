#!/usr/bin/env python2

from __future__ import division
from __future__ import print_function
import click
import collections
import json
import os
import sys
import subprocess
import csv
from StringIO import StringIO


@click.group()
def cli():
    pass


def _combined_data(filenames):
    benchdata = collections.defaultdict(dict)
    for fn in filenames:
        bench, mode, _ = os.path.basename(fn).split('.', 2)
        with open(fn) as f:
            benchdata[bench][mode] = json.load(f)
    return dict(benchdata)


def _avg_prob(counts_dict):
    total_prob = 0.0
    total_count = 0
    for prob, count in counts_dict['approx'].items():
        total_prob += float(prob) * count
        total_count += count
    return total_prob / total_count


def human_time(secs, abbrev=False):
    secs = int(secs)
    minutes = secs // 60
    secs = secs % 60

    if minutes:
        value = minutes
        unit = 'min' if abbrev else 'minute'
    else:
        value = secs
        unit = 'sec' if abbrev else 'second'

    return '{} {}{}'.format(
        value,
        unit,
        '' if value == 1 or abbrev else 's',
    )


@cli.command()
@click.argument('filenames', nargs=-1)
def level_sensitivity(filenames):
    _summarize(filenames, _avg_prob)


def _norm_probs(counts_dict):
    approx_dict = counts_dict['approx']
    total_count = sum(approx_dict.values())
    out = {}
    for prob, count in counts_dict['approx'].items():
        out[prob] = count / total_count
    return out


@cli.command()
@click.argument('filenames', nargs=-1)
def level_breakdown(filenames):
    _summarize(filenames, _norm_probs)


@cli.command()
@click.argument('filenames', nargs=-1)
def timing(filenames):
    all_data = _combined_data(filenames)
    times = {}
    for bench, data in all_data.items():
        times[bench] = human_time(data['time']['continuous'], True)
    json.dump(times, sys.stdout, indent=2, sort_keys=True)


def getloc(directory, langs=('Java',)):
    report = subprocess.check_output(['cloc', '--csv', '--quiet', directory])
    report = report.decode('utf8')
    if '\r\n' in report:
        _, report = report.split('\r\n')
    report = report.strip()

    reader = csv.DictReader(StringIO(report))
    lines = 0
    for row in reader:
        if row['language'] in langs:
            lines += int(row['code'])
    return lines


def getoccur(pattern, directory):
    try:
        ackout = subprocess.check_output(['ack', '--type=java',
                                          '-o', pattern, directory])
    except subprocess.CalledProcessError:
        return 0
    ackout = ackout.decode('utf8')
    return len(ackout.strip().split('\n'))


@cli.command()
@click.argument('appdirs', nargs=-1)
def codecount(appdirs):
    counts = {}
    for appdir in appdirs:
        appname = os.path.basename(appdir)
        counts['{}-loc'.format(appname)] = getloc(appdir)
        counts['{}-approx'.format(appname)] = getoccur(r'@Approx[^\(]', appdir)
        counts['{}-approxp'.format(appname)] = getoccur(r'@Approx\(', appdir)
        counts['{}-dyn'.format(appname)] = getoccur('@Dyn', appdir)
    json.dump(counts, sys.stdout, indent=2, sort_keys=True)


def _prob_cdf(probs):
    approx_probs = {float(k): int(v) for k, v in probs['approx'].items()}
    total = sum(approx_probs.values())

    integrated = 0
    cdf_points = []
    for prob, count in sorted(approx_probs.items()):
        integrated += count
        cdf_points.append((prob, integrated / total))

    # Add a 1.0 point if there is none already to anchor the rhs of the
    # plot.
    if cdf_points[-1][1] != 1.0:
        cdf_points.append((1.0, 1.0))

    return cdf_points


@cli.command()
@click.argument('filenames', nargs=-1)
def cdf(filenames):
    """Compute operation precision CDF data for k-limited versions of a
    benchmark.
    """
    all_data = _combined_data(filenames)
    assert len(all_data) == 1
    data = all_data.values()[0]

    bench_cdfs = {}

    # Baseline: continuous case.
    bench_cdfs['unlimited'] = \
        _prob_cdf(data['continuous']['continuous'])

    for limit, limit_data in data['limited'].items():
        if isinstance(limit_data, dict):
            bench_cdfs[limit] = _prob_cdf(limit_data)

    json.dump(bench_cdfs, sys.stdout, indent=2, sort_keys=True)


def _normalize(probs):
    approx_probs = {float(k): int(v) for k, v in probs['approx'].items()}
    total = sum(approx_probs.values())
    out = {}
    for prob, count in sorted(approx_probs.items()):
        out[prob] = count / total
    return out


@cli.command()
@click.argument('filenames', nargs=-1)
def aggcounts(filenames):
    all_data = _combined_data(filenames)
    assert len(all_data) == 1
    data = all_data.values()[0]

    out = {}
    for levels in data['continuous']['discrete']:
        if levels in data['discrete']:
            level_count = len(levels.split(','))
            out[level_count] = {
                'config': levels,
                'solved': _normalize(data['discrete'][levels]),
                'rounded': _normalize(data['continuous']['discrete'][levels]),
            }

    json.dump(out, sys.stdout, indent=2, sort_keys=True)


def _forced1_fraction(counts_dict):
    """Get the fraction of approximate operations that were forced to
    1.0 precision.
    """
    approx_counts = counts_dict['approx']
    total = sum(approx_counts.values())
    forced = approx_counts.get("1.0", 0)
    return forced / total


def _summarize(filenames, summfunc):
    """Generic data summarization command.
    """
    all_data = _combined_data(filenames)
    all_out = {}

    for bench, data in all_data.items():
        if 'continuous' not in data:
            print('{} has no data'.format(bench), file=sys.stderr)
            continue
        elif not data['continuous']['continuous']['approx']:
            print('{} has empty data'.format(bench), file=sys.stderr)
            continue

        bench_out = all_out[bench] = {}
        asterisks = bench_out['asterisks'] = []

        # Baseline: completely continuous case.
        bench_out['continuous'] = \
            summfunc(data['continuous']['continuous'])

        # If the level list is present in both the compile-time and
        # run-time data, gather both.
        level_range = [k for k in data['continuous']['discrete']
                       if k in data['discrete']]

        for levels in level_range:
            level_count = len(levels.split(','))
            if 'failure' in data['discrete'][levels]:
                print('falling back to continuous for {}/{}-level'.format(
                    bench, level_count
                ), file=sys.stderr)
                res = data['continuous']['discrete'][levels]
                asterisks.append(level_count)
            else:
                res = data['discrete'][levels]
            bench_out[str(level_count)] = summfunc(res)

    json.dump(all_out, sys.stdout, indent=2, sort_keys=True)


@cli.command()
@click.argument('filenames', nargs=-1)
def forced1(filenames):
    _summarize(filenames, _forced1_fraction)


def _tex_percent(frac):
    if frac < 0.01:
        return r'$<$1\%'
    else:
        return r'{}\%'.format(int(frac * 100))


@cli.command()
@click.argument('filenames', nargs=-1)
def dynops(filenames):
    all_data = _combined_data(filenames)

    out = {}
    for bench, data in all_data.items():
        cts = data['continuous']['continuous']
        approx = sum(cts['approx'].values())
        precise = cts['precise']
        dyn = cts['dyn']
        total = approx + precise
        out.update({
            '{}-approx'.format(bench): _tex_percent(approx / total),
            '{}-precise'.format(bench): _tex_percent(precise / total),
            '{}-dyn'.format(bench): _tex_percent(dyn / total),
        })

    json.dump(out, sys.stdout, indent=2, sort_keys=True)


def _hist(capprox, buckets):
    total = sum(capprox.values())
    normapprox = {float(k): v / total for k, v in capprox.items()}

    bench_hist = []
    bucket_lo = 0.0
    for bucket_hi in buckets:
        bucket_f = 0.0
        for p, f in normapprox.items():
            if p >= bucket_lo and p < bucket_hi:
                bucket_f += f

        bench_hist.append((bucket_hi, bucket_f))

        # For the next round.
        bucket_lo = bucket_hi

    return bench_hist


@cli.command()
@click.argument('filenames', nargs=-1)
def idealhist(filenames, buckets=(0.99, 0.99999999, 1.0, 2.0)):
    all_data = _combined_data(filenames)

    hists = {}
    for bench, data in all_data.items():
        capprox = data['continuous']['continuous']['approx']
        hists[bench] = _hist(capprox, buckets)

    json.dump(hists, sys.stdout, indent=2, sort_keys=True)


@cli.command()
@click.argument('filenames', nargs=-1)
def limithist(filenames,
              buckets=(0.99, 0.999, 0.9999, 0.99999, 0.999999, 0.9999999,
                       0.99999999, 0.999999999, 1.0, 2.0)):
    all_data = _combined_data(filenames)

    hists = {}
    bench_data = all_data.values()[0]
    for limit, limit_data in bench_data['limited'].items():
        if isinstance(limit_data, dict):
            limit_approx = limit_data['approx']
            hists[limit] = _hist(limit_approx, buckets)

    json.dump(hists, sys.stdout, indent=2, sort_keys=True)


MODEL = {
    '0.99': 0.7,
    '0.999': 0.75,
    '0.9999': 0.8,
    '0.99999': 0.85,
    '0.999999': 0.9,
    '0.9999999': 0.95,
    '0.99999999': 0.98,
    '0.999999999': 0.99,
    '1.0': 1.0,
}


def _energy_model(counts):
    total_ops = counts['precise'] + sum(counts['approx'].values())
    relaxed_op_cost = counts['precise']
    for level, count in counts['approx'].items():
        relaxed_op_cost += count * MODEL[level]
    return 1.0 - relaxed_op_cost / total_ops


@cli.command()
@click.argument('filenames', nargs=-1)
def energy_compare(filenames):
    all_data = _combined_data(filenames)
    all_out = {}

    for bench, data in all_data.items():
        level_range = [k for k in data['continuous']['discrete']
                       if k in data['discrete']]
        bench_out = all_out[bench] = {}
        for levels in level_range:
            level_count = len(levels.split(','))
            rounded = _energy_model(data['continuous']['discrete'][levels])
            if 'failure' in data['discrete'][levels]:
                solved = None
            else:
                solved = _energy_model(data['discrete'][levels])
            bench_out[str(level_count)] = rounded, solved

    json.dump(all_out, sys.stdout, indent=2, sort_keys=True)


@cli.command()
@click.argument('filename')
def energy_table(filename, levels=8):
    with open(filename) as f:
        data = json.load(f)
    out = {}
    for bench, bench_data in data.items():
        rounded, solved = bench_data[str(levels)]
        out.update({
            '{}-rounded'.format(bench): _tex_percent(rounded),
            '{}-solved'.format(bench):
            _tex_percent(solved) if solved else '---',
        })
    json.dump(out, sys.stdout, indent=2, sort_keys=True)


if __name__ == '__main__':
    cli()
