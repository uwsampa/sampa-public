@Approximable
package strict.stat;

import enerj.lang.Approximable;