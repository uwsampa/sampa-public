@Approximable
package strict;

import enerj.lang.Approximable;
