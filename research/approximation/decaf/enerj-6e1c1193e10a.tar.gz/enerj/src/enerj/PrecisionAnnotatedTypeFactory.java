package enerj;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.Collections;

import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.type.TypeKind;
import java.lang.annotation.Annotation;

import com.sun.source.tree.BinaryTree;
import com.sun.source.tree.ClassTree;
import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.tree.ExpressionTree;
import com.sun.source.tree.MemberSelectTree;
import com.sun.source.tree.MethodInvocationTree;
import com.sun.source.tree.NewClassTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.Tree.Kind;
import com.sun.source.tree.TypeParameterTree;
import com.sun.source.util.TreePath;

import org.checkerframework.common.basetype.BaseTypeChecker;
import org.checkerframework.framework.source.Result;
import org.checkerframework.framework.type.AnnotatedTypeMirror;
import org.checkerframework.framework.type.AnnotatedTypeMirror.AnnotatedArrayType;
import org.checkerframework.framework.type.AnnotatedTypeMirror.AnnotatedDeclaredType;
import org.checkerframework.framework.type.AnnotatedTypeMirror.AnnotatedExecutableType;
import org.checkerframework.framework.type.AnnotatedTypeMirror.AnnotatedTypeVariable;
import org.checkerframework.framework.type.AnnotatedTypeFactory;
import org.checkerframework.common.basetype.BaseAnnotatedTypeFactory;
import org.checkerframework.framework.type.GenericAnnotatedTypeFactory;
import org.checkerframework.framework.type.TreeAnnotator;
import org.checkerframework.javacutil.AnnotationUtils;
import org.checkerframework.javacutil.Pair;
import org.checkerframework.framework.util.AnnotatedTypes;
import org.checkerframework.framework.util.AnnotationBuilder;
import org.checkerframework.framework.type.QualifierHierarchy;
import org.checkerframework.framework.util.GraphQualifierHierarchy;
import org.checkerframework.framework.util.MultiGraphQualifierHierarchy;
import org.checkerframework.framework.type.TypeHierarchy;

import enerj.lang.*;

/**
 * The annotated type factory for the precision checker.
 * We currently do not want automatic flow inference, so turn it off.
 */
public class PrecisionAnnotatedTypeFactory extends BaseAnnotatedTypeFactory {

    public static final String CONSTS_FILE = "enerjnoiseconsts.json";
    public static float TIMING_ERROR_PROB_PERCENT = 0;

	public PrecisionAnnotatedTypeFactory(PrecisionChecker checker) {
		super(checker, false);
        postInit();
	}

    private PrecisionChecker chk() {
        return (PrecisionChecker)checker;
    }

	/**
     * The type of "this" is always "context" if its type is approximable. Otherwise it
     * is precise.
     */
    @Override
    public AnnotatedDeclaredType getSelfType(Tree tree) {
    	AnnotatedDeclaredType type = super.getSelfType(tree);

    	if (type!=null) {
    	    // Check whether the type of "this" is approximable.
    		type.clearAnnotations();
    		if (PrecisionChecker.isApproximable(type.getUnderlyingType())) {
        		type.addAnnotation(chk().CONTEXT);
    		} else {
        	    type.addAnnotation(chk().PRECISE);
    		}
    	}
        return type;
    }

    /**
     * Adapt the type of field accesses.
     */
    @Override
    public void postAsMemberOf(AnnotatedTypeMirror type,
            AnnotatedTypeMirror owner, Element element) {
		assert type != null;
		assert owner != null;
		assert element != null;

    	if(type.getKind() != TypeKind.DECLARED &&
    		type.getKind() != TypeKind.ARRAY &&
    		!type.getKind().isPrimitive()) {
    		// nothing to do
    		return;
    	}
    	if(element.getKind() == ElementKind.LOCAL_VARIABLE) {
    		// the type of local variables also does not need to change
    		return;
    	}

    	/*
		System.out.println("\npostasmemberof:");
    	System.out.println("in type: " + type);
    	System.out.println("owner: " + owner);
    	System.out.println("element: " + element);
    	*/

		// Combine annotations
    	AnnotatedTypeMirror combinedType;
    	try {
    		combinedType = combineTypeWithType(owner, type);
    	} catch (ContextInTopAccessException exc) {
    		//TODO:
    		// It would have been nice to catch this this earlier so we can
    		// report exactly where the error occurred. To do that, we should
    		// eventually modify
    		// TypeFromTree$TypeFromExpression.visitMemberSelect
    		exc.report(element);
    		return;
    	}
		// System.out.println("combined type: " + combinedType);

		type.clearAnnotations();
		type.addAnnotations(combinedType.getAnnotations());
		// System.out.println("result: " + type.toString());

		// TODO: HACK: we needed to make setTypeArguments public to work
		// around a limitation of the framework.
		// If the method had a return value, like constructor/methodFromUse, we could probably get around this.

		if (type.getKind() == TypeKind.DECLARED
				&& combinedType.getKind() == TypeKind.DECLARED) {
			AnnotatedDeclaredType declaredType = (AnnotatedDeclaredType) type;
			AnnotatedDeclaredType declaredCombinedType = (AnnotatedDeclaredType) combinedType;
			declaredType.setTypeArguments(declaredCombinedType.getTypeArguments());
		} else if (type.getKind() == TypeKind.ARRAY
				&& combinedType.getKind() == TypeKind.ARRAY) {
			AnnotatedArrayType arrayType = (AnnotatedArrayType) type;
			AnnotatedArrayType arrayCombinedType = (AnnotatedArrayType) combinedType;
			arrayType.setComponentType(arrayCombinedType.getComponentType());
		}

		// System.out.println("out type: " + type);
    }

    private class ContextInTopAccessException extends Exception {
        public void report(Object tree) {
    		checker.report(Result.failure("access.top.context"), tree);
    	}
    }

	private AnnotatedTypeMirror combineTypeWithType(
			AnnotatedTypeMirror target, AnnotatedTypeMirror type) throws ContextInTopAccessException {

		AnnotationMirror targetam = target.getAnnotations().iterator().next();
        if (type.getAnnotations().isEmpty()) {
            // Type parameters (i.e. generics) have no annotations.
            return type;
        }
		AnnotationMirror typeam = type.getAnnotations().iterator().next();

		AnnotatedTypeMirror result = type.getCopy(true);

		// This is perhaps another framework bug: the annotations on a type
		// variable don't seem to be copied by type.getCopy(). This is also
		// unsound, but for now pass the type through unmodified.
		if (type instanceof AnnotatedTypeMirror.AnnotatedTypeVariable &&
				result.getAnnotations().isEmpty()) {
			return type;
		}

		// TODO: why is .equals directly not working?
		if (typeam.toString().equals(chk().CONTEXT.toString())) {

			// Don't allow @Top to substitute for @Context.
			if (targetam.toString().equals(chk().TOP.toString())) {
				throw new ContextInTopAccessException();
			}

			result.clearAnnotations();
			result.addAnnotation(targetam);
		}

		if (type.getKind() == TypeKind.DECLARED) {
            AnnotatedDeclaredType declaredType = (AnnotatedDeclaredType) result;

            if ( declaredType.getTypeArguments().size() > 0) {
            	Map<AnnotatedTypeMirror, AnnotatedTypeMirror> mapping = new HashMap<AnnotatedTypeMirror, AnnotatedTypeMirror>();

            	// Get the combined type arguments
            	for (AnnotatedTypeMirror typeArgument : declaredType.getTypeArguments()) {
            		AnnotatedTypeMirror recTypeArgument = combineTypeWithType(target, typeArgument);
            		mapping.put(typeArgument, recTypeArgument);
            	}

            	// Construct result type
            	result = result.substitute(mapping);
            }
		}
		if (type.getKind() == TypeKind.ARRAY) {
            // Create a copy
            AnnotatedArrayType  arrayType = (AnnotatedArrayType) result;

            AnnotatedTypeMirror elemType = arrayType.getComponentType().getCopy(true);

            AnnotationMirror elemam = elemType.getAnnotations().iterator().next();

    		// TODO: why is .equals directly not working?
    		if (elemam.toString().equals(chk().CONTEXT.toString())) {

    			// Don't allow @Top to substitute for @Context.
    			if (targetam.toString().equals(chk().TOP.toString())) {
    				throw new ContextInTopAccessException();
    			}

    			elemType.clearAnnotations();
    			elemType.addAnnotation(targetam);
    			arrayType.setComponentType(elemType);
    		}
        }

		return result;
	}

    /**
     * Returns a new Approx annotation with the given approx value
     */
    protected AnnotationMirror createApproxAnnotation(double value) {
        AnnotationBuilder builder =
            new AnnotationBuilder(processingEnv, Approx.class.getCanonicalName());
        builder.setValue("value", value);
        return builder.build();
    }

    @Override
    protected TreeAnnotator createTreeAnnotator() {
        return new PrecisionTreeAnnotator(this);
    }

    /**
     * Get the tree that corresponds to elt
     */
    public Tree getDeclarationFromElement(Element elt) {
        // Stick it to the man by revealing this protected final method
        return declarationFromElement(elt);
    }

    protected ClassTree getClassTree(Tree node) {
        return getCurrentClassTree(node);
    }

    protected TreePath getPathExpensive(Tree node) {
        return trees.getPath(root, node);
    }

	private class PrecisionTreeAnnotator extends TreeAnnotator {

		public PrecisionTreeAnnotator(AnnotatedTypeFactory typeFactory) {
			super(typeFactory);
		}

		/**
		 * Propagate information from the lhs and rhs of binary operations.
		 */
	    @Override
	    public Void visitBinary(BinaryTree node, AnnotatedTypeMirror type) {
	    	super.visitBinary(node, type);

            /*
            System.out.println("PATF visitBinary");
            System.out.println("node: " + node);
            System.out.println("type: " + type);
            */

	    	AnnotatedTypeMirror lhs = PrecisionAnnotatedTypeFactory.this.getAnnotatedType(node.getLeftOperand());
	    	AnnotatedTypeMirror rhs = PrecisionAnnotatedTypeFactory.this.getAnnotatedType(node.getRightOperand());

	    	// Pointer equality is always precise.
	    	if ((lhs.getKind() == TypeKind.DECLARED || lhs.getKind() == TypeKind.NULL) &&
	    			(rhs.getKind() == TypeKind.DECLARED || rhs.getKind() == TypeKind.NULL)&&
	    			(node.getKind() == Kind.EQUAL_TO || node.getKind() == Kind.NOT_EQUAL_TO)) {
	    		type.clearAnnotations();
	    		type.addAnnotation(chk().PRECISE);
	    		return null;
	    	}

	    	if ( lhs.getAnnotations().contains(chk().TOP) ||
	    			rhs.getAnnotations().contains(chk().TOP) ) {
	    		type.clearAnnotations();
	    		type.addAnnotation(chk().TOP);
            } else if (lhs.hasAnnotation(Dyn.class) || rhs.hasAnnotation(Dyn.class)) {
                // Result is dyn
                type.clearAnnotations();
                type.addAnnotation(chk().DYN);
	    	} else if ( lhs.hasAnnotation(Approx.class) ||
	    			rhs.hasAnnotation(Approx.class)) {
	    		type.clearAnnotations();
                // Calculate the probability that both values are correct
                double value = calculateBinaryApproxValue(lhs, rhs);
	    		type.addAnnotation(createApproxAnnotation(value));
	    	} else if ( lhs.getAnnotations().contains(chk().CONTEXT) ||
	    			rhs.getAnnotations().contains(chk().CONTEXT) ) {
	    		type.clearAnnotations();
	    		type.addAnnotation(chk().CONTEXT);
	    	}

	    	return null;
	    }

        /**
         * Given two AnnotatedTypeMirrors, determine the probability that the
         * result of a binary operation on these types is correct
         */
        private double calculateBinaryApproxValue(AnnotatedTypeMirror lhs,
                                                  AnnotatedTypeMirror rhs) {
            boolean leftIsApprox = lhs.hasAnnotation(Approx.class);
            boolean rightIsApprox = rhs.hasAnnotation(Approx.class);
            TypeKind lkind = lhs.getKind();
            TypeKind rkind = rhs.getKind();
            double approxValue;
            if (leftIsApprox && rightIsApprox) {
                double lval = chk().getApproxValue(lhs);
                double rval = chk().getApproxValue(rhs);
                approxValue = lval * rval;
                double[] args = {lval, rval};
            } else if (leftIsApprox) {
                approxValue = chk().getApproxValue(lhs);
            } else if (rightIsApprox) {
                approxValue = chk().getApproxValue(rhs);
            } else {
                throw new IllegalArgumentException(
                        "calculateBinaryApproxValue should only be called " +
                        "with at least one approx annotation");
            }
            if (lkind.isPrimitive() && rkind.isPrimitive())
                approxValue *= (1 - TIMING_ERROR_PROB_PERCENT / 100);
            return approxValue;
        }

	    @Override
	    public Void visitClass(ClassTree node, AnnotatedTypeMirror type) {
	    	for(TypeParameterTree tpt : node.getTypeParameters()) {
	    		if (tpt.getBounds().isEmpty()) {
	    			// No bounds.
	    			continue;
	    		}
	    		visitTypeParameter(tpt, fromTypeTree(tpt.getBounds().get(0)));
	    	}
	    	return super.visitClass(node, type);
	    }

	    @Override
	    public Void visitTypeParameter(TypeParameterTree node, AnnotatedTypeMirror type) {
	    	if (!type.getAnnotations().isEmpty()) {
	    		type.addAnnotation(chk().TOP);
	    	}
	    	return super.visitTypeParameter(node, type);
	    }

	}

    @Override
    protected Set<Class<? extends Annotation>> createSupportedTypeQualifiers() {
        Set<Class<? extends Annotation>> typeQualifiers
            = new HashSet<Class<? extends Annotation>>();

        typeQualifiers.add(Precise.class);
        typeQualifiers.add(Approx.class);
        typeQualifiers.add(Dyn.class);
        typeQualifiers.add(Context.class);

        // Always allow Top as top modifier, regardless of subtyping hierarchy
        // if(!getLintOption(STRELAXED, STRELAXED_DEFAULT)) {
        typeQualifiers.add(Top.class);

        return Collections.unmodifiableSet(typeQualifiers);
    }

    private final class PrecisionQualifierHierarchy extends GraphQualifierHierarchy {

        public PrecisionQualifierHierarchy(MultiGraphQualifierHierarchy.MultiGraphFactory f, javax.lang.model.element.AnnotationMirror bottom) {
            super(f, bottom);
        }

        @Override
        public boolean isSubtype(AnnotationMirror sub, AnnotationMirror sup) {
            if (AnnotationUtils.areSameIgnoringValues(sup, chk().TOP))
                return true;
            if (AnnotationUtils.areSameIgnoringValues(sub, chk().TOP))
                return false;

            if (AnnotationUtils.areSameIgnoringValues(sup, chk().DYN))
                return true;
            if (AnnotationUtils.areSameIgnoringValues(sub, chk().DYN))
                return false;

            // If both are approx, compare values
            if (AnnotationUtils.areSameIgnoringValues(sub, chk().APPROX) &&
                AnnotationUtils.areSameIgnoringValues(sup, chk().APPROX)) {
                double approxSup = getApproxValue(sup);
                double approxSub = getApproxValue(sub);
                if (Double.isNaN(approxSub) || Double.isNaN(approxSup))
                    return true;
                return approxSub <= approxSup;
            }

            // precise is a subtype of everything
            if (AnnotationUtils.areSameIgnoringValues(sub, chk().PRECISE))
                return true;

            // Strip values then compare types
            if (AnnotationUtils.areSameIgnoringValues(sub, chk().APPROX))
                sub = chk().APPROX;
            if (AnnotationUtils.areSameIgnoringValues(sup, chk().APPROX))
                sup = chk().APPROX;

            return super.isSubtype(sub, sup);
        }

        /**
         * Gets the value out of an approx annotation
         */
        private double getApproxValue(AnnotationMirror approx) {
            if (AnnotationUtils.areSameByClass(approx, Dyn.class))
                    throw new IllegalArgumentException("Tried to get approx value of a @Dyn");
            return (Double) AnnotationUtils.getElementValuesWithDefaults(approx).get(chk().approxValue).getValue();
        }
    }

    // The TypeHierarchy (unlike the QualifierHierarchy) makes judgments about
    // full Java types. We use this to change the behavior for primitive vs.
    // reference types.
    private final class PrecisionTypeHierarchy extends TypeHierarchy {
        public PrecisionTypeHierarchy(BaseTypeChecker checker,
                                      QualifierHierarchy qh) {
            super(checker, qh);
        }

        /**
         * For primitive types we allow an assignment from precise types to
         * approximate types.
         * In the other cases, follow the specified hierarchy in the qualifiers.
         */
        @Override
        public boolean isSubtype(AnnotatedTypeMirror sub,
                                 AnnotatedTypeMirror sup) {
            // Null is always a subtype of any reference type.
            if (sub.getKind() == TypeKind.NULL &&
                    (sup.getKind() == TypeKind.DECLARED || sup.getKind() == TypeKind.TYPEVAR)) {
                return true;
            }

            // TODO: I think this special case is only needed for the strict subtyping
            // option. But it also shouldn't break the relaxed subtyping hierarchy.
            if( sub.getUnderlyingType().getKind().isPrimitive() &&
                sup.getUnderlyingType().getKind().isPrimitive() ) {

                if (sup.hasAnnotation(Dyn.class) && !sub.hasAnnotation(Top.class))
                    return true;

                if (sub.hasAnnotation(Dyn.class) && !sup.hasAnnotation(Top.class))
                    return false;

                double approxSup = chk().getApproxValue(sup);
                double approxSub = chk().getApproxValue(sub);
                if (Double.isNaN(approxSub) || Double.isNaN(approxSup)) return true;

                if (sup.hasAnnotation(Approx.class) &&
                    sub.hasAnnotation(Approx.class)) {
                    return approxSup <= approxSub;
                }

                if ( sup.hasAnnotation(Approx.class) ||
                     sup.getAnnotations().contains(chk().TOP) ||
                     (sup.getAnnotations().contains(chk().CONTEXT) &&
                      sub.getAnnotations().contains(chk().PRECISE)) ||
                     sup.getAnnotations().equals(sub.getAnnotations())){
                    return true;
                } else {
                    return false;
                }
            }
            return super.isSubtype(sub, sup);
        }
    }

    @Override
    public QualifierHierarchy createQualifierHierarchy(
            MultiGraphQualifierHierarchy.MultiGraphFactory factory) {
        return new PrecisionQualifierHierarchy(factory, null);
    }

    @Override
    protected TypeHierarchy createTypeHierarchy() {
        return new PrecisionTypeHierarchy(chk(), getQualifierHierarchy());
    }
}
