package enerj.instrument;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Queue;

import javax.annotation.processing.ProcessingEnvironment;
import javax.lang.model.element.VariableElement;

import checkers.runtime.instrument.HelpfulTreeTranslator;

import org.checkerframework.framework.type.AnnotatedTypeMirror;
import org.checkerframework.framework.type.AnnotatedTypeMirror.AnnotatedArrayType;
import org.checkerframework.framework.type.AnnotatedTypeFactory;
import org.checkerframework.javacutil.TreeUtils;
import org.checkerframework.javacutil.ElementUtils;

import com.sun.source.tree.MethodTree;
import com.sun.source.util.TreePath;
import com.sun.tools.javac.code.Flags;
import com.sun.tools.javac.code.Symbol;
import com.sun.tools.javac.code.TypeTags;
import com.sun.tools.javac.tree.*;
import com.sun.tools.javac.tree.JCTree.JCExpression;
import com.sun.tools.javac.tree.JCTree.JCMethodDecl;
import com.sun.tools.javac.tree.JCTree.JCNewArray;
import com.sun.tools.javac.tree.JCTree.JCNewClass;
import com.sun.tools.javac.tree.JCTree.JCStatement;
import com.sun.tools.javac.util.List;

import enerj.PrecisionAnnotatedTypeFactory;
import enerj.PrecisionChecker;
import enerj.PrecisionVisitor;

// Adds calls to the runtime system to keep track of the dynamic precision
// state of each object as it is instantiated.
public class RuntimePrecisionTranslator extends HelpfulTreeTranslator<PrecisionChecker> {
    AnnotatedTypeFactory atypeFactory;

    private final Set<String> dyns;

    private String className;
    private JCTree.JCExpression dynExpr;
    private String dynVar;
    private boolean inDynFunction;
    private int infCheckCount;
    private Map<String, Queue<String>> invocations;

    public RuntimePrecisionTranslator(PrecisionChecker checker,
                                      ProcessingEnvironment env,
                                      TreePath p,
                                      Map<String, Queue<String>> invocations) {
        this(checker, env, p);
        this.invocations = invocations;
    }

    private RuntimePrecisionTranslator(PrecisionChecker checker,
                                      ProcessingEnvironment env,
                                      TreePath p) {
        super(checker, env, p);
        atypeFactory = checker.getVisitor().getTypeFactory();
        dyns = new HashSet<>();
        inDynFunction = false;
        infCheckCount = 0;
    }

    @Override
    public void visitNewClass(JCNewClass tree) {
    	super.visitNewClass(tree);

    	if (tree.clazz instanceof JCTree.JCIdent) {
    		Symbol sym = ((JCTree.JCIdent)tree.clazz).sym;
    		if ((sym.flags() & Flags.ENUM) != 0) {
    			// Instantiating an enum. Don't instrument.
    			return;
    		}
    	}

    	/*
    	 * We transform object instantiations
    	 *
    	 *   new @Mod C();
    	 *
    	 * to
    	 *
    	 *   wrappedNew(
    	 *     PrecisionRuntime.impl.beforeCreation(this, @Mod==@Approx),
    	 *     new @Mod C(),
    	 *     this
    	 *   );
    	 *
    	 * where
    	 *
    	 *   <T> T wrappedNew(boolean before, T created, Object creator) {
    	 *     PrecisionRuntime.impl.afterCreation(creator, created);
    	 *     return created;
    	 *   }
    	 *
    	 * The call to beforeCreation needs to happen before the real "new".
    	 * Therefore, we use it as the first argument in wrappedNew.
    	 * The call to afterCreation can happen directly after the "new", but needs
    	 * access to the newly created object. Therefore, instead of also making it an
    	 * argument, we call afterCreation in wrappedNew.
    	 *
    	 * In a static environment, instead of "this" we use the current Thread as creator.
    	 */
    	MethodTree enclMeth = TreeUtils.enclosingMethod(path);
    	boolean envIsStatic;
    	if (enclMeth==null) {
    		envIsStatic = true;
    	} else {
    		envIsStatic = ElementUtils.isStatic(TreeUtils.elementFromDeclaration(enclMeth));
    	}

    	JCTree.JCExpression beforeMeth = dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.beforeCreation");
        AnnotatedTypeMirror type = atypeFactory.getAnnotatedType(tree);
    	JCExpression isApprox;
        JCExpression isDyn;
        if ( type.hasEffectiveAnnotationRelaxed(checker.APPROX) ) {
        	isApprox = maker.Literal(true);
            isDyn = maker.Literal(false);
        } else if (type.hasEffectiveAnnotationRelaxed(checker.DYN)) {
            isApprox = maker.Literal(false);
            isDyn = maker.Literal(true);
        } else if ( type.hasEffectiveAnnotation(checker.CONTEXT) ) {
            throw new UnsupportedOperationException("@Context is not supported in DECAF");
            /*
        	JCTree.JCExpression curIsApproxMeth = dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.isApproximate");
        	isApprox = maker.Apply(null, curIsApproxMeth, List.of(thisExp()));
            */
        } else {
        	isApprox = maker.Literal(false);
            isDyn = maker.Literal(false);
        }

        int[] sizes = PrecisionChecker.objectSizes(
    	    type, atypeFactory, typeutils, checker
    	);
    	JCTree.JCExpression preciseSizeExp = maker.Literal(sizes[0]);
    	JCTree.JCExpression approxSizeExp  = maker.Literal(sizes[1]);

    	List<JCExpression> beforeArgs;
    	if (envIsStatic) {
        	JCTree.JCExpression curThreadMeth = dotsExp("Thread.currentThread");
        	JCTree.JCMethodInvocation curThreadCall = maker.Apply(null, curThreadMeth, List.<JCExpression>nil());

    		beforeArgs = List.of(curThreadCall, isApprox,
    		                     preciseSizeExp, approxSizeExp, isDyn);
    	} else {
    		beforeArgs = List.of(thisExp(), isApprox,
    		                     preciseSizeExp, approxSizeExp, isDyn);

    	}

    	JCTree.JCMethodInvocation beforeCall = maker.Apply(null, beforeMeth, beforeArgs);

    	JCTree.JCExpression wrappedNewMeth = dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.wrappedNew");
    	List<JCExpression> wrappedArgs;
    	if (envIsStatic) {
        	JCTree.JCExpression curThreadMeth = dotsExp("Thread.currentThread");
        	JCTree.JCMethodInvocation curThreadCall = maker.Apply(null, curThreadMeth, List.<JCExpression>nil());

    		wrappedArgs = List.of(beforeCall, tree, curThreadCall);
    	} else {
    		wrappedArgs = List.of(beforeCall, tree, thisExp());
    	}

    	JCTree.JCMethodInvocation wrappedCall = maker.Apply(
    	    null, wrappedNewMeth, wrappedArgs);

    	attribute(wrappedCall, tree);

    	this.result = wrappedCall;
    }

    private void giveTypeToNewArray(JCTree.JCExpression elemtype,
                                    JCTree.JCNewArray newArray) {
        if (newArray.getInitializers() != null && newArray.elemtype == null) {
            newArray.elemtype = elemtype;

            // Recurse if multidimensional array.
            for (JCTree.JCExpression elem : newArray.getInitializers())
                if (elem instanceof JCTree.JCNewArray)
                    giveTypeToNewArray(
                        ((JCTree.JCArrayTypeTree)elemtype).elemtype,
                        (JCTree.JCNewArray)elem
                    );
        }
    }

    @Override
    public void visitVarDef(JCTree.JCVariableDecl tree) {
        // Give explicit types to array literals.
        if (tree.init instanceof JCTree.JCNewArray)
            giveTypeToNewArray(((JCTree.JCArrayTypeTree)tree.vartype).elemtype,
                               (JCTree.JCNewArray)tree.init);

        // Log whether or not we have a dyn type
        AnnotatedTypeMirror type = atypeFactory.getAnnotatedType(tree);
        type = PrecisionVisitor.reduceArray(type);
        if (type.hasEffectiveAnnotationRelaxed(checker.DYN)) {
            boolean res = dyns.add(tree.getName().toString());
            if (!res) throw new AssertionError(tree.getName() + " already in dyns");
            dynExpr = tree.init;
            dynVar = tree.getName().toString();
        }

        super.visitVarDef(tree);
    }

    @Override
    public void visitAssign(JCTree.JCAssign tree) {
        String name = tree.lhs.toString().split("\\[")[0];
        if (dyns.contains(name)) {
            dynExpr = tree.rhs;
            dynVar = name;
        }

        super.visitAssign(tree);
    }

    @Override
    public void visitAssignop(JCTree.JCAssignOp tree) {
        String name = tree.lhs.toString().split("\\[")[0];

        super.visitAssignop(tree);

        if (dyns.contains(name)) {
            dynVar = name;
            wrapDyn(tree);
        }
    }

    private void wrapDyn(JCTree.JCExpression tree) {
        // Hacky way to wrap variable assignment in enterDyn/exitDyn
        List<JCTree.JCExpression> enterArgs = List.of(maker.Literal(dynVar == null ? "" : dynVar));
        JCTree.JCMethodInvocation enterDyn = maker.Apply(null,
                                                         dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.enterDyn"),
                                                         enterArgs);
        JCTree.JCExpression wrappedMeth = dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.exitDyn");
        List<JCExpression> wrappedArgs = List.of(enterDyn, tree);
        JCTree.JCMethodInvocation wrappedCall = maker.Apply(null,
                                                            wrappedMeth,
                                                            wrappedArgs);
        attribute(wrappedCall, tree);
        this.result = wrappedCall;
        dynExpr = null;
    }

    @Override
    public void visitLiteral(JCTree.JCLiteral tree) {
        super.visitLiteral(tree);
        if (tree.equals(dynExpr)) wrapDyn(tree);
    }

    @Override
    public void visitIdent(JCTree.JCIdent tree) {
        super.visitIdent(tree);
        if (tree.equals(dynExpr)) wrapDyn(tree);
    }

    @Override
    public void visitBinary(JCTree.JCBinary tree) {
        super.visitBinary(tree);
        if (tree.equals(dynExpr)) wrapDyn(tree);
    }

    @Override
    public void visitIndexed(JCTree.JCArrayAccess tree) {
        super.visitIndexed(tree);
        if (tree.equals(dynExpr)) wrapDyn(tree);
    }

    @Override
    public void visitClassDef(JCTree.JCClassDecl tree) {
        String old = className;
        className = tree.name.toString();

        super.visitClassDef(tree);

        className = old;
    }

    @Override
    public void visitApply(JCTree.JCMethodInvocation tree) {
        boolean checkedEndorse = tree.toString().contains("checked_endorse");

        if (checkedEndorse) {
            dynExpr = tree.args.head;
            dynVar = null;
        }

        super.visitApply(tree);

        AnnotatedTypeMirror type = atypeFactory.getAnnotatedType(tree);
        String typeName = type.toString();

        // Get function name with class name
        PrecisionAnnotatedTypeFactory patf = (PrecisionAnnotatedTypeFactory) atypeFactory;
        AnnotatedTypeMirror.AnnotatedExecutableType exMethod = atypeFactory.methodFromUse(tree).first;
        MethodTree method = (MethodTree) patf.getDeclarationFromElement(exMethod.getElement());
        String methodName = method == null ? null :
                                             className + "-" + method.getName().toString();
        Queue<String> methodInvocations = invocations.get(methodName);
        String internalName = method == null || methodInvocations == null ? "" : methodInvocations.remove();

        JCTree.JCMethodInvocation wrappedCall = null;
        if (tree.toString().contains("checked_endorse")) {
            // Replace call with checked endorse
            if (tree.args.length() == 2) {
                // Declared checked endorse
                wrappedCall = maker.Apply(null,
                                          dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.checkedEndorse"),
                                          tree.args);
            } else if (tree.args.length() == 1) {
                // Use string lookup method
                String varName = "inf*check*" + infCheckCount;
                ++infCheckCount;

                List<JCExpression> wrappedArgs = List.of(tree.args.get(0),
                                                         maker.Literal(varName));
                wrappedCall = maker.Apply(null,
                                          dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.checkedEndorse"),
                                          wrappedArgs);
            } else throw new AssertionError("Unexpected number of arguments to checked_endorse");

        } else if (!typeName.contains("void") &&
                   !typeName.contains("Object") &&
                   !tree.toString().startsWith("super(") &&
                   !tree.toString().startsWith("this(")) {
            // Wrap the function application
            List<JCExpression> enterArgs = List.of(maker.Literal(internalName));
            JCTree.JCMethodInvocation enterFun = maker.Apply(null,
                                                             dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.beforeApply"),
                                                             enterArgs);
            List<JCExpression> actuals = tree.args;
            java.util.List<? extends VariableElement> formals = exMethod.getElement().getParameters();

            for (int i = 0; i < actuals.size(); ++i) {
                List<JCExpression> args = List.of(enterFun,
                                                  maker.Literal(formals.get(i).toString()),
                                                  maker.Literal(actuals.get(i).toString()));
                enterFun = maker.Apply(null,
                                       dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.pairArgs"),
                                       args);
            }

            JCTree.JCExpression wrappedFun = dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.afterApply");
            String varName = tree.equals(dynExpr) ? dynVar : "";
            List<JCExpression> wrappedArgs = List.of(enterFun,
                                                     tree,
                                                     maker.Literal(varName));
            wrappedCall = maker.Apply(null, wrappedFun, wrappedArgs);
        } /* TODO: How do I make sure variables can be read in void functions?
        else {
            // General function wrapping
            List<JCExpression> args = List.of(maker.Literal(internalName));
            JCTree.JCMethodInvocation enterFun = maker.Apply(null,
                                                             dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.enterFunction"),
                                                             args);
            List<JCExpression> exitArgs = List.of(enterFun, tree);
            JCTree.JCExpression wrappedFun = dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.exitFunction");
            wrappedCall = maker.Apply(null, wrappedFun, exitArgs);
        }*/

        if (wrappedCall != null) {
            attribute(wrappedCall, tree);
            this.result = wrappedCall;
        }
    }

    @Override
    public void visitReturn(JCTree.JCReturn tree) {
        if (inDynFunction) {
            dynExpr = tree.expr;
            dynVar = null;
        }

        super.visitReturn(tree);
    }

    private final Set<JCTree.JCNewArray> subInits = new HashSet<JCTree.JCNewArray>();

    @Override
    public void visitNewArray(JCNewArray tree) {
        // Don't instrument array initializations inside of array
        // initialization literals.
        if (subInits.contains(tree)) {
            super.visitNewArray(tree);
            return;
        }
        if (tree.getInitializers() != null) {
            for (JCTree.JCExpression init : tree.getInitializers()) {
                if (init instanceof JCTree.JCNewArray) {
                    subInits.add((JCTree.JCNewArray)init);
                }
            }
        }

    	super.visitNewArray(tree);

    	// Translate array creations. We'll transform this expression:
    	//     new T[n]
    	// into this one:
    	//     enerj.rt.PrecisionRuntimeRoot.impl.newArray(
    	//          new T[n], 1, preciseElSize, approxElSize
        //     )

    	AnnotatedArrayType type =
    	    (atypeFactory.getAnnotatedType(tree));

    	// Recurse to true basic element type.
    	AnnotatedTypeMirror elType = type;
    	for (int i = 0; i < tree.dims.length(); ++i) {
    	    elType = ((AnnotatedArrayType)elType).getComponentType();
    	}
    	// ... and get the size of that element type.
        int[] sizes = PrecisionChecker.typeSizes(
            elType,
            true,
            checker
            // Get the approx-context size and switch to precise in precise
            // contexts (determined by call below).
        );

        JCTree.JCExpression isApprox;
        JCTree.JCExpression isDyn;
        if ( elType.hasEffectiveAnnotationRelaxed(checker.APPROX) ) {
        	isApprox = boolExp(true);
            isDyn = boolExp(false);
        } else if (elType.hasEffectiveAnnotationRelaxed(checker.DYN)) {
            isApprox = boolExp(false);
            isDyn = boolExp(true);
        } else if ( elType.hasEffectiveAnnotation(checker.CONTEXT) ) {
            throw new UnsupportedOperationException("@Context is not supported in DECAF");
            /*
        	isApprox = maker.Apply(null,
        	    dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.isApproximate"),
        	    List.of(thisExp())
        	);
            */
        } else {
        	isApprox = boolExp(false);
            isDyn = boolExp(true);
        }

    	JCTree.JCExpression call = maker.Apply(null,
    	    dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.newArray"),
    	    List.of(
    	        tree,
    	        maker.Literal(tree.dims.length()),
    	        isApprox,
    	        maker.Literal(sizes[0]),
    	        maker.Literal(sizes[1]),
                isDyn
    	    )
    	);
    	attribute(call, tree);
    	result = call;
    }

    @Override
    public void visitMethodDef(JCMethodDecl tree) {
        // Note if this function is dyn
        boolean prevDyn = inDynFunction;
        AnnotatedTypeMirror returnType = atypeFactory.getAnnotatedType(tree).getReturnType();
        if (returnType == null) inDynFunction = false;
        else {
            returnType = PrecisionVisitor.reduceArray(returnType);
            inDynFunction = returnType.hasEffectiveAnnotationRelaxed(checker.DYN);
        }

    	super.visitMethodDef(tree);

        dyns.clear();
    	if (TreeUtils.isConstructor(tree)) {
    		/*
    		 * We transform constructor definitions by adding as first statement:
    		 *
    		 *   PrecisionRuntime.impl.enterConstructor( this );
    		 */
    		JCTree.JCExpression enterSel = dotsExp("enerj.rt.PrecisionRuntimeRoot.impl.enterConstructor");
    		JCTree.JCMethodInvocation enterCall = maker.Apply(null, enterSel, com.sun.tools.javac.util.List.of(thisExp()));
    		JCTree.JCStatement enterStmt = maker.Exec(enterCall);

    		// Start attribution of the new AST part
    		attr.attribStat(enterStmt, getAttrEnv(tree));

    		List<JCStatement> stmts = tree.body.getStatements();
    		JCStatement first = stmts.head;

    		/*
    		// Did I really need to make sure that the first statement is a constructor call??
    		if (first instanceof JCExpressionStatement) {
    			JCExpression exp = ((JCExpressionStatement)first).getExpression();
        		if (exp instanceof JCMethodInvocation) {
        			JCExpression rcv = ((JCMethodInvocation) exp).getMethodSelect();
        			if (rcv instanceof JCIdent) {
        				Name n = ((JCIdent) rcv).getName();
        				if (!names.init.equals(n)) {
        					// error
        				}
        			} else {
        				// error
        			}
        		} else {
        			// error
        		}
    		} else {
    			// error
    		}
    		*/

    		// Change the constructor body
    		tree.body = maker.Block(0, List.of(first).appendList(stmts.tail.prepend(enterStmt)));
    	}

        inDynFunction = prevDyn;
    }
}
