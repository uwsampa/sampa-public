package enerj.lang;

public class PrecisionException extends RuntimeException {

    private final static long serialVersionUID = 1;

    public PrecisionException(double expected, double actual) {
        super("expected precision " + expected + " but got " + actual);
    }
}
