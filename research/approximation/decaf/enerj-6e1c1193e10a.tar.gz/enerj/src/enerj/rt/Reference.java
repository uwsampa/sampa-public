package enerj.rt;

import java.lang.ref.PhantomReference;

import enerj.PrecisionChecker;

public class Reference<T> {
    public T value;

    public boolean approx;
    public double approxValue;

    public boolean primitive; // Did we box a primitive type?

    public PhantomReference<Object> phantom;

    // Dummy reference for very short, temporary use
    public Reference(double approxValue) {
        this.approxValue = approxValue;
    }

    public Reference(T value, boolean approx, double approxValue,
                     boolean primitive, boolean dyn, String name) {
        if (dyn) approxValue = PrecisionRuntimeRoot.impl.resetDynVal();
        if (Double.isNaN(approxValue)) {
            // Look up approx value from name->value mapping
            if (dyn) throw new AssertionError("Dyn was NaN");
            approxValue = PrecisionRuntimeRoot.impl.getValue(name);
        }

        this.value = value;
        this.approx = approx;
        this.approxValue = approxValue;
        this.primitive = primitive;
        int[] sizes = PrecisionChecker.referenceSizes(this);
        phantom = PrecisionRuntimeRoot.impl.setApproximate(
            this, approx, false, sizes[0], sizes[1], dyn
        );

        PrecisionRuntimeRoot.impl.addRef(name, this);

    }

    public void destroy() {
        PrecisionRuntimeRoot.impl.endLifetime(phantom);
    }
}
