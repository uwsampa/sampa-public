package enerj.solver;

import com.sun.source.tree.MethodTree;
import com.sun.source.tree.VariableTree;
import com.sun.tools.javac.code.Type;
import com.sun.tools.javac.tree.JCTree;

import enerj.PrecisionVisitor;
import enerj.PrecisionVisitor.MetaMethodInvocation;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;


public class Z3Processor {
    public static final double EPSILON = 0.0001;

    private enum Result { SAT, UNSAT, TIMEOUT }

    private static final boolean DEBUG = true;
    private static final String NON_VAR_PREFIXES[] = {"op-",
                                                      "method-",
                                                      "inv-",
                                                      "obj-target",
                                                      "return-",
                                                      "inf-check-"};
    private static final double OBJECTIVE_EPSILON = 0.01;
    private static final long VAR_NUM_DELTA = 1000000;
    private static final int Z3_TIMEOUT_MS = 60 * 1000;
    private static final String ZEROS_ARR = "zeros";

    private final List<String> constraints;
    private final Map<MethodTree, Method> methods;
    private final Map<String, Scope> methodScopes;
    private final StringBuilder savedConstraints;
    private final List<String> savedVars;
    private final Stack<String> tmpVars;
    private final Stack<Scope> varScopes;
    private final List<String> wildcardVars;

    private boolean approx;
    private List<Scope> containedScopes;
    private Method currentMethod;
    private double[] levels;
    private Process proc;
    private double returnValue;
    private boolean save;
    private int scopeNum;
    private BufferedReader stdOut;
    private BufferedWriter stdIn;
    private long varNum;
    private Scope vars;

    /**
     * Construct a new Z3Processor
     */
    public Z3Processor() {
        // Start a z3 process
        createProc();

        constraints = new ArrayList<String>();
        methods = new HashMap<>();
        methodScopes = new HashMap<>();
        save = false;
        savedConstraints = new StringBuilder();
        savedVars = new ArrayList<String>();
        scopeNum = 0;
        tmpVars = new Stack<String>();
        vars = new Scope(null, null);
        varNum = VAR_NUM_DELTA;
        varScopes = new Stack<Scope>();
        wildcardVars = new ArrayList<String>();
        init();
    }

    public void declareLevels(double[] levels) {
        this.levels = levels;
    }

    private void createProc() {
        // Start a z3 process
        ProcessBuilder pb = new ProcessBuilder("z3", "-smt2", "-in");
        pb.redirectErrorStream(true);
        try {
            proc = pb.start();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        stdOut = new BufferedReader(new InputStreamReader(proc.getInputStream()));
        stdIn = new BufferedWriter(new OutputStreamWriter(proc.getOutputStream()));

    }

    /**
     * Initialize a "blank" z3 session
     */
    private void init() {
        constraints.clear();
        containedScopes = new ArrayList<Scope>();
        tmpVars.clear();
        disableApproxOps();
        wildcardVars.clear();
        returnValue = -1.0;
        // use faster non-linear arithmatic engine
        writeLine("(set-option :produce-proofs false)");
    }

    public void declareZeros() {
        writeLine("(declare-const " + ZEROS_ARR + " (Array Int Real))");
        writeLine("(assert (= " + ZEROS_ARR + " ((as const (Array Int Real)) 0)))");
    }

    /**
     * Clear the state accumulated in this Z3 session and start over
     */
    public void clearState() {
        writeLine("(reset)");
        init();
        writeLine(savedConstraints.toString());
    }

    /**
     * Enable or disable constraint saving
     */
    public void saveConstraints(boolean save) {
        System.out.println("Setting save to: " + save);
        this.save = save;
    }

    /**
     * Pushes the current scope onto the scope stack and creates a new one
     */
    public String pushScope(String name) {
        name += "s" + scopeNum++ + "-";
        System.out.println("pushing scope for " + name);
        varScopes.push(vars);
        vars = new Scope(name, vars);
        containedScopes.add(vars);
        return name;
    }

    public void popScope() {
        System.out.println("popping scope");
        try {
            vars = varScopes.pop();
        } catch (EmptyStackException e) {
            throw new RuntimeException("Not enough scopes");
        }
    }

    public String getScopeName() { return vars.name; }

    public void setScope(int scope) {
        pushScope(null);
        try {
            vars = varScopes.get(scope);
        } catch (ArrayIndexOutOfBoundsException exc) {
            throw new RuntimeException("Not enough scopes");
        }
    }

    public int getScopeNumber() {
        return varScopes.size();
    }

    public void pushZ3() { writeLine("(push)"); }
    public void popZ3() { writeLine("(pop)"); }

    public int enterMethod(MethodTree invocation) {
        if (currentMethod != null)
            throw new IllegalStateException("Already in a method");

        // See if we already have a copy of this method
        Method method = methods.get(invocation);
        if (method == null) {
            method = new Method(invocation);
            methods.put(invocation, method);
        }
        currentMethod = method;
        ++method.enterCount;

        // Push data about this method so we can pop it off if it is
        // unsatisfiable
        writeLine("(push)");

        return method.enterCount;
    }

    public void exitMethod() {
        exitMethod(checkSat() == Result.SAT);
    }

    public Scope getScopeFromMethodName(String name) {
        Scope ret = methodScopes.get(name);
        if (ret == null)
            throw new IllegalArgumentException(name + " not a declared method name");
        return methodScopes.get(name);
    }

    public int timesChecked(MethodTree meth) {
        Method method = methods.get(meth);
        if (method == null) return 0;
        if (method.equals(currentMethod))
            throw new IllegalArgumentException("Currently checking method " + meth);
        return method.enterCount;
    }

    public void exitMethod(boolean sat) {
        if (currentMethod == null) throw new IllegalStateException("Not in method");
        currentMethod = null;
        if (!sat) {
            // Method is unsatisfiable, throw away data so we can continue to
            // check the rest of the program
            writeLine("(pop)");
            popScope();
        }
    }

    /**
     * Execute the query being built up.
     *
     * Returns the approximate value of a binary operator, or NaN if the query
     * is unsatisfiable.  Calling this method does NOT clear the state of the
     * Z3 session.
     */
    public QueryResult executeQuery() {
        return executeQuery(checkSat() == Result.SAT);
    }

    /**
     * Execute the query, returning null on timeout.
     */
    public QueryResult executeQuery(int timeout) {
        Result res = checkSat(timeout);
        if (res == Result.TIMEOUT) {
            return null;
        }
        return executeQuery(res == Result.SAT);
    }

    /**
     * Like unparameterized executeQuery, but assumes checkSat() already run
     * and the result passed in through sat.
     */
    private QueryResult executeQuery(boolean sat) {
        if (!sat) return QueryResult.FAILURE;

        List<String> realVars = new ArrayList<>();
        for (String str : wildcardVars) {
            if (isVar(str)) realVars.add(str);
        }

        List<String> zeros = checkZero(realVars);
        List<String> ones = checkOne(realVars);
        if (checkSat() != Result.SAT) throw new AssertionError("!sat");
        linearOptimize();
        if (checkSat() != Result.SAT) throw new AssertionError("!sat");
        Map<String, Double> wildcardValues = getWildcardValues(wildcardVars);

        return new QueryResult(sat, zeros, ones, wildcardValues, vars, containedScopes);
    }

    /**
     * Checks for unconstrained variables and returns a list of them
     */
    public List<String> checkZero(List<String> vars) {
        List<String> ret = new ArrayList<>();
        if (vars.isEmpty()) return ret;

        writeLine("(push)");

        // Generate constraint
        StringBuilder constraint = new StringBuilder("(assert (or");
        for (String var : vars) {
            // Bind to 0.0
            constraint.append(" (= ").append(var).append(" 0.0)");
        }
        constraint.append("))");
        writeLine(constraint.toString());

        if (checkSat(true) == Result.SAT) {
            // At least one variable is underconstrained, find it
            Map<String, Double> vals = getWildcardValues(vars);

            for (Map.Entry<String, Double> val : vals.entrySet()) {
                String name = val.getKey();
                if (isVar(name) && val.getValue() < EPSILON) ret.add(val.getKey());
            }

            if (ret.isEmpty()) throw new AssertionError("ret.size() == 0");
        }

        writeLine("(pop)");
        return ret;
    }

    /**
     * Checks for over-constrained variables and returns a list of possible
     * candidates
     */
    public List<String> checkOne(List<String> vars) {
        List<String> ret = new ArrayList<>();
        if (vars.isEmpty()) return ret;

        writeLine("(push)");

        // Generate constraint
        StringBuilder constraint = new StringBuilder("(assert (and");
        for (String var : vars) {
            // Set exclusive upper bound to 1.0
            constraint.append(" (< ").append(var).append(" 1.0)");
        }
        constraint.append("))");
        writeLine(constraint.toString());

        Result sat = checkSat(true);
        writeLine("(pop)");

        if (sat == Result.UNSAT) {
            // Re-check sat after popping to get wildcard values
            sat = checkSat();
            if (sat == Result.UNSAT) throw new AssertionError("!sat");

            // Find candidates
            Map<String, Double> vals = getWildcardValues(vars);

            for (Map.Entry<String, Double> val : vals.entrySet()) {
                if (val.getValue() > 1.0 - EPSILON) ret.add(val.getKey());
            }

            if (ret.isEmpty()) throw new AssertionError("ret.size() == 0");
        }

        return ret;
    }

    public void addInvocation(MetaMethodInvocation inv) {
        Method method = methods.get(inv.method);
        if (method == null) {
            // Create a method and add it to the methods map
            method = new Method(inv);
            methods.put(inv.method, method);
        } else method.invocations.add(inv);
    }

    /**
     * Get all of the values from wildcards
     */
    private Map<String, Double> getWildcardValues(List<String> vars) {
        Map<String, Double> ret = new HashMap<>();
        try {
            // Get values of wildcard variables (includes operators)
            for (String var : vars) {
                writeLine("(get-value (" + var + "))", false);
                stdIn.flush();
                double value = parseResult(stdOut.readLine());
                ret.put(var, value);
            }
        } catch(IOException e) {
            throw new RuntimeException(e);
        }
        return ret;
    }

    private boolean isVar(String name) {
        for (String nonVar : NON_VAR_PREFIXES) {
            if (name.startsWith(nonVar)) return false;
        }
        return true;
    }

    /**
     * Declare a variable to the solver without binding it to a value
     *
     * @param name The name of the variable being declared
     */
    private String declareUnboundedVariable(String name) {
        if (save) savedVars.add(name);
        Long count = vars.get(name);
        if (count == null) count = varNum;
        else {
            long scopedCount = count % VAR_NUM_DELTA;
            count = varNum + scopedCount + 1;
        }
        varNum += VAR_NUM_DELTA;
        vars.put(name, count);
        name += "-" + count;
        writeLine("(declare-const " + name  + " Real)");

        if (name.startsWith("method-")) methodScopes.put(name, vars);

        return name;
    }

    /**
     * Declare a variable to the solver
     *
     * @param name The name of the variable being declared
     * @param value The approx value of the variable or NaN if variable is not
     *              approximate
     */
    public String declareVariable(String name, double value) {
        name = declareUnboundedVariable(name);

        if (Double.isNaN(value)) {
            if (levels != null && name.startsWith("op")) {
                // Use discrete levels
                writeLine("(assert (or");
                for (double level : levels) {
                    writeLine("(= " + name + " " + level + ")");
                }
                writeLine("))");
            } else {
                // Use continuous approximation
                writeLine("(assert (>= " + name + " 0.0))");
                writeLine("(assert (<= " + name + " 1.0))");
            }
            if (!name.startsWith("tmp-") && !name.startsWith("return-"))
                wildcardVars.add(name);
        }
        else writeLine("(assert (= " + name + " " + value + "))");

        return name;
    }

    /**
     * Returns whether or not name has been declared as a variable
     *
     * @return true iff name has been declared previously
     */
    public boolean variableDeclared(String name) {
        return vars.containsVar(name);
    }

    /**
     * Get the internal name for varNum
     *
     * @param varName the variable to get the internal name for
     * @throws NoSuchVariableException if varName couldn't be found
     * @return internal name of varName
     */
    public String getInternalName(String varName) {
        Long count = vars.get(varName);
        if (count == null)
            throw new NoSuchVariableException("Unknown variable " + varName);
        return varName + "-" + count;
    }

    private void handleLastTmp(String varName,
                               boolean internalName,
                               String op,
                               boolean doAssert) {
        if (tmpVars.isEmpty())
            throw new IllegalStateException("Too few temporary variables declared");
        if (!internalName) varName = getInternalName(varName);

        String lastTmp = tmpVars.pop();
        // Aggressively approximate method returns
        if (doAssert)
            writeLine("(assert (" + op + " " + varName + " " + lastTmp + "))");
        else writeLine("(" + op + " " + varName + " " + lastTmp + ")");
    }

    /**
     * Assign the last generated temporary variable to varName
     *
     * @param varName Name of variable to assign last temporary to
     */
    public void assignLastTmp(String varName, boolean internalName) {
        handleLastTmp(varName, internalName, "<=", true);
    }

    public void referenceLastTmp(String varName, boolean internalName) {
        handleLastTmp(varName, internalName, "=", true);
    }

    /**
     * Handles binary operator on last two temp values
     */
    public void binaryOp(int pos) {
        binaryOp(pos, approx, 0.0);
    }

    public void binaryOp(int pos, boolean isApprox, double explicitProb) {
        if (tmpVars.size() < 2)
            throw new IllegalStateException("Two few temporary variables declared");
        String left = tmpVars.pop();
        String right = tmpVars.pop();
        String res = initTmp();
        String line = "(assert (= " + res + " (* " + left + " " + right;
        String op = "op-" + vars.name + "-" + pos;
        String opDecl = null;
        if (isApprox) {
            opDecl = declareVariable(op, Double.NaN);
            line += " " + opDecl;
        }
        line += ")))";
        writeLine(line);

        if (explicitProb != 0.0) {
            String eLine = "(assert (>= " + opDecl + " " + explicitProb + "))";
            writeLine(eLine);
        }
    }

    public void setApproxOps(boolean approx) {
        if (DEBUG) System.out.println("Setting approx to: " + approx);
        this.approx = approx;
    }

    /**
     * Makes all operations approximate from this point on.
     *
     * For example, this would be called at the start of visitVariable if the
     * variable is determined to be approximate
     */
    public void enableApproxOps() {
        if (DEBUG) System.out.println("Enabling Approx");
        approx = true;
    }

    /**
     * Makes all operations precise from this point on
     */
    public void disableApproxOps() {
        if (DEBUG) System.out.println("Disabling Approx");
        approx = false;
    }

    /**
     * Initialize a new temporary variable with approx value "value"
     *
     * @param value Approx value of the new temp variable
     * @return The number of the temp variable
     */
    public String initTmp(double value) {
        String name = declareVariable("tmp-", value);
        tmpVars.push(name);
        return name;
    }

    /**
     * Initialize a new temporary variable without any associated approx value
     *
     * @return The number of the temp variable
     */
    public String initTmp() {
        return initTmp(Double.NaN);
    }

    /**
     * Push a variable onto the tmp var stack
     *
     * @throws IllegalArgumentException if var is not a declared variable
     */
    public void pushVar(String var, boolean internalName) {
        if (!internalName) var = getInternalName(var);
        tmpVars.push(var);
    }

    /**
     * Declare return precision from method signature
     *
     * @param value Approx value for method return
     */
    public String declareReturn(String name, double value, boolean isArray) {
        returnValue = value;
        String internalName = declareVariable(name, value);
        if (currentMethod != null) {
            currentMethod.addName(internalName);
            currentMethod.isArray(isArray);
        }
        return internalName;
    }

    /**
     * Assign the last temp to the return value
     *
     * @Deprecated Use assignLastTmp with the generated return name instead
     */
    @Deprecated
    public void assignReturn() {
        assignLastTmp("return-", false);
    }

    public boolean returnIsApprox() {
        return Math.abs(returnValue - 1.0) > EPSILON;
    }

    /**
     * Gets the inferred value of a variable
     *
     * @deprecated This method locks in the value for var in Z3, it should be
     *             avoided as much as possible.
     * @param var Variable to lookup value for
     * @returns the inferred value for var
     */
    @Deprecated
    private double getValue(String var, boolean fromInternalName) {
        if (!fromInternalName) var = getInternalName(var);

        // Lookup inferred value
        // TODO: Is -1 a good error value to return here?  Do I need to change
        // how the visitor handles this return?
        if (checkSat() != Result.SAT) return -1;
        writeLine("(get-value (" + var + "))");
        String line;
        try {
            stdIn.flush();
            line = stdOut.readLine();
        } catch (IOException e) { throw new RuntimeException(e); }
        return parseResult(line);
    }

    public String getLastTmp() {
        try {
            return tmpVars.pop();
        } catch (EmptyStackException e) {
            throw new IllegalStateException("No temporary variables declared");
        }
    }

    public void dumpStack() {
        System.out.println("BEGIN STACK DUMP");
        for (String var : tmpVars) {
            System.out.println(var);
        }
        System.out.println("END STACK DUMP");
    }

    public Collection<Method> getMethods() {
        return methods.values();
    }

    public int getStackSize() {
        return tmpVars.size();
    }

    private void optimizeObjective() {
        // Filter operators
        List<String> ops = new ArrayList<String>();
        for (String var : wildcardVars) if (var.startsWith("op-")) ops.add(var);

        if (ops.isEmpty()) return;

        double target = 0.5;
        double diff = 0.25;
        Result last = Result.UNSAT;
        double lastSat = -1.0;
        String objTarget = buildObjective(ops);
        writeLine("(push)");
        while (diff > OBJECTIVE_EPSILON) {
            writeLine("(pop)");
            writeLine("(push)");
            writeLine("(assert (<= " + objTarget + " " + target + "))");
            last = checkSat(true);
            if (last != Result.SAT) {
                // Reduce the target
                lastSat = target;
                target -= diff;
            } else
                // Increase the target
                target += diff;
            diff /= 2;
        }
        if (last != Result.SAT) {
            // unsat, throw out objective
            writeLine("(pop)");
            if (lastSat > 0) writeLine("(assert (<= " + objTarget + " " + lastSat + "))");
        }
    }

    private void linearOptimize() {
        // Filter operators
        List<String> ops = new ArrayList<String>();
        for (String var : wildcardVars) if (var.startsWith("op-")) ops.add(var);

        if (ops.isEmpty()) return;

        pushZ3();
        String objTarget = buildObjective(ops);
        if (checkSat(true) != Result.SAT) {
            // Just generating the unbounded objTarget can mess up z3
            // sometimes!
            popZ3();
            return;
        }
        for (double i = 1.0; i >= 0.0; i -= OBJECTIVE_EPSILON) {
            writeLine("(push)");
            writeLine("(assert (<= " + objTarget + " " + i + "))");
            if (checkSat(true) != Result.SAT) {
                // unsat, throw out last objective
                writeLine("(pop)");
                break;
            }
        }

    }

    /**
     * Generates an objective and returns the name of the variable it is bound
     * to
     */
    private String buildObjective(List<String> ops) {
        // Generate objective
        String objTarget = declareUnboundedVariable("obj-target");
        StringBuilder line = new StringBuilder();
        line.append("(assert (= ").append(objTarget).append(" (/ (+");
        for (String op : ops) line.append(" ").append(op);
        line.append(") ").append(ops.size()).append(")))");
        writeLine(line.toString());
        return objTarget;
    }

    private Result checkSat() {
        return checkSat(false);
    }

    private void restart() {
        // Solver hates us, kill it.
        proc.destroy();
        createProc();

        // Restore all but the last constraint
        //constraints.remove(constraints.size() - 1);
        for (String constraint : constraints) {
            writeLine(constraint, false);
        }
    }

    /**
     * Checks the satisfiability of the constraints
     *
     * @param timeout Whether or not to enforce the Z3 timeout
     * @return True if constraints are satisfiable
     */
    private Result checkSat(boolean timeout) {
        return checkSat(timeout ? Z3_TIMEOUT_MS : 0);
    }

    private Result checkSat(int timeout) {
        try {
            // Tell z3 to check-sat
            writeLine("(check-sat)", false);
            stdIn.flush();

            long start = System.currentTimeMillis();
            boolean stopped = false;
            while (timeout != 0 && !stdOut.ready()) {
                long now = System.currentTimeMillis();
                if (now - start > 2 * timeout) {
                    if (DEBUG) System.out.println("Z3 ignored signal, terminating");
                    restart();
                    return Result.TIMEOUT;

                } else if (!stopped && now - start > timeout) {
                    // Ask the solver to stop
                    if (DEBUG) System.out.println("Z3 timeout, asking to continue");
                    int pid = getPid();
                    Runtime.getRuntime().exec("kill -2 " + pid);
                    stopped = true;
                }

                /*
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {}
                */
            }

            // Analyze result
            String res = stdOut.readLine();
            if (res == null) {
                // Z3 died
                restart();
                return Result.TIMEOUT;
            }
            if (stdOut.ready()) throw new AssertionError("stdout is out of sync!");
            if (DEBUG) System.out.println(res);
            if (stopped) return Result.TIMEOUT;
            if (res.equals("sat")) return Result.SAT;
            return Result.UNSAT;
        } catch (IOException e) { throw new RuntimeException(e); }
    }

    private int getPid() {
        try {
            Field f = proc.getClass().getDeclaredField("pid");
            f.setAccessible(true);
            return f.getInt(proc);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Given a result string from z3 in the format:
     *     ((op (/ 30.0 49.0)))
     *     or
     *     ((op 0.0))
     * returns the double representation of op
     */
    private double parseResult(String result) {
        if (DEBUG) System.out.println(result);

        String[] tokens = result.split(" ");

        if (tokens.length == 2)
            // result looks like ((op 0.0))
            return Double.parseDouble(tokens[1].replace(")", ""));

        // result looks like ((op (/ 30.0 49.0)))
        assert tokens.length == 4;

        double numerator = Double.parseDouble(tokens[2]);
        double denominator = Double.parseDouble(tokens[3].replace(")", ""));
        return numerator / denominator;
    }

    private void debugCheck() {
        if (checkSat() != Result.SAT) {
            System.err.println("Debug check failed!");
            Thread.dumpStack();
            System.exit(1);
        }
    }

    /**
     * Sends line to Z3, appending a newline at the end.
     *
     * Does NOT flush the stdin buffer
     * log parameter determines whether or not the line should be saved in the
     * constraints list
     */
    private void writeLine(String line, boolean log) {
        if (DEBUG) System.out.println(line);
        if (save) savedConstraints.append('\n').append(line);
        if (log) constraints.add(line);
        try {
            stdIn.write(line);
            stdIn.newLine();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Sends line to Z3, appending a newline at the end.
     *
     * Does NOT flush the stdin buffer
     */
    private void writeLine(String line) {
        writeLine(line, true);
    }

    public static class Scope {
        public final String name;
        public final Scope parent;
        public final Map<String, Long> vars;

        Scope(String name, Scope parent) {
            this.name = name;
            this.parent = parent;
            this.vars = new HashMap<>();
        }

        Long get(String var) {
            Long ret = vars.get(var);
            if (ret == null) {
                if (parent == null) return null;
                else return parent.get(var);
            } else return ret;
        }

        void put(String var, Long num) {
            vars.put(var, num);
        }

        boolean containsVar(String var) {
            return vars.containsKey(var);
        }
    }

    public static class QueryResult {
        private static final QueryResult FAILURE = new QueryResult(false, null, null, null, null, null);

        public final boolean sat;
        public final List<String> zeros;
        public final List<String> possibleOnes;
        public final Map<String, Double> wildcardVars;
        public final Scope scope;
        public final List<Scope> containedScopes;

        private QueryResult(boolean sat,
                            List<String> zeros,
                            List<String> possibleOnes,
                            Map<String, Double> wildcardVars,
                            Scope scope,
                            List<Scope> containedScopes) {
            this.sat = sat;
            this.zeros = zeros;
            this.possibleOnes = possibleOnes;
            this.wildcardVars = wildcardVars;
            this.scope = scope;
            this.containedScopes = containedScopes;

            // Remove duplicates
            for (Scope i = scope; i != null; i = i.parent)
                containedScopes.remove(i);
        }

        public Set<Map.Entry<String, Double>> entrySet() {
            return wildcardVars.entrySet();
        }

        public Double get(String var) { return wildcardVars.get(var); }

    }

    public class Method {
        public final List<MetaMethodInvocation> invocations;
        public final MethodTree method;
        public final List<String> names;

        private boolean array;
        private int enterCount;
        public int enterCount() { return enterCount; }

        public Method(MetaMethodInvocation inv) {
            this(inv.method);
            invocations.add(inv);
        }

        public Method(MethodTree meth) {
            invocations = new ArrayList<>();
            method = meth;
            names = new ArrayList<>();
        }

        public void addName(String name) { names.add(name); }

        @Override
        public boolean equals(Object obj) {
            if (invocations.isEmpty())
                throw new AssertionError("invocations.size() == 0");

            if (!(obj instanceof Method)) return false;
            Method other = (Method) obj;
            return method.equals(other.method);
        }

        @Override
        public int hashCode() {
            return method.hashCode();
        }

        public void isArray(boolean array) { this.array = array; }
        public boolean isMethodChecked() { return !names.isEmpty(); }

        @Deprecated
        public void clearInvocations() {
            if (!isMethodChecked())
                throw new IllegalStateException("These invocations have certainly not been checked");
            invocations.clear();
        }

        public void emitConstraints() {
            if (!isMethodChecked())
                throw new IllegalStateException("Method not yet checked");
            String arrName = method.getName().toString() + Math.random();

            // Bind actual parameters to formal parameters
            // formal parameters shall have the name p0-name, p1-name, ...
            // actual parameters shall use the internal solver variable names
            List<? extends VariableTree> params = method.getParameters();
            for (int h = 0; h < invocations.size(); ++h) {
                MetaMethodInvocation inv = invocations.get(h);

                // Declare the virtual selection array
                //writeLine("(declare-const " + arrName + "-arr" + h + " (Array Int Real))");
                for (int i = 0; i < names.size(); ++i) {
                    writeLine(String.format("(declare-const %s-arr-%d-%d Real)",
                                            arrName,
                                            h,
                                            i));
                }

                // Use invChoice to figure out which scenario Z3 chose
                String invChoice = declareUnboundedVariable("inv-" + inv.varName);
                wildcardVars.add(invChoice);
                writeLine("(assert (or"); // All possible invocations in an or
                for (int i = 0; i < names.size(); ++i) {
                    writeLine("(and"); // lock method parameters together
                    writeLine("(= " + invChoice + " " + (i+1) + ")");

                    // Bind parameters
                    for (int j = 0; j < inv.parameters.length; ++j) {
                        String name = generateParamName(i, j);
                        VariableTree formal = params.get(j);
                        pushVar(inv.parameters[j], true);
                        JCTree.JCVariableDecl jvar = (JCTree.JCVariableDecl) formal;
                        boolean isArray = jvar.type instanceof Type.ArrayType;
                        if (isArray) handleLastTmp(name, false, "=", false);
                        else handleLastTmp(name, false, "<=", false);

                        if (inv.superMethod != null) {
                            // Bind params with super.method
                            Method parent = methods.get(inv.superMethod.method);
                            if (parent == null) throw new AssertionError("parent == null");
                            String supParam = parent.generateParamName(i, j);
                            // Subtype has to be <= supertype
                            pushVar(supParam, false);
                            if (isArray) handleLastTmp(name, false, "=", false);
                            else handleLastTmp(name, false, "<=", false);
                        }
                    }

                    // Set virtual array to indicate method choice
                    /*
                    writeLine(String.format("(= %s-arr%d (store %s %d 1.0))",
                                            arrName,
                                            h,
                                            ZEROS_ARR,
                                            i));
                                            */
                    for (int j = 0; j < names.size(); ++j) {
                        writeLine(String.format("(= %s-arr-%d-%d %s)",
                                                arrName,
                                                h,
                                                j,
                                                j == i ? "1.0" : "0.0"));
                    }

                    // Bind return value
                    pushVar(names.get(i), true);
                    if (array) handleLastTmp(inv.varName, true, "=", false);
                    else handleLastTmp(inv.varName, true, "<=", false);
                    writeLine(")"); // Close and
                }
                writeLine("))"); // Close or
                checkSat();
            }

            if (!invocations.isEmpty()) {
                // Force binding of all invocations Think of the arrays stacked up
                // as a matrix, with invocations on the y side (invocations), and x
                // side (names).  If k is 3 and there are 5 invocations, it looks
                // something like this
                // [x, x, x]
                // [x, x, x]
                // [x, x, x]
                // [x, x, x]
                // [x, x, x]
                for (int i = 0; i < names.size(); ++i) {
                    // Column-by-column processing

                    // Assert that at least ONE element in column i is 1
                    writeLine("(assert (or");
                    for (int j = 0; j < invocations.size(); ++j) {
                        /*
                        writeLine(String.format("(= (select %s-arr%d %d) 1.0)",
                                                arrName,
                                                j,
                                                i));
                                                */
                        writeLine(String.format("(= %s-arr-%d-%d 1.0)",
                                                arrName,
                                                j,
                                                i));
                    }
                    writeLine("))");

                }
            }
        }

        private String stripObfuscation(String var) {
            return var.substring(0, var.lastIndexOf("-"));
        }

        private String generateParamName(int i, int j) {
            return "p" + j + "-" + stripObfuscation(names.get(i)) + (i+1) + "--";
        }
    }

    private class NoSuchVariableException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        NoSuchVariableException(String message) { super(message); }
    }
}
