import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Print out the vars.ser data
 */
public class PrintSer {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        FileInputStream fileIn = new FileInputStream(args[0]);
        ObjectInputStream in = new ObjectInputStream(fileIn);
        Map<String, Map<String, Double>> vars = (HashMap<String, Map<String, Double>>) in.readObject();
        in.close();
        fileIn.close();

        for (Map.Entry<String, Map<String, Double>> entries : vars.entrySet()) {
            System.out.println(entries.getKey());
            for (Map.Entry<String, Double> entry : entries.getValue().entrySet()) {
                System.out.printf("\t%s : %f\n", entry.getKey(), entry.getValue());
            }
        }
    }
}
