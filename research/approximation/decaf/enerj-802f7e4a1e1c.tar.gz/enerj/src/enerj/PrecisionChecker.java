package enerj;

import java.lang.annotation.Annotation;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.processing.ProcessingEnvironment;
import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.TypeKind;
import javax.lang.model.util.ElementFilter;
import javax.lang.model.util.Types;

import org.checkerframework.common.basetype.BaseTypeChecker;
import org.checkerframework.common.basetype.BaseTypeVisitor;
import org.checkerframework.framework.qual.TypeQualifiers;
import checkers.runtime.InstrumentingChecker;
import checkers.runtime.instrument.InstrumentingTranslator;
import org.checkerframework.framework.source.SupportedLintOptions;
import org.checkerframework.framework.type.AnnotatedTypeMirror;
import org.checkerframework.framework.type.AnnotatedTypeMirror.AnnotatedDeclaredType;
import org.checkerframework.framework.type.AnnotatedTypeMirror.AnnotatedExecutableType;
import org.checkerframework.javacutil.AnnotationUtils;
import org.checkerframework.javacutil.ElementUtils;
import org.checkerframework.javacutil.TreeUtils;
import org.checkerframework.framework.type.AnnotatedTypeFactory;

import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.util.TreePath;
import com.sun.tools.javac.tree.JCTree;
import com.sun.source.tree.BinaryTree;

import enerj.instrument.RuntimePrecisionTranslator;
import enerj.instrument.SimulationTranslator;
import enerj.instrument.ConstructorTranslator;
import enerj.lang.*;
import enerj.rt.Reference;

/**
 * The precision type checker.
 */
@TypeQualifiers({Approx.class, Precise.class, Dyn.class, Top.class, Context.class})
@SupportedLintOptions( { PrecisionChecker.STRELAXED,
	PrecisionChecker.SIMULATION } )
/* A note about how to pass these options:
 * Do not use:
 *   -Alint=strelaxed -Alint=mbdynamic
 * but instead use:
 *   -Alint=strelaxed,mbdynamic
 * You will not get a warning about this...
 */
public class PrecisionChecker extends InstrumentingChecker {
	// Subtyping lint options
	// We currently only have one option, STRELAXED.
	// If the option is not present, we use the stricter subtyping
	// hierarchy.
	public static final boolean STRELAXED_DEFAULT = false;
	public static final String STRELAXED = "strelaxed";

	// Whether to simulate the approximate execution of the program
	public static final boolean SIMULATION_DEFAULT = false;
	public static final String SIMULATION = "simulation";

    // How many checks to do, use -Achecks=n to set
    private static final String MAX_CHECKS_FLAG = "checks";
    public static final int MAX_CHECKS_DEFAULT = 0;
    private int maxChecks;
    public int maxChecks() { return maxChecks; }

    // How many (if any) discrete levels of approximation should there be
    // -Alevels=l0,l1,...,ln
    // ex: -Alevels=0.9,0.99,1.0
    private static final String LEVELS_FLAG = "levels";
    protected double[] levels = null;

    // A flag to permit timeout.
    private static final String TIMEOUT_FLAG = "timeout";
    boolean timeoutAllowed = false;

	// The method name post-fixes that are used for approximate/precise methods
	public static final String MB_APPROX_POST = "_APPROX";
	public static final String MB_PRECISE_POST = "_PRECISE";

    public AnnotationMirror APPROX, PRECISE, TOP, CONTEXT, DYN;

    protected ExecutableElement approxValue;

    @Override
    public void initChecker() {
        APPROX = AnnotationUtils.fromClass(processingEnv.getElementUtils(), Approx.class);
        PRECISE = AnnotationUtils.fromClass(processingEnv.getElementUtils(), Precise.class);
        TOP = AnnotationUtils.fromClass(processingEnv.getElementUtils(), Top.class);
        CONTEXT = AnnotationUtils.fromClass(processingEnv.getElementUtils(), Context.class);
        DYN = AnnotationUtils.fromClass(processingEnv.getElementUtils(), Dyn.class);
        approxValue = TreeUtils.getMethod("enerj.lang.Approx", "value", 0, processingEnv);

        super.initChecker();

        // Get options
        Map<String, String> opts = processingEnv.getOptions();

        // Get max-checks flag value
        String checks = opts.get(MAX_CHECKS_FLAG);
        System.out.println("checks: " + checks);
        maxChecks = checks == null ? 0 : Integer.parseInt(checks);

        // Get levels flag value
        String levelStr = opts.get(LEVELS_FLAG);
        if (levelStr != null) {
            String[] levelTokens = levelStr.split(",");
            levels = new double[levelTokens.length];
            for (int i = 0; i < levels.length; ++i) {
                double value = -1.0;
                try {
                    value = Double.parseDouble(levelTokens[i]);
                } catch (NumberFormatException e) {
                    System.err.println("Expected a number, got " + levelTokens[i]);
                    System.exit(1);
                }
                if (value < 0.0 || value > 1.0) {
                    System.err.println("Approximation levels must be in the range [0, 1]");
                    System.exit(1);
                }
                levels[i] = value;
            }
        }

        // Get the flag determining whether timeout exceptions are allowed.
        timeoutAllowed = opts.containsKey(TIMEOUT_FLAG);
    }

    @Override
    public Set<String> getSupportedOptions() {
        Set<String> ret = new HashSet<>(super.getSupportedOptions());
        ret.add(MAX_CHECKS_FLAG);
        ret.add(LEVELS_FLAG);
        ret.add(TIMEOUT_FLAG);
        return ret;
    }

    /**
     * Returning null here turns off instrumentation in the superclass.
     */
    @Override
    public InstrumentingTranslator<PrecisionChecker> getTranslator(TreePath path) {
        return null;
    }

    // Hook to run tree translators (AST transformation step).
    @Override
    public void typeProcess(TypeElement e, TreePath p) {
        JCTree tree = (JCTree) p.getCompilationUnit(); // or maybe p.getLeaf()?

        if (debug()) {
            System.out.println("Translating from:");
            System.out.println(tree);
        }


        // Run the checker next and ensure everything worked out.
        super.typeProcess(e, p);

		if (getLintOption(PrecisionChecker.SIMULATION, PrecisionChecker.SIMULATION_DEFAULT)) {

			// then add instrumentation for bookkeeping
			tree.accept(new RuntimePrecisionTranslator(this,
                                                       processingEnv,
                                                       p,
                                                       ((PrecisionVisitor) visitor).invocations));

			// finally look what to simulate
			if (getLintOption(PrecisionChecker.SIMULATION, PrecisionChecker.SIMULATION_DEFAULT)) {
				tree.accept(new SimulationTranslator(this, processingEnv, p));
                // tree.accept(new ConstructorTranslator(this, processingEnv, p));
			}
		}

        if (debug()) {
            System.out.println("Translated to:");
            System.out.println(tree);
        }
    }

    // Removed (moved, really) in Checker Framework 1.3.0, but I'm leaving this
    // here for earlier versions.
    public boolean isValidUse(AnnotatedDeclaredType declarationType,
            AnnotatedDeclaredType useType) {
		// The checker calls this method to compare the annotation used in a
		// type to the modifier it adds to the class declaration. As our default
		// modifier is Precise, this results in an error when Approx is used
    	// as type annotation. Just ignore this check here and do them manually
    	// in the visitor.
    	return true;
    }

    /**
     * Gets the value out of an approx annotation
     */
    public double getApproxValue(AnnotatedTypeMirror approx) {
        approx = ((PrecisionVisitor) visitor).reduceArray(approx);
        // TODO: Is a default value of 0 (no guarantees) correct?
        if (approx.hasAnnotation(Dyn.class)) return 0.0;
        if (!approx.hasAnnotation(Approx.class)) return 1.0;
        AnnotationMirror annotation = approx.getAnnotation(Approx.class);
        return (Double) AnnotationUtils.getElementValuesWithDefaults(annotation).get(approxValue).getValue();
    }

    public Double getExplicit(JCTree tree) {
        if (tree instanceof BinaryTree) {
            BinaryTree b = (BinaryTree)tree;
            return ((PrecisionVisitor)visitor).explicits.get(b);
        }
        return null;
    }

	/**
	 * Determine whether the two given methods are substitutable, that is, every
	 * possible call of origexe will also succeed if we substitute newexe for
	 * it.
	 *
	 * @param origexe The original method.
	 * @param newexe The new method that we want to substitute.
	 * @return True, iff we can safely substitute the method.
	 */
    public boolean isCompatible(AnnotatedExecutableType origexe, AnnotatedExecutableType newexe) {
    	if (origexe.getParameterTypes().size() != newexe.getParameterTypes().size()) {
    		return false;
    	}

    	/* TODO: when depending on the context, this is not good... should we always
    	 * check this? Is this only a problem with strict subtyping?
    	if (!isSubtype( origexe.getReturnType(), newexe.getReturnType() ) ) {
    		return false;
    	}
    	*/

    	List<AnnotatedTypeMirror> origparams = origexe.getParameterTypes();
    	List<AnnotatedTypeMirror> newparams = newexe.getParameterTypes();

        /*
    	for(int i=0; i<origparams.size(); ++i) {
    		if(!((PrecisionVisitor)visitor).getTypeFactory().getQualifierHierarchy().isSubtype(origparams.get(i), newparams.get(i))) {
    			return false;
    		}
    	}
        */

    	// TODO: type parameter, exceptions?
		return true;
	}

	/**
	 * Explicitly construct components that weren't being automatically
	 * detected by introspection for some reason. (Seems to be necessary
     * on at least some Mac OS X systems.)
	 */
	@Override
	protected BaseTypeVisitor<?> createSourceVisitor() {
	    return new PrecisionVisitor(this);
	}

	/**
	 * Determines whether a given declared type (i.e., class) is approximable
	 * (has an @Approximable annotation) or whether the whole package is approximable.
	 */
	public static boolean isApproximable(DeclaredType type) {
		Element tyelem = type.asElement();
		Approximable ann = tyelem.getAnnotation(Approximable.class);
	    if (ann != null) {
	    	return true;
	    }
	    tyelem = ElementUtils.enclosingPackage(tyelem);
	    if (tyelem!=null) {
	    	ann = tyelem.getAnnotation(Approximable.class);
		    if (ann != null) {
		    	return true;
		    }
	    }
	    return false;
	}


	/**** Object size calculation. ****/

	private static final int POINTER_SIZE = 8; // on 64-bit VM
	private static final int LINE_SIZE = 64; // x86

	// Get the size of a Reference (local variable) at runtime.
	public static <T> int[] referenceSizes(Reference<T> ref) {
	    int preciseSize = 0;
	    int approxSize = 0;

        if (ref.primitive) {
            int size = 0;
            if (ref.value instanceof Byte) size = 1;
    	    else if (ref.value instanceof Short) size = 2;
    	    else if (ref.value instanceof Integer) size = 4;
    	    else if (ref.value instanceof Long) size = 8;
    	    else if (ref.value instanceof Float) size = 4;
    	    else if (ref.value instanceof Double) size = 8;
    	    else if (ref.value instanceof Character) size = 2;
    	    else if (ref.value instanceof Boolean) size = 1; // not defined
    	    else assert false;

    	    if (ref.approx)
                approxSize = size;
            else
                preciseSize = size;

        } else { // Object or array type.
            preciseSize = POINTER_SIZE;
        }

	    return new int[] {preciseSize, approxSize};
	}

	// Get the size of a particular static type.
	public static int[] typeSizes(AnnotatedTypeMirror type, boolean apprCtx, PrecisionChecker checker) {
	    int preciseSize = 0;
	    int approxSize = 0;

	    if (type.getKind() == TypeKind.DECLARED) {
            // References are always precise.
            preciseSize += POINTER_SIZE;
        } else {

            int size = 0;
            switch (type.getKind()) {
    	    case ARRAY: size = 0; break; // FIXME deal with arrays!
    	    case BOOLEAN: size = 1; break; // not defined
    	    case BYTE: size = 1; break;
    	    case CHAR: size = 2; break;
    	    case DOUBLE: size = 8; break;
    	    case FLOAT: size = 4; break;
    	    case INT: size = 4; break;
    	    case LONG: size = 8; break;
    	    case SHORT: size = 2; break;
    	    default: assert false;
    	    }

            if (type.hasEffectiveAnnotationRelaxed(checker.APPROX) ||
                    (apprCtx && type.hasEffectiveAnnotation(checker.CONTEXT)))
	            approxSize += size;
	        else
	            preciseSize += size;
        }

        return new int[]{preciseSize, approxSize};
	}

	// Get the size of an instance of a given class type (at compile time).
	public static int[] objectSizes(AnnotatedTypeMirror type,
	                                AnnotatedTypeFactory factory,
	                                Types typeutils,
	                                PrecisionChecker checker) {
	    boolean approx = type.hasEffectiveAnnotationRelaxed(checker.APPROX);
	    int preciseSize = 0;
	    int approxSize = 0;

	    List<? extends Element> members =
	        ((TypeElement)typeutils.asElement(type.getUnderlyingType())).getEnclosedElements();

	    for (VariableElement field : ElementFilter.fieldsIn(members)) {
	        AnnotatedTypeMirror fieldType = factory.getAnnotatedType(field);
	        int[] sizes = typeSizes(fieldType, approx, checker);
	        preciseSize += sizes[0];
	        approxSize  += sizes[1];
	    }

	    preciseSize += POINTER_SIZE; // vtable

	    int wastedApprox = Math.min(
	    	LINE_SIZE - (preciseSize % LINE_SIZE), // remainder of last precise line
	    	approxSize // all the approximate data
	    );
	    preciseSize += wastedApprox;
	    approxSize -= wastedApprox;

	    if (wastedApprox != 0 || approxSize != 0) {
	    	System.out.println(preciseSize + " " + approxSize + "; " + wastedApprox);
	    }

	    return new int[]{preciseSize, approxSize};
	}

    public BaseTypeVisitor getVisitor() {
        return (BaseTypeVisitor)visitor;
    }

}
