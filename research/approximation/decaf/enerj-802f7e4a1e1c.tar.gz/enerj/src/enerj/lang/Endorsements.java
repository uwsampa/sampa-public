package enerj.lang;

public class Endorsements {
	private Endorsements() {
		throw new AssertionError("Class Endorsements shouldn't be instantiated!");
	}
	/*
    @SuppressWarnings("precision")
    public static <T extends @Top Object> @Precise T endorse(T ref) {
    	// TODO: runtime check possible?
        return ref;
    }*/

    @SuppressWarnings("precision")
    public static @Precise int endorse(@Approx int param) {
    	// TODO: runtime check possible?
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise float endorse(@Approx float param) {
    	// TODO: runtime check possible?
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise boolean endorse(@Approx boolean param) {
    	// TODO: runtime check possible?
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise byte endorse(@Approx byte param) {
    	// TODO: runtime check possible?
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise short endorse(@Approx short param) {
    	// TODO: runtime check possible?
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise long endorse(@Approx long param) {
    	// TODO: runtime check possible?
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise char endorse(@Approx char param) {
    	// TODO: runtime check possible?
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise double endorse(@Approx double param) {
    	// TODO: runtime check possible?
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise double[] endorse(@Approx double[] param) {
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise double[][] endorse(@Approx double[][] param) {
        return endorse(param, 1.0);
    }

    @SuppressWarnings("precision")
    public static @Precise int endorse(@Approx int param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise float endorse(@Approx float param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise boolean endorse(@Approx boolean param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise byte endorse(@Approx byte param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise short endorse(@Approx short param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise long endorse(@Approx long param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise char endorse(@Approx char param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise double endorse(@Approx double param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise double[] endorse(@Approx double[] param, double value) {
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise double[][] endorse(@Approx double[][] param, double value) {
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise int checked_endorse(@Dyn int param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise float checked_endorse(@Dyn float param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise boolean checked_endorse(@Dyn boolean param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise byte checked_endorse(@Dyn byte param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise short checked_endorse(@Dyn short param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise long checked_endorse(@Dyn long param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise char checked_endorse(@Dyn char param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise double checked_endorse(@Dyn double param, double value) {
    	// TODO: runtime check possible?
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise double[] checked_endorse(@Dyn double[] param, double value) {
        return param;
    }

    @SuppressWarnings("precision")
    public static @Precise int[] checked_endorse(@Dyn int[] param, double value) {
        return param;
    }
}
