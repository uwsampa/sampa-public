package enerj.lang;

import java.lang.annotation.*;

import org.checkerframework.framework.qual.*;

/**
 * Type qualifier for approximate values.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE_USE, ElementType.TYPE_PARAMETER})
@TypeQualifier
@SubtypeOf({Dyn.class})
public @interface Approx {
    double value() default Double.NaN;
}
