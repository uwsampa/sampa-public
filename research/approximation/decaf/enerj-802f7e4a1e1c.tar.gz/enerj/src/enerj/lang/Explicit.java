package enerj.lang;

public class Explicit {
    public static @Dyn double explicit(@Dyn double value, double precision) {
        return value;
    }
}
