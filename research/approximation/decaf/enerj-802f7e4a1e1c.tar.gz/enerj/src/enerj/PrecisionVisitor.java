package enerj;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.Queue;

import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.type.TypeKind;
import javax.lang.model.util.Elements;

import org.checkerframework.common.basetype.BaseTypeVisitor;
import org.checkerframework.common.basetype.BaseTypeChecker;
import org.checkerframework.checker.compilermsgs.qual.CompilerMessageKey;
import org.checkerframework.framework.source.Result;
import org.checkerframework.framework.type.AnnotatedTypeFactory;
import org.checkerframework.framework.type.AnnotatedTypeMirror;
import org.checkerframework.framework.type.AnnotatedTypeMirror.AnnotatedDeclaredType;
import org.checkerframework.framework.type.AnnotatedTypeMirror.AnnotatedExecutableType;
import org.checkerframework.javacutil.TreeUtils;
import org.checkerframework.common.basetype.BaseTypeValidator;

import enerj.lang.Approx;
import enerj.lang.Dyn;
import enerj.lang.Precise;
import enerj.solver.Z3Processor;

import com.sun.source.tree.*;
import com.sun.source.util.TreePath;
import com.sun.tools.javac.code.Type;
import com.sun.tools.javac.tree.JCTree;


public class PrecisionVisitor extends BaseTypeVisitor<PrecisionAnnotatedTypeFactory> {
    public static final String INFERRED_DATA_SER = "vars.ser";
    public static final String OPS_CSV = "operators.csv";
    public static final int QUERY_TIMEOUT_MS = 30 * 60 * 1000;

    protected final Map<String, Queue<String>> invocations;

    private final Set<ClassTree> classes;
    private final Set<VariableTree> formalParameters;
    private final Stack<MetaMethodInvocation> recheck;
    private final Z3Processor solver;

    private int baseScope;
    private MetaMethodInvocation currentRevisit;
    private Map<String, Map<String, Double>> inferredData;
    private boolean limitChecks;
    private BufferedWriter opsCsv;
    private ClassTree outerClass;


	public PrecisionVisitor(PrecisionChecker checker) {
        super(checker);
        solver = new Z3Processor();
        //ClassTree eclass = TreeUtils.enclosingClass(checker.currentPath);
        //File csv = new File(eclass.getSimpleName() + OPS_CSV_SUFFIX);
        File csv = new File(OPS_CSV);
        csv.delete();
        try {
            boolean res = csv.createNewFile();
            assert res;
            opsCsv = new BufferedWriter(new FileWriter(csv));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        classes = new HashSet<>();
        recheck = new Stack<MetaMethodInvocation>();
        currentRevisit = null;
        formalParameters = new HashSet<VariableTree>();
        inferredData = new HashMap<>();
        invocations = new HashMap<>();
    }

    private PrecisionChecker chk() {
        return (PrecisionChecker)checker;
    }

    /**
     * Make sure that @Approx annotated object types are approximable.
     */
    protected class ApproximabilityValidator extends BaseTypeValidator {
        ApproximabilityValidator(BaseTypeChecker checker, BaseTypeVisitor<?> visitor, AnnotatedTypeFactory atypeFactory) {
            super(checker, visitor, atypeFactory);
        }
        @Override
        public Void visitDeclared(AnnotatedDeclaredType type, Tree node) {
        	// Is the class not approximatable but has an @Approx annotation?
        	if ((type.hasEffectiveAnnotationRelaxed(chk().APPROX) ||
        	        type.hasEffectiveAnnotation(chk().CONTEXT)) &&
        	        !PrecisionChecker.isApproximable(type.getUnderlyingType())) {
        	    checker.report(Result.failure("type.invalid.unapproximable",
        	                                  type.getUnderlyingType().toString()), node);
        	}

            return super.visitDeclared(type, node);
        }
    }

    @Override
    public ApproximabilityValidator createTypeValidator() {
        return new ApproximabilityValidator(checker, this, atypeFactory);
    }


    /**
     * Validate a new object creation.
     *
     * @param node the new object creation.
     * @param p not used.
     */
    @Override
    public Void visitNewClass(NewClassTree node, Void p) {
        assert node != null;

        // Check for @Top as top-level modifier.
        AnnotatedTypeMirror type = atypeFactory.getAnnotatedType(node);
        if ( type.hasEffectiveAnnotation(chk().TOP) ) {
            // System.out.println("new got: " + type.toString());
            checker.report(Result.failure("new.top.forbidden"), node);
        }

        // TODO: Are new classes always precise?  I think so...
        String tmp = solver.initTmp(1.0);

        super.visitNewClass(node, p);

        // Remove any constraints generated from paramters
        while (!solver.getLastTmp().equals(tmp)) {}
        solver.pushVar(tmp, true);

        return null;
    }

    @Override
    protected boolean checkConstructorInvocation(AnnotatedDeclaredType dt,
            AnnotatedExecutableType constructor, Tree src) {
    	// Ignore the default annotation on constructors
    	return true;
    }

    @Override
    protected void checkMethodInvocability(AnnotatedExecutableType method,
            MethodInvocationTree node) {
    	// Ignore the default annotation on methods
    	return;
    }

    @Override
    public Void visitClass(ClassTree node, Void p) {
        // Has to be set AFTER the precision checker has it's init method run,
        // which is why this is here and not in the constructor.
        limitChecks = chk().maxChecks() > 0;
        solver.declareLevels(chk().levels);

        // Check all member variables first
        for (Tree t : node.getMembers()) {
            if (t.getKind() == Tree.Kind.VARIABLE) scan(t, null);
            else if (t.getKind() == Tree.Kind.CLASS) classes.add((ClassTree) t);
        }

        baseScope = solver.getScopeNumber();
        System.out.println("baseScope: " + baseScope);

        if (outerClass == null) outerClass = node;

        super.visitClass(node, p);

        if (outerClass == node) {
            if (limitChecks) {
                System.out.println("---------------------------------------------");
                //solver.declareZeros();
                // Leave checks to the very end

                // Check the saved methods
                Collection<Z3Processor.Method> methods = solver.getMethods();
                boolean changed = false;
                do {
                    // Iterate through constraint generation until no more are
                    // generated
                    changed = false;
                    for (Z3Processor.Method method : methods) {
                        // Scan all methods first
                        if (!method.isMethodChecked())
                            throw new AssertionError("method hasn't been checked yet");
                        while (method.enterCount() < method.invocations.size() &&
                               method.enterCount() < chk().maxChecks()) {
                            scan(method.method, null);
                            changed = true;
                        }
                    }
                } while (changed);

                for (Z3Processor.Method method : methods) {
                    // Solve the constraints for this method
                    method.emitConstraints();
                }

                Z3Processor.QueryResult res = executeQuery();

                // Analyze results
                if (res.sat) {
                    // Don't fill in class or method name
                    StringBuilder line = new StringBuilder(",");
                    writeVars(line, res);
                    checkWarns(res, node);

                    // Map invocations in inferredData
                    for (Map.Entry<String, Double> var : res.wildcardVars.entrySet()) {
                        String varName = var.getKey();
                        if (varName.startsWith("inv-")) {
                            int index = (int) Math.round(var.getValue()) - 1;
                            int end = varName.lastIndexOf("-");
                            String invName = varName.substring(4, end);
                            // Bind invocation in the slowest way possible
                            for (Z3Processor.Method method : methods) {
                                for (MetaMethodInvocation inv : method.invocations) {
                                    if (inv.varName.equals(invName)) {
                                        // Found it!
                                        String actualMethod = method.names.get(index);
                                        String scopeName = solver.getScopeFromMethodName(actualMethod).name;
                                        Map<String, Double> data = inferredData.get(scopeName);
                                        if (data == null) {
                                            System.out.println(inferredData);
                                            throw new AssertionError("data == null, " +
                                                                     actualMethod +
                                                                     " not in inferredData");
                                        }
                                        inferredData.put(invName, data);
                                        System.out.printf("binding %s to %s\n",
                                                          invName,
                                                          scopeName);
                                    }
                                }
                            }
                        }
                    }
                } else checker.report(Result.failure("unsatisfiable.approx.types"), node);

                System.out.println("---------------------------------------------");
            }

            // Clean up inferred data
            for (Map.Entry<String, Map<String, Double>> methData : inferredData.entrySet()) {
                Map<String, Double> niceKeys = new HashMap<>();
                for (Map.Entry<String, Double> var : methData.getValue().entrySet()) {
                    String[] tokens = var.getKey().split("-");
                    String niceName = tokens[0];
                    niceKeys.put(niceName, var.getValue());
                }
                methData.setValue(niceKeys);
            }

            // Serialize our inferred data
            try {
                FileOutputStream fileOut = new FileOutputStream(INFERRED_DATA_SER);
                ObjectOutputStream out = new ObjectOutputStream(fileOut);
                out.writeObject(inferredData);
                out.close();
                fileOut.close();
            } catch (IOException e) { throw new RuntimeException(e); }
            inferredData = null;

        }


        return null;
    }

    private void writeVars(StringBuilder line, Z3Processor.QueryResult result) {
        for (Z3Processor.Scope current = result.scope;
             current != null;
             current = current.parent) {
            // Traverse up the scope list
            addScopeToInferredData(current, result);
        }

        for (Z3Processor.Scope scope : result.containedScopes) {
            // Add other contained scopes as well
            addScopeToInferredData(scope, result);
        }

        for (Map.Entry<String, Double> var : result.entrySet()) {
            String varName = var.getKey();
            double varValue = var.getValue();
            line.append(",").append(varName).append(":").append(varValue);
            System.out.println(varName + " : " + varValue);
        }
        line.append("\n");
        System.out.print(line.toString());
        try {
            opsCsv.write(line.toString());
            opsCsv.flush();
        } catch (IOException e) { throw new RuntimeException(e); }
    }

    private void addScopeToInferredData(Z3Processor.Scope scope,
                                        Z3Processor.QueryResult result) {
        Map<String, Double> vars = new HashMap<>();
        for (Map.Entry<String, Long> var : scope.vars.entrySet()) {
            // Associate variables with this scope
            String internalName = var.getKey() + "-" + var.getValue();
            Double value = result.get(internalName);
            if (value != null) vars.put(internalName, value);
        }
        if (!vars.isEmpty()) {
            Map<String, Double> old = inferredData.put(scope.name, vars);
            System.out.println("adding " + scope.name);
            System.out.println("old: " + old);
            System.out.println("new: " + vars);
            if (old != null && !noDataLost(old, vars)) {
                throw new AssertionError("old != null && !noDataLost(old, vars), inferredData already contained incompatible data about " +
                                         scope.name);
            }
        }
    }

    private boolean noDataLost(Map<String, ?> old, Map<String, ?> vars) {
        if (vars.size() != old.size()) return false;

        for (String var : vars.keySet()) {
            if (!old.containsKey(var)) return false;
        }

        return true;
    }

    /**
     * Handles variable declaration and initialization
     */
    @Override
    public Void visitVariable(VariableTree node, Void p) {
        // TODO: Compiler messages may be more useful if this logic is moved
        //       to visitAnnotation
        AnnotatedTypeMirror type = getAnnotatedType(node);

        double value = chk().getApproxValue(type);
        if (value < 0.0 || value > 1.0) {
            checker.report(Result.failure("illegal.approx.value", value),
                                          node);
        }
        solver.setApproxOps(isApprox(type));

        boolean memberVar = enclosingStatement(node).getKind() == Tree.Kind.CLASS;
        solver.saveConstraints(memberVar);

        String name = node.getName().toString();
        if (!formalParameters.contains(node) &&
                (!memberVar || (memberVar && !solver.variableDeclared(name)))) {
            // Add the variable to the solver
            solver.declareVariable(name, value);
        }

        // Traverse down after establishing whether or not variable is
        // approximate
        super.visitVariable(node, p);

        // Assign last temporary to the variable
        if (node.getInitializer() != null) {
            JCTree.JCVariableDecl jnode = (JCTree.JCVariableDecl) node;
            if (jnode.type instanceof Type.ArrayType &&
                    !node.getInitializer().toString().startsWith("new "))
                solver.referenceLastTmp(name, false);
            else solver.assignLastTmp(name, false);
        }

        return null;
    }

    @Override
    public Void visitBinary(BinaryTree node, Void p) {
    	super.visitBinary(node, p);

        Double explicitPrecison = explicits.get(node);
        if (explicitPrecison != null) {
            solver.binaryOp(getPos(node), true, explicitPrecison);
        } else {
            solver.binaryOp(getPos(node));
        }

    	// AnnotatedTypeMirror lhs = atypeFactory.getAnnotatedType(node.getLeftOperand());
    	// AnnotatedTypeMirror rhs = atypeFactory.getAnnotatedType(node.getRightOperand());

    	// TODO: is this the correct check? do we want subtypes or not?
    	// Disabling this check for now. We should allow binary operations on incompat.
    	// types (e.g., approx + precise). The resulting expression just becomes "tainted"
    	// approximate. --ALDS
    	/*
    	if (! (checker.getQualifierHierarchy().isSubtype(lhs.getAnnotations(), rhs.getAnnotations()) ||
    			checker.getQualifierHierarchy().isSubtype(rhs.getAnnotations(), lhs.getAnnotations()) ) ) {
    		checker.report(Result.failure("binary.type.incompatible", lhs, rhs), node);
    	}
    	*/

    	return null;
    }

    /**
     * Properly handle compound assignment with approximate types
     */
    @Override
    public Void visitCompoundAssignment(CompoundAssignmentTree node,
                                        Void p) {
        // FIXME: Getting the approx value of node.getVariable() is wrong, we
        // use false for now because it's the safe answer.
        solver.setApproxOps(false);
        super.visitCompoundAssignment(node, p);

        // Expand out to a binary op
        String name = getName(node.getVariable());
        boolean isThis = name.startsWith("this.");
        if (isThis) {
            name = name.substring(5);
            solver.setScope(baseScope);
        }
        solver.binaryOp(getPos(node));
        solver.assignLastTmp(name, false);
        solver.pushVar(name, false);
        if (isThis) solver.popScope();

        return null;
    }

    /**
     * Properly handle unary operators
     */
    @Override
    public Void visitUnary(UnaryTree node, Void p) {
        solver.setApproxOps(isApprox(node.getExpression()));
        super.visitUnary(node, p);
        System.out.println("VU: " + node);

        // Expand out to a binary op, the operand is the last tmp
        String name = solver.getLastTmp();
        solver.pushVar(name, true);
        solver.initTmp(1.0); // abstract literal
        solver.binaryOp(getPos(node));
        solver.assignLastTmp(name, true);
        solver.pushVar(name, true);

        return null;
    }

	/**
     * Do not allow approximate data as the type of a conditional.
     * TODO: ensure that approximation gets propagated in comparisons!
     */
    private void conditionCheck(ExpressionTree condtree) {
    	AnnotatedTypeMirror cond = atypeFactory.getAnnotatedType(condtree);
    	Set<AnnotationMirror> condanns = cond.getAnnotations();

    	if (condanns.size() > 0 &&
    		!condanns.contains(chk().PRECISE) ) {
    		checker.report(Result.failure("condition.type.incompatible", cond), condtree);
    	}
    }

    @Override
    public Void visitIf(IfTree node, Void p) {
        solver.setApproxOps(false);
    	super.visitIf(node, p);
    	conditionCheck(node.getCondition());
    	return null;
    }

    @Override
    public Void visitDoWhileLoop(DoWhileLoopTree node, Void p) {
    	super.visitDoWhileLoop(node, p);
        conditionCheck(node.getCondition());
        return null;
    }

    @Override
    public Void visitWhileLoop(WhileLoopTree node, Void p) {
    	super.visitWhileLoop(node, p);
        conditionCheck(node.getCondition());
        return null;
    }

    @Override
    public Void visitForLoop(ForLoopTree node, Void p) {
    	super.visitForLoop(node, p);
    	if (node.getCondition() == null) {
    		return null;
    	}
        conditionCheck(node.getCondition());
        return null;
    }

    /* TODO: should we forbid iterating over approx arrays? Hmm, no.
    @Override
    public Void visitEnhancedForLoop(EnhancedForLoopTree node, Void p) {
        return super.visitEnhancedForLoop(node, p);
    } */

    @Override
    public Void visitConditionalExpression(ConditionalExpressionTree node, Void p) {
    	super.visitConditionalExpression(node, p);
        conditionCheck(node.getCondition());
        return null;
    }

    @Override
    public Void visitAssert(AssertTree node, Void p) {
    	super.visitAssert(node, p);
        conditionCheck(node.getCondition());
        return null;
    }

    // Ensure that array indices are precise.
    @Override
    public Void visitArrayAccess(ArrayAccessTree node, Void p) {
        super.visitArrayAccess(node, p);
        AnnotatedTypeMirror type = atypeFactory.getAnnotatedType(
            node.getIndex());
        if ( !type.hasEffectiveAnnotation(chk().PRECISE) ) {
            checker.report(Result.failure("array.index.approx"),
                           node.getIndex());
        }
        String name = getName(node.getExpression());
        solver.getLastTmp();

        return null;
    }

    // Moved here in Checker Framework 1.3.0.
    public boolean isValidUse(AnnotatedDeclaredType declarationType,
            AnnotatedDeclaredType useType) {
        return true;
    }

    private boolean checkWarns(Z3Processor.QueryResult result, Tree node) {
        boolean warn = false;
        for (String var : result.zeros) {
            if (!var.startsWith("op-") && !var.startsWith("tmp-")) {
                checker.report(Result.warning("zero.precision", var), node);
                warn = true;
            }
        }

        for (String var : result.possibleOnes) {
            if (!var.startsWith("op-") && !var.startsWith("tmp-")) {
                checker.report(Result.warning("full.precision", var), node);
                warn = true;
            }
        }

        return warn;
    }

    private Z3Processor.QueryResult executeQuery() {
        if (chk().timeoutAllowed) {
            Z3Processor.QueryResult res = solver.executeQuery(QUERY_TIMEOUT_MS);
            if (res == null) {
                System.err.println("SOLVER QUERY TIMEOUT");
                System.exit(1);
            }
            return res;
        } else {
            return solver.executeQuery();
        }
    }

    @Override
    public Void visitMethod(MethodTree node, Void p) {
        if (limitChecks && currentRevisit != null) {
            String error = "Method inlining AND check limiting enabled";
            throw new AssertionError(error);
        }

        int enterCount = -1;
        String mname = null;
        if (currentRevisit == null) {
            mname = generateMethodName(node, 0);
            if (limitChecks) {
                enterCount = solver.enterMethod(node);
                mname += enterCount;
            }
            mname += "-";
            solver.pushScope(mname);
        }
        System.out.println("Method: " + node);
        AnnotatedTypeMirror anno = atypeFactory.getAnnotatedType(node).getReturnType();
        System.out.println("anno: " + anno);
        solver.saveConstraints(false);

        double value = 1.0;
        boolean inf = false;  // Are there inferred parameters?
        if (isApprox(anno)) {
            if (currentRevisit == null) {
                value = chk().getApproxValue(anno);
                if (value < 0.0 || value > 1.0)
                    checker.report(Result.failure("illegal.approx.value", value),
                                   node);
            } else value = -1.0; // value must not be used

            if (Double.isNaN(value)) inf = true;
        } else if (isDyn(anno)) value = 0.0;

        if (currentRevisit == null && !limitChecks) solver.clearState();

        if (currentRevisit == null) {
            solver.declareReturn(generateMethodName(node, 0),
                                 value,
                                 anno.getKind().equals(TypeKind.ARRAY));
        }

        // Declare formal parameters
        List<? extends VariableTree> params = node.getParameters();
        for (int i = 0; i < params.size(); ++i) {
            VariableTree param = params.get(i);
            double paramValue = chk().getApproxValue(getAnnotatedType(param));
            String paramName = param.getName().toString();
            solver.declareVariable(paramName, paramValue);
            formalParameters.add(param);
            if (limitChecks) {
                String paramBinder = "p" + i + "-" + mname + "-";
                System.out.println("paramBinder: " + paramBinder);
                solver.declareVariable(paramBinder, paramValue);
                solver.pushVar(paramBinder, false);
                solver.referenceLastTmp(paramName, false);
            }
            if (Double.isNaN(paramValue)) inf = true;
        }

        if (currentRevisit != null) inf = false;

        super.visitMethod(node, p);

        formalParameters.clear();

        if (currentRevisit != null) {
            // Assert that inferred parameters are correct
            for (int i = 0; i < params.size(); ++i) {
                VariableTree var = params.get(i);
                String name = var.getName().toString();
                solver.pushVar(currentRevisit.parameters[i], true);
                JCTree.JCVariableDecl jvar = (JCTree.JCVariableDecl) var;
                if (jvar.type instanceof Type.ArrayType)
                    solver.referenceLastTmp(name, false);
                else solver.assignLastTmp(name, false);
            }
            solver.pushVar(currentRevisit.varName, true);
        } else if (limitChecks) { /// && inf) {
            // Don't solve constraints, just set them aside for later
            solver.exitMethod(true);
        } else {
            Z3Processor.QueryResult result = executeQuery();
            if (!result.sat) {
                checker.report(Result.failure("unsatisfiable.approx.types"), node);
                solver.popScope();
                if (limitChecks) solver.exitMethod(false);
                return null;
            }

            // Warn about zero and one probabilities
            if (!limitChecks && !inf) checkWarns(result, node);

            // TODO: Add a slot for return precision and arg precision
            // line: classname,methodname,op0,op1,...
            StringBuilder line = new StringBuilder();
            // class name
            ClassTree eclass = ((PrecisionAnnotatedTypeFactory) atypeFactory).getClassTree(node);
            line.append(eclass.getSimpleName());
            // method name
            String paramNames = node.getParameters() == null ?
                                "" :
                                node.getParameters().toString().replace('\n', ' ');
            line.append(",").append(node.getReturnType()).append(" ")
                .append(node.getName()).append(" ").append(paramNames);
            // return
            line.append(",return:").append(value);
            writeVars(line, result);
            if (limitChecks) solver.exitMethod(true);
            else solver.popScope();
        }

        return null;
    }

    @Override
    protected boolean checkOverride(MethodTree overriderTree,
                                    AnnotatedTypeMirror.AnnotatedDeclaredType enclosingType,
                                    AnnotatedTypeMirror.AnnotatedExecutableType overridden,
                                    AnnotatedTypeMirror.AnnotatedDeclaredType overriddenType,
                                    java.lang.Void p) {
        System.out.println("checkOverride called");
        System.out.println("overriderTree: " + overriderTree);
        System.out.println("enclosingType: " + enclosingType);
        System.out.println("overridden: " + overridden);
        System.out.println("overriddenType " + overriddenType);

        AnnotatedTypeMirror.AnnotatedExecutableType anno =
            atypeFactory.getAnnotatedType(overriderTree);
        double overriderReturn = chk().getApproxValue(anno.getReturnType());
        double overriddenReturn = chk().getApproxValue(overridden.getReturnType());
        if (Double.isNaN(overriderReturn) && !Double.isNaN(overriddenReturn)) {
            // Communicate overriderReturn precision to solver.  Overrider
            // return must be greater than or equal to overridden
            solver.initTmp(overriddenReturn);
            if (currentRevisit == null) solver.assignLastTmp(generateMethodName(anno, 0), false);
            else solver.assignLastTmp(currentRevisit.varName, true);
        }

        List<AnnotatedTypeMirror> overriderParams = anno.getParameterTypes();
        List<AnnotatedTypeMirror> overriddenParams = overridden.getParameterTypes();
        for (int i = 0 ; i < overriderParams.size(); ++i) {
            double overriderParam = chk().getApproxValue(overriderParams.get(i));
            double overriddenParam = chk().getApproxValue(overriddenParams.get(i));
            if (Double.isNaN(overriderParam) && !Double.isNaN(overriddenParam)) {
                // Communicate overriderParam to solver.  Overrider param must
                // be less than or equal to overridden
                String paramName = overriderTree.getParameters().get(i).getName().toString();
                String tmp = solver.initTmp(overriddenParam);
                solver.getLastTmp();
                solver.pushVar(paramName, false);
                solver.assignLastTmp(tmp, true);
            }
        }
        return super.checkOverride(overriderTree, enclosingType, overridden, overriddenType, p);
    }


    @Override
    public Void visitReturn(ReturnTree node, Void p) {
        solver.setApproxOps(currentRevisit == null ?
                            solver.returnIsApprox() : true);
        super.visitReturn(node, p);
        if (currentRevisit == null) {
            TreePath path = atypeFactory.getPath(node);
            MethodTree method = TreeUtils.enclosingMethod(path);
            solver.assignLastTmp(generateMethodName(method, 0), false);
        } else {
            solver.assignLastTmp(currentRevisit.varName, true);
            //solver.pushVar("method-", false);
        }
        return null;
    }

    // TODO: Need to do something special here for return type inference?
    @Override
    public Void visitAssignment(AssignmentTree node, Void p) {
        ExpressionTree var = node.getVariable();
        solver.setApproxOps(isApprox(var));
        super.visitAssignment(node, p);

        String name = getName(var);
        boolean isThis = name.startsWith("this.");
        if (isThis) {
            name = name.substring(5);
            solver.setScope(baseScope);
        }

        if (name.contains(".")) {
            double value = chk().getApproxValue(getAnnotatedType(var));
            if (Double.isNaN(value)) {
                checker.report(Result.failure("cross.class.inference"), node);
                solver.getLastTmp();
                return null;
            } else {
                // Lazily declare member variables
                solver.declareVariable(name, value);
            }
        }

        JCTree.JCAssign jnode = (JCTree.JCAssign) node;
        if (jnode.lhs.type instanceof Type.ArrayType &&
                !node.getExpression().toString().contains("new "))
            solver.referenceLastTmp(name, false);
        else solver.assignLastTmp(name, false);

        // Result from assignment acts as a temp
        solver.pushVar(name, false);

        if (isThis) solver.popScope();
        return null;
    }

    @Override
    public Void visitTypeCast(TypeCastTree node, Void p) {
        super.visitTypeCast(node, p);

        solver.getLastTmp();
        double value = chk().getApproxValue(getAnnotatedType(node));
        solver.initTmp(value);

        return null;
    }

    @Override
    public Void visitLiteral(LiteralTree node, Void p) {
        super.visitLiteral(node, p);
        solver.initTmp(1.0);
        return null;
    }

    @Override
    public Void visitIdentifier(IdentifierTree node, Void p) {
        String name = getName(node);
        boolean isThis = name.equals("this");
        if (isThis) solver.setScope(baseScope);
        super.visitIdentifier(node, p);
        if (solver.variableDeclared(name)) solver.pushVar(name, false);
        else if (!isThis && !name.contains(".")) {
            try {
                // TODO: This is a mess.  Lazily inits a temp that is likely
                // wrong, which gets "fixed" in visitMemberSelect, which ALSO
                // might do the wrong thing and gets fixed in
                // visitMethodInvocation.
                AnnotatedTypeMirror anno = atypeFactory.getAnnotatedTypeFromTypeTree(node);
                double value = chk().getApproxValue(anno);
                if (Double.isNaN(value)) {
                    checker.report(Result.failure("cross.class.inference"), node);
                    value = -1.0;
                }
                solver.initTmp(value);
            } catch (NullPointerException exc) {}
        }
        if (isThis) solver.popScope();
        return null;
    }

    @Override
    public Void visitMemberSelect(MemberSelectTree node, Void p) {
        super.visitMemberSelect(node, p);
        System.out.println("VMS: " + node);

        String name = node.getIdentifier().toString();
        boolean isThis = getName(node.getExpression()).equals("this");
        if (isThis && solver.variableDeclared(name)) {
            solver.setScope(baseScope);
            solver.pushVar(name, false);
            solver.popScope();
        } else if (name.equals("length")) {
            // Most likely an array length field
            solver.getLastTmp(); // Remove array that was placed on stack
            solver.initTmp(1.0);
        } else if (!isThis) {
            // Functions are a special case handled in visitMethodInvocation
            // Pop the last thing off the stack since visitIdentifier messed it
            // up?
            String last = solver.getLastTmp();
            try {
                // TODO: Change call to getAnnotatedType()?  Is that going to
                // be equivalent to getAnnotatedTypeFromTypeTree()?
                AnnotatedTypeMirror anno = atypeFactory.getAnnotatedTypeFromTypeTree(node);
                double value = chk().getApproxValue(anno);
                if (Double.isNaN(value)) {
                    checker.report(Result.failure("cross.class.inference"), node);
                    value = -1.0;
                }
                solver.initTmp(value);
            } catch (NullPointerException exc) {}
        }

        return null;
    }

    private String getName(Tree node) {
        String name = node.toString().split("\\[")[0];
        return name;
    }

    public Map<BinaryTree, Double> explicits = new HashMap<BinaryTree, Double>();

    @Override
    public Void visitMethodInvocation(MethodInvocationTree node, Void p) {
        // TODO: make sure this works if you're returning an approx array
        PrecisionAnnotatedTypeFactory patf = (PrecisionAnnotatedTypeFactory) atypeFactory;
        AnnotatedTypeMirror type = getAnnotatedType(node);
        boolean endorse = node.toString().startsWith("Endorsements");
        String endorseTmp = null;
        if (endorse) {
            // Handle static endorse.  To the type system, this endorse returns
            // a precise var, but to the solver it has the precision of its
            // value parameter

            // Get the value from the actual paramters.  MUST be a literal
            if (node.getArguments().size() == 2) {
                ExpressionTree valArg = node.getArguments().get(1);
                System.out.println("valArg: " + valArg);
                Tree.Kind kind = valArg.getKind();
                if (kind.equals(Tree.Kind.DOUBLE_LITERAL)) {

                    Double val = (Double) ((LiteralTree) valArg).getValue();
                    if (val == null || val.isNaN() || val < 0.0 || val > 1.0)
                        checker.report(Result.failure("illegal.approx.value", val),
                                       valArg);
                    endorseTmp = solver.initTmp(val);

                    // Modify the annotated type
                    type.clearAnnotations();
                    type.addAnnotation(patf.createApproxAnnotation(val));

                } else {
                    // value is not a literal, reject
                    checker.report(Result.failure("endorse.not.literal"), valArg);
                    solver.initTmp(1.0);
                }
            } else {
                // Old style endorse
                if (node.getArguments().size() != 1)
                    throw new AssertionError("Endorse has 0 or >2 args");
                endorseTmp = solver.initTmp(1.0);
            }
        }

        if (node.toString().startsWith("Explicit.explicit")) {
            ExpressionTree valExp = node.getArguments().get(0);
            double prob = (Double)(((LiteralTree)(node.getArguments().get(1))).getValue());
            explicits.put((BinaryTree)valExp, prob);
        }

        int preStackSize = solver.getStackSize();
        super.visitMethodInvocation(node, p);
        int postStackSize = solver.getStackSize();

        if (endorse) {
            if (endorseTmp == null) throw new AssertionError("endorseTmp == null");

            // Remove tmps up to the endorseTmp
            while (!solver.getLastTmp().equals(endorseTmp)) {}
            solver.pushVar(endorseTmp, true);
            return null;
        }

        if (endorseTmp != null) throw new AssertionError("endorseTmp != null");

        double value = chk().getApproxValue(type);
        if (value < 0.0 || value > 1.0) {
            checker.report(Result.failure("illegal.approx.value", value),
                           node);
        }
        boolean wildcardParams = false;
        boolean wildcardReturn = false;


        // Get the method invoked by node
        AnnotatedExecutableType exMethod = atypeFactory.methodFromUse(node).first;
        System.out.println("method from use: " + exMethod);
        List<AnnotatedTypeMirror> params = exMethod.getParameterTypes();
        System.out.println("params: " + params);

        // Fix stack that was potentially broken by member select
        int correctSize = preStackSize + params.size();
        for (int i = correctSize; i < postStackSize; ++i) {
            solver.getLastTmp();
        }

        // Check if any parameters need to be inferred
        for (AnnotatedTypeMirror param : params) {
            param = reduceArray(param);
            if (Double.isNaN(chk().getApproxValue(param))) {
                wildcardParams = true;
                break;
            }
        }

        // Check if return value must be inferred
        wildcardReturn = Double.isNaN(value);

        // Get the method invoked by node
        MethodTree method = (MethodTree) patf.getDeclarationFromElement(exMethod.getElement());
        if (wildcardReturn || wildcardParams) {

            if (method == null) { //|| !patf.getClassTree(node).getMembers().contains(method)) {
                checker.report(Result.failure("cross.class.inference"), node);
                solver.initTmp(-1.0);
                return null;
            }

            // Get parameter precision
            int numArgs = node.getArguments().size();
            String[] args = new String[numArgs];
            for (int i = numArgs - 1; i >= 0; --i) {
                args[i] = solver.getLastTmp();
            }

            int pos = getPos(node);
            long line = root.getLineMap().getLineNumber(pos);

            String name = generateMethodName(method, line);
            name = solver.declareVariable(name, value);
            solver.pushVar(name, true);
            MetaMethodInvocation inline =
                new MetaMethodInvocation(method, args, name, currentRevisit,
                                         line);

            String result = null;
            if (limitChecks) {
                solver.addInvocation(inline);
                handleSubclasses(inline);
                result = name;
            } else {
                // Keep everything in the same scope so potential overrides have
                // access to their parents parameters
                result = solver.pushScope(generateMethodName(method, line) + "-");
                recheckMethod(inline);
                handleSubclasses(inline);
                solver.popScope();
            }

            // Map this scope to the method
            TreePath path = patf.getPath(method);
            if (path != null) {
                String className = TreeUtils.enclosingClass(path)
                                            .getSimpleName()
                                            .toString();
                String methodName = className + "-" + method.getName()
                                                            .toString();
                Queue<String> methodInvocations = invocations.get(methodName);
                if (methodInvocations == null) {
                    methodInvocations = new LinkedList<String>();
                    invocations.put(methodName, methodInvocations);
                }

                if (method.getName().toString().equals("main"))
                    invocations.put("main", methodInvocations);

                methodInvocations.add(result);
            }
        }

        if (!(wildcardReturn || wildcardParams)) solver.initTmp(value);

        return null;
    }

    private String generateMethodName(AnnotatedTypeMirror.AnnotatedExecutableType anno,
                                      long line) {
        PrecisionAnnotatedTypeFactory patf = (PrecisionAnnotatedTypeFactory) atypeFactory;
        MethodTree method = (MethodTree) patf.getDeclarationFromElement(anno.getElement());
        return generateMethodName(method, line);
    }

    private String generateMethodName(MethodTree method, long line) {
        TreePath path = atypeFactory.getPath(method);
        String className = TreeUtils.enclosingClass(path).getSimpleName().toString();

        return "method-" + className + "-" + method.getName().toString() + "-" + line + "-";
    }

    private void handleSubclasses(MetaMethodInvocation inv) {
        PrecisionAnnotatedTypeFactory patf = (PrecisionAnnotatedTypeFactory) atypeFactory;
        TreePath path = patf.getPathExpensive(inv.method);
        String className = TreeUtils.enclosingClass(path).getSimpleName().toString();

        // Store parameter names
        String[] supParams = null;
        if (!limitChecks) {
            supParams = new String[inv.parameters.length];
            List<? extends VariableTree> methVars = inv.method.getParameters();
            for (int i = 0; i < supParams.length; ++i) {
                supParams[i] = solver.getInternalName(methVars.get(i).getName().toString());
            }
        }

        // TODO: Traversing a hashset is probably kinda slow, but at the
        // same time I don't want duplicates.  Hmm...
        for (ClassTree memberClass : classes) {
            Tree extendsClause = memberClass.getExtendsClause();

            if (extendsClause != null && extendsClause.toString().equals(className)) {
                // Found an extending class!  Check for overriding method
                MethodTree override = null;
                for (Tree member : memberClass.getMembers()) {
                    if (member.getKind() == Tree.Kind.METHOD) {
                        MethodTree candidate = (MethodTree) member;
                        if (candidate.getName().equals(inv.method.getName())) {
                            // Overloading is illegal in the checker framework,
                            // so checking just the method name should be
                            // sufficient
                            override = candidate;
                            break;
                        }
                    }
                }
                if (override == null) continue; // No overriding method

                String subclassName = memberClass.getSimpleName().toString();
                String name = "method-" + subclassName + "-" + override.getName().toString() + "-" + inv.line + "-";
                AnnotatedTypeMirror anno = atypeFactory.getAnnotatedType(override).getReturnType();
                double value = chk().getApproxValue(anno);
                name = solver.declareVariable(name, value);
                MetaMethodInvocation sub =
                    new MetaMethodInvocation(override, inv.parameters, name, inv.parent, inv.line, inv);

                if (limitChecks) {
                    solver.addInvocation(sub);
                    // Push our invocation onto the tmp stack
                    solver.pushVar(sub.varName, true);
                } else recheckMethod(sub);

                // Constraints for return values
                solver.assignLastTmp(inv.varName, true);

                // If limit checks, delay this assignment until constraint
                // generation
                if (!limitChecks) {
                    // Constraints for parameters
                    List<? extends VariableTree> subParams = override.getParameters();
                    if (subParams.size() != supParams.length) throw new AssertionError();
                    for (int i = 0; i < supParams.length; ++i) {
                        System.out.println("supParams[" + i + "]: " + supParams[i]);
                        solver.pushVar(supParams[i], true);
                        solver.assignLastTmp(subParams.get(i).getName().toString(), false);
                    }
                }

                handleSubclasses(sub);
            }
        }
    }

    @Override
    public Void visitBlock(BlockTree node, Void p) {
        //solver.pushScope();
        super.visitBlock(node, p);
        //solver.popScope();

        return null;
    }

    public void recheckMethod(MetaMethodInvocation method) {
        System.out.println("************************************************");
        if (!method.inCycle()) {
            MetaMethodInvocation old = currentRevisit;
            currentRevisit = method;
            // Re-check method
            try {
                scan(method.method, null);
            } catch (NullPointerException exc) {
                checker.report(Result.failure("cross.class.inference"), method.method);
                solver.initTmp(-1.0);
            }
            currentRevisit = old;
        } else {
            checker.report(Result.failure("lossy.cycle"), method.method);
        }
        System.out.println("************************************************");
    }

    private void dumpPath() {
        System.out.println("Path: ");
        for (Tree t : getCurrentPath()) {
            System.out.println("node: " + t);
        }
    }

    public static AnnotatedTypeMirror reduceArray(AnnotatedTypeMirror type) {
        while (type instanceof AnnotatedTypeMirror.AnnotatedArrayType) {
            // Get the correct annotation from an array
            AnnotatedTypeMirror.AnnotatedArrayType arr =
                (AnnotatedTypeMirror.AnnotatedArrayType) type;
            type = arr.getComponentType();
        }

        return type;
    }

    private AnnotatedTypeMirror getAnnotatedType(Tree node) {
        AnnotatedTypeMirror type = atypeFactory.getAnnotatedType(node);
        type = reduceArray(type);
        return type;
    }

    private boolean isApprox(Tree node) {
        AnnotatedTypeMirror anno = getAnnotatedType(node);
        return isApprox(anno);
    }

    private boolean isApprox(AnnotatedTypeMirror type) {
        type = reduceArray(type);
        return type.hasAnnotation(Approx.class);
    }

    private boolean isDyn(AnnotatedTypeMirror type) {
        type = reduceArray(type);
        return type.hasAnnotation(Dyn.class);
    }

    private int getPos(Tree node) {
        JCTree jnode = (JCTree) node;
        return jnode.pos;
    }

    public static class MetaMethodInvocation {
        public final MethodTree method;
        public final String[] parameters;
        public final MetaMethodInvocation parent;
        public final long line;
        public final MetaMethodInvocation superMethod;
        public final String varName;

        public MetaMethodInvocation(MethodTree method,
                                    String[] parameters,
                                    String varName,
                                    MetaMethodInvocation parent,
                                    long line,
                                    MetaMethodInvocation superMethod) {
            this.method = method;
            this.parameters = parameters;
            this.varName = varName;
            this.parent = parent;
            this.line = line;
            this.superMethod = superMethod;
        }

        public MetaMethodInvocation(MethodTree method,
                                    String[] parameters,
                                    String varName,
                                    MetaMethodInvocation parent,
                                    long line) {
            this(method, parameters, varName, parent, line, null);
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null || !(obj instanceof MetaMethodInvocation))
                return false;
            MetaMethodInvocation other = (MetaMethodInvocation) obj;

            boolean ret = method.equals(other.method) &&
                          Arrays.equals(parameters, other.parameters) &&
                          this.line == other.line;
            return ret;
        }

        @Override
        public int hashCode() {
            return method.hashCode();
        }

        /**
         * Returns true if this is certainly part of cycle
         */
        public boolean inCycle() {
            for (MetaMethodInvocation current = parent;
                 current != null;
                 current = current.parent) {
                if (this.equals(current)) return true;
            }
            return false;
        }
    }

    @Override
    public PrecisionAnnotatedTypeFactory createTypeFactory() {
        return new PrecisionAnnotatedTypeFactory(chk());
    }
}
