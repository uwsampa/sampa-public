package enerj.instrument;

public class ConstructorMarker {
    public static final ConstructorMarker inst = null;
}
