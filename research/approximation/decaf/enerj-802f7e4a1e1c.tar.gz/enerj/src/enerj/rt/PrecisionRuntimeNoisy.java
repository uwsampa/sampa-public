package enerj.rt;

import java.util.Arrays;
import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;
import java.util.WeakHashMap;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;

import enerj.lang.PrecisionException;

import enerj.PrecisionAnnotatedTypeFactory;
import enerj.PrecisionVisitor;

public class PrecisionRuntimeNoisy extends PrecisionRuntimeDefault {
    // -Dlevels=0.2,0.5,0.999,1.0 (for example)
    private static final String LEVELS_PROPERTY = "levels";

	protected final String CONSTS_FILE =
        PrecisionAnnotatedTypeFactory.CONSTS_FILE;

    // Operation timing errors.
    protected int TIMING_ERROR_MODE = 2;
    protected float TIMING_ERROR_PROB_PERCENT =
        PrecisionAnnotatedTypeFactory.TIMING_ERROR_PROB_PERCENT;

	// Indicates that the approximation should not be used;
	protected final int DISABLED = 0;
    protected final boolean TIMING_ERRORS_ONLY = true;

    private final Stack<String> currentInvocation;
    private final Map<String, Integer> invocations;
    private final Stack<Set<String>> locked;
    private final Map<String, Double> ops;
    private final Stack<Double> precisions;
    private final Stack<Map<String, Reference<?>>> references;

    private double dynVal;
    private boolean inDyn;
    private Map<String, Map<String, Double>> inferredData;


	public PrecisionRuntimeNoisy() {
		super();
		System.err.println("Initializing noisy EnerJ runtime.");
        currentInvocation = new Stack<>();
        precisions = new Stack<Double>();
        references = new Stack<>();
        references.push(new HashMap<>());
        locked = new Stack<>();
        locked.push(new HashSet<>());
        dynVal = 1.0;
        inDyn = false;

        // Read in discrete levels if supplied
        String levelsParam = System.getProperty(LEVELS_PROPERTY);
        double[] levels = null;
        if (levelsParam != null) {
            String[] levelStrs = levelsParam.split(",");
            levels = new double[levelStrs.length];
            for (int i = 0; i < levels.length; ++i) {
                double level = -1.0;
                try {
                    level = Double.parseDouble(levelStrs[i]);
                } catch (NumberFormatException e) {
                    System.err.println("levels must in be format l_0,l_1,...,l_n");
                    System.exit(1);
                }
                if (level < 0.0 || level > 1.0) {
                    System.err.println("-Dlevels must be in the range [0.0, 1.0]");
                    System.exit(1);
                }
                levels[i] = level;
            }
            Arrays.sort(levels);
        }

        invocations = new HashMap<>();
        ops = new HashMap<>();
        Scanner lines;
        try {
            lines = new Scanner(new File(PrecisionVisitor.OPS_CSV));
        } catch (FileNotFoundException e) { throw new RuntimeException(e); }
        while (lines.hasNextLine()) {
            String[] tokens = lines.nextLine().split(",");
            for (String token : tokens) {
                if (token.startsWith("op-")) {
                    String[] kv = token.split(":");
                    assert kv.length == 2;
                    String[] opTokens = kv[0].split("-");
                    String opName = join(Arrays.copyOfRange(opTokens, 0, 2), "-") + "-" +
                                    join(Arrays.copyOfRange(opTokens, 3, 6), "-") + "-" +
                                    join(Arrays.copyOfRange(opTokens, 7, 9), "-");
                    //String opName = kv[0].substring(0, kv[0].lastIndexOf("-"));
                    double opValue = Double.parseDouble(kv[1]);

                    if (levels != null) {
                        // Discretize value
                        int index = Arrays.binarySearch(levels, opValue);
                        if (index < 0) {
                            index = (index + 1) * -1;
                            try {
                                opValue = levels[index];
                            } catch (ArrayIndexOutOfBoundsException e) {
                                System.err.printf("Found operator with precision %f but highest available precision is %f\n", opValue, levels[levels.length-1]);
                                System.exit(1);
                            }
                        }
                    }

                    Double old = ops.put(opName, opValue);
                    if (old != null && old != opValue) {
                        // FIXME: This is a poor fix to the problem of multiple
                        // values binding to the same operators.  Operators
                        // should be read from inferredData because it is
                        // guaranteed to be unique
                        ops.put(opName, Math.max(old, opValue));
                        //throw new AssertionError("old != null && " + old + " != " + opValue);
                    }
                } else if (token.startsWith("inv-")) {
                    String[] kv = token.split(":");
                    if (kv.length != 2) throw new AssertionError("kv.length != 2");
                    String[] invTokens = kv[0].split("-");
                    String methodName = join(Arrays.copyOfRange(invTokens, 3, 5), "-");
                    int invocation = (int) Double.parseDouble(kv[1]);
                    invocations.put(methodName, invocation);
                }
            }
        }

        // Read in inferred data
        // TODO: Operators will be read in without being adjusted for discrete
        // values, is this OK?
        try {
            FileInputStream fileIn = new FileInputStream(PrecisionVisitor.INFERRED_DATA_SER);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            inferredData = (Map<String, Map<String, Double>>) in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException | ClassNotFoundException e) {
            System.err.printf("Error reading %s, please re-compile and try again\n", PrecisionVisitor.INFERRED_DATA_SER);
            System.exit(1);
        }

        // Find main
        for (String key : inferredData.keySet()) {
            if (key.contains("main")) {
                currentInvocation.push(key);
                break;
            }
        }


        lines.close();
        System.err.println(ops);
        System.err.println(invocations);
        System.err.println(inferredData);
	}

	@Override
    public <T> T loadLocal(Reference<T> ref, boolean approx) {
        if (inDyn) pushPrecision(ref.approxValue);
	    return super.loadLocal(ref, approx);
	}

    @Override
	public <T> T loadArray(Object array, int index, boolean approx, String name) {
        boolean loadLocal = name.contains("loadLocal");
        name = name.split("\\[")[0];
        if (inDyn && !loadLocal) pushPrecision(name);
        return super.loadArray(array, index, approx, name);
    }

    @Override
	public <T> T loadField(Object obj,
                           String fieldname,
                           boolean approx,
                           double precision) {
        if (inDyn) pushPrecision(precision);
        return super.loadField(obj, fieldname, approx, precision);

    }

    @Override
    public Void enterFunction(String invocation) {
        currentInvocation.push(invocation);
        return null;
    }

    @Override
    public <T> T exitFunction(Void enter, T statement) {
        currentInvocation.pop();
        return statement;
    }

    @Override
    public String enterDyn(String varName) {
        if (inDyn || !precisions.isEmpty())
            throw new IllegalStateException("Already in dyn");

        inDyn = true;
        return varName;
    }

    @Override
    public <T> T exitDyn(String varName, T statement) {
        if (!inDyn) throw new IllegalStateException("Not currently in dyn");
        inDyn = false;
        dynVal = precisions.isEmpty() ? 1.0 : precisions.pop();
        precisions.clear();

        if (varName != null) {
            Reference<?> ref = references.peek().get(varName);
            if (ref != null)
                ref.approxValue = ref.primitive ? dynVal :
                                                  Math.min(dynVal, ref.approxValue);
        }

        return statement;
    }

    @Override
    public double resetDynVal() {
        double ret = dynVal;
        dynVal = 1.0;
        return ret;
    }

    @Override
    public void addRef(String name, Reference<?> ref) {
        if (locked.peek().contains(name)) {
            // Update reference
            Reference<?> locked = references.peek().get(name);
            if (locked == null) throw new AssertionError("locked == null");
            ref.approxValue = locked.approxValue;

            // Unlock reference
            this.locked.peek().remove(name);
        }
        references.peek().put(name, ref);
    }

    @Override
    public Void beforeApply(String invocation) {
        references.push(new HashMap<String, Reference<?>>(references.peek()));
        locked.push(new HashSet<>());
        enterFunction(invocation);
        return null;
    }

    @Override
    public Void pairArgs(Void prev, String formal, String actual) {
        actual = actual.split("\\[")[0];
        Reference<?> ref = references.peek().get(actual);
        if (ref == null)
            // Assume that if there are @Dyn's in here, the actual parameter
            // was actually a variable
            ref = new Reference(0.0);
        references.peek().put(formal, ref);
        locked.peek().add(formal);
        return null;
    }

    @Override
    public <T> T afterApply(Void before, T fun, String varName) {
        references.pop();
        locked.pop();

        if (!varName.equals("")) {
            // Set the precision of varName
            Reference<?> ref = references.peek().get(varName);
            if (ref == null) {
                // Create new dummy reference and lock it to be replaced when
                // vardef is exited
                ref = new Reference(dynVal);
            } else {
                // variable already declared
                ref.approxValue = dynVal;
            }
        }

        exitFunction(null, null);
        return fun;
    }

    @Override
    public <T> T checkedEndorse(T statement, double target) {
        if (dynVal < target) throw new PrecisionException(target, dynVal);
        return statement;
    }

    private void pushPrecision(String name) {
        Reference<?> ref = references.peek().get(name);
        if (ref == null)
            throw new AssertionError(name + " not in Reference table");
        pushPrecision(ref.approxValue);
    }

    private void pushPrecision(double value) {
        if (value < 0 || value > 1.0 || Double.isNaN(value))
            throw new AssertionError("value " + value + " is illegal");
        precisions.push(value);
    }

    /**
     * Joins a String[] using sep in-between elements.
     *
     * Why this is not a standard library function is beyond me
     */
    private static String join(String[] arr, String sep) {
        if (arr.length == 0) return "";

        StringBuilder ret = new StringBuilder(arr[0]);
        for (int i = 1; i < arr.length; ++i) ret.append(sep).append(arr[i]);
        return ret.toString();
    }


	// Error injection helpers.

    private int numBytes(Object value) {
        if (value instanceof Byte) return 1;
        else if (value instanceof Short) return 2;
        else if (value instanceof Integer) return 4;
        else if (value instanceof Long) return 8;
        else if (value instanceof Float) return 4;
        else if (value instanceof Double) return 8;
        else if (value instanceof Character) return 2;
        else if (value instanceof Boolean) return 1;
        else assert false;
        return 0;
    }

    private long toBits(Object value) {
		if (value instanceof Byte || value instanceof Short ||
				value instanceof Integer || value instanceof Long) {
			return ((Number)value).longValue();
		} else if (value instanceof Float) {
			return Float.floatToRawIntBits((Float)value);
		} else if (value instanceof Double) {
			return Double.doubleToRawLongBits((Double)value);
		} else if (value instanceof Character) {
			return ((Character)value).charValue();
		} else if (value instanceof Boolean) {
			if ((Boolean)value) {
				return -1;
			} else {
				return 0;
			}
		} else {
			// Non-primitive type.
            assert false;
            return 0;
		}
    }

    private Object fromBits(long bits, Object oldValue) {
		if (oldValue instanceof Byte) {
			return (byte)bits;
		} else if (oldValue instanceof Short) {
			return (short)bits;
		} else if (oldValue instanceof Integer) {
			return (int)bits;
		} else if (oldValue instanceof Long) {
			return bits;
		} else if (oldValue instanceof Float) {
			return (Float.intBitsToFloat((int)bits));
		} else if (oldValue instanceof Double) {
			return (Double.longBitsToDouble(bits));
		} else if (oldValue instanceof Character) {
			return (char)bits;
		} else if (oldValue instanceof Boolean) {
			return (bits != 0);
		} else {
			assert false;
			return null;
		}
    }

	private <T> T bitError(T value, long invProb) {
        if (!isPrimitive(value))
            return value;

		long bits = toBits(value);
		int width = numBytes(value);

		// Inject errors.
		for (int bitpos = 0; bitpos < width * 8; ++bitpos) {
			long mask = 1 << bitpos;
			if ((long)(Math.random() * invProb) == 0) {
				// Bit error!
				bits = bits ^ mask;
			}
		}

        return (T) fromBits(bits, value);
	}

	private boolean isPrimitive(Object o) {
		return (
			o instanceof Number ||
			o instanceof Boolean ||
			o instanceof Character
		);
	}

    // Timing errors for arithmetic.
    private HashMap<Class<?>, Number> lastValues = new HashMap<Class<?>, Number>();
    private Number timingError(Number num, double correct_prob) {
        long bits;
        if (Math.random() > correct_prob) {
            switch (TIMING_ERROR_MODE) {
            case DISABLED:
                return num;

            case 1: // Single bit flip.
                bits = toBits(num);
                int errpos = (int)(Math.random() * numBytes(num) * 8);
                bits = bits ^ (1 << errpos);
                return (Number)fromBits(bits, num);

            case 2: // Random value.
                bits = 0;
                for (int i = 0; i < numBytes(num); ++i) {
                    byte b = (byte)(Math.random() * Byte.MAX_VALUE);
                    bits |= ((long)b) << (i*8);
                    if (Math.random() < 0.5)
                        bits |= 1L << ((i+1)*8-1); // Sign bit.
                }
                return (Number)fromBits(bits, num);

            case 3: // Last value.
                if (lastValues.containsKey(num.getClass()))
                    return lastValues.get(num.getClass());
                else
                    return (Number)fromBits(0, num);

            default:
                assert false;
                return null;
            }
        } else {
            return num;
        }
    }

    private void dumpStack() {
        Thread.dumpStack();
    }

    @Override
    public double getValue(String varName) {

        String inv = currentInvocation.isEmpty() ? "" :
                                                   currentInvocation.peek();
        Map<String, Double> data = inferredData.get(inv);
        if (inv == "") return 1.0; // constructor

        if (data == null) {
            // Expensive lookup, this traversal works fine because the cases
            // where currentInvocation in not in inferredData are all cases
            // where only one method was generated anyway
            StackTraceElement[] trace = Thread.currentThread().getStackTrace();
            StackTraceElement currentFrame = trace[3];
            StackTraceElement prevFrame = trace.length > 4 ? trace[4] : null;

            StringBuilder internalMethodName = new StringBuilder("method-");
            internalMethodName.append(currentFrame.getClassName())
                              .append("-")
                              .append(currentFrame.getMethodName())
                              .append("-");
            if (prevFrame == null) internalMethodName.append(0);
            else internalMethodName.append(prevFrame.getLineNumber());
            Integer invocation = invocations.get(internalMethodName.toString());
            internalMethodName.append("-");
            if (invocation != null) internalMethodName.append(invocation);

            for (Map.Entry<String, Map<String, Double>> entry : inferredData.entrySet()) {
                if (entry.getKey().contains(internalMethodName.toString())) {
                    data = entry.getValue();
                    break;
                }
            }

            if (data == null) {
                // Try appending a one, this could be main
                internalMethodName.append(1);
                for (Map.Entry<String, Map<String, Double>> entry : inferredData.entrySet()) {
                    if (entry.getKey().contains(internalMethodName.toString())) {
                        data = entry.getValue();
                        break;
                    }
                }
            }
        }

        // On error, assume we're in a void function without dyns
        if (data == null) {
            return 0.0;
            //throw new AssertionError("data == null");
        }
        Double ret = data.get(varName);
        if (ret == null) {
            return 0.0;
            //throw new AssertionError(varName + " not in data");
        }
        return ret;
    }

	// Runtime operations.

	@Override
	public Number binaryOp(Number lhs, Number rhs, ArithOperator op,
						   NumberKind nk, boolean approx, int opNum,
                           int numApprox) {
		// DEBUG
		/*
		if ((nk == NumberKind.DOUBLE || nk == NumberKind.FLOAT) && !approx) {
			// Why wasn't it approximate?
			Thread.dumpStack();
		}
		*/

        Number res = super.binaryOp(lhs, rhs, op, nk, approx, opNum, numApprox);
        //System.out.println("binaryOp called for opNum " + opNum);

        StackTraceElement[] callStack = Thread.currentThread().getStackTrace();
        boolean next = false;
        Double value = null;
        String name = null;
        String lastName = null;
        String className = null;
        for (StackTraceElement e : callStack) {
            if (className != null) {
                String internalMethodName = lastName + "-" + e.getLineNumber();
                Integer invocation = invocations.get(internalMethodName);
                name = "op-method-" + lastName + "-";
                if (invocation == null) name += e.getLineNumber() + "-";
                else name += "0-" + invocation;
                name += "--" + opNum;

                value = ops.get(name);
                if (value == null) {
                    // Must not be in an inferred method
                    name = "op-" + lastName + "-0-" + opNum;
                    value = ops.get(name);
                }

                if (value == null) {
                    name = "op-method-" + lastName + "-0---" + opNum;
                    value = ops.get(name);
                }

                if (value != null) break;
            }

            // Stored values for next iteration
            String[] classNameTokens = e.getClassName().split("\\$");
            className = classNameTokens[classNameTokens.length - 1];
            lastName = e.getMethodName();
        }
        if (value == null) {
            // Op may be in main
            name = "op-method-main-0---" + opNum;
            value = ops.get(name);
            if (value == null) {
                name = "op-method-" + className + "-main-0---" + opNum;
                value = ops.get(name);
            }
            if (value == null) {
                name = "op-method-" + className + "-main-0-1--" + opNum;
                value = ops.get(name);
            }
        }
        if (value == null) value = 1.0;

        if (approx) {
            if (value < 0.9)
                System.err.println("Operator " + name + " has value " + value);

            countOperation(name);
        } else {
            countOperation("precise");
        }

        // Timing errors on ALU.
        if (approx/* && !(nk == NumberKind.DOUBLE || nk == NumberKind.FLOAT)*/) {
            res = timingError(res, value);
            if (TIMING_ERROR_MODE == 3) // Last value mode.
                lastValues.put(res.getClass(), res);
        }

        if (inDyn) {
            countOperation("dyn");

            // Track precision
            if (numApprox < 0 || numApprox > 2)
                throw new IllegalArgumentException("numApprox must be in the range [0, 2]");

            double precision = 1.0;
            for (int i = 0; i < numApprox; ++i) {
                try {
                    precision *= precisions.pop();
                } catch (EmptyStackException e) {
                    throw new IllegalStateException("Not enough precisions declared");
                }
            }
            pushPrecision(precision);
        }

		return res;
	}
}
