package checkers.runtime.jillexample;

public class ExampleRuntime {
    public static Object didCast(Object value) {
        System.out.println("performing cast on \"" + value + "\"");
        return value;
    }
}
