public class Demo {
  static Object o = (String) "a String!";

  public static void main(String[] args) {
      Object o = (String) "a String!";
      String s = (String) o;
  }
}
